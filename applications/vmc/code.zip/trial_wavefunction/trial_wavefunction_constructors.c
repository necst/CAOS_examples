/**
 * @file trial_wavefunction_constructors.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Constructors and initialisers for the TrialWavefunction_t class.
 */
#include <trial_wavefunction/trial_wavefunction.h>
#include <trial_wavefunction/trial_wavefunction_query.h>


/**
 * @brief Initialise the function pointers for a TrialWavefunction_t object.
 * @param[in] _self : TrialWavefunction_t object.
 */
void trial_wavefunction_initialise( TrialWavefunction_t * _self ) {

  _self->print = &trial_wavefunction_print ;
  _self->evaluate = &trial_wavefunction_evaluate ;
  _self->gradient = &trial_wavefunction_gradient ;
  _self->laplacian = &trial_wavefunction_laplacian ;

}

