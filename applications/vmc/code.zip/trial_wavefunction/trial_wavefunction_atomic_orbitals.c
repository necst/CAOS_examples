/**
 * @file trial_wavefunction_atomic_orbitals.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Atomic orbital evaluation routines for TrialWavefunction_t class.
 */
#include <trial_wavefunction/trial_wavefunction.h>
#include <trial_wavefunction/trial_wavefunction_query.h>

// Some static arrays that we need to keep their values between invocations
static float_p aoValsBase[NTHREADSMAX*NAOSMAX] ;
static float_p ddr1_aoValsBase[NTHREADSMAX*NAOSMAX] ;
static float_p ddr2_aoValsBase[NTHREADSMAX*NAOSMAX] ;

static float_p distance_r[DEF_NAOS_L*3];
static float_p distance_rSq[DEF_NAOS_L];
static float_p ao_vals_vec[DEF_NAOS_L][DEF_MAX_AO_TYPE];


/**
 * @brief Compute the atomic orbital prefactor resulting from its angular momentum.
 *        Assumes we're in a Cartesian basis.
 * @param[in]  _dr     : Difference vector between electron and atomic orbital centre.
 * @param[in]  _m      : Atomic orbital angular momentum type (see enum in trial_wavefunction.h).
 * @param[out] float_p : Value of the atomic orbital.
 */
static float_p cartesianPrefactor( const float_p * _dr, const size_t _m ) {

  float_p prefactor = 0 ;
  
  switch( _m ) {

  case S:
    prefactor = 1.0 ; break ;
  case PX:
    prefactor = _dr[0] ; break ;
  case PY:
    prefactor = _dr[1] ; break ;
  case PZ:
    prefactor = _dr[2] ; break ;
  case DXX:
    prefactor = _dr[0] * _dr[0] ; break ;
  case DYY:
    prefactor = _dr[1] * _dr[1] ; break ;
  case DZZ:
    prefactor = _dr[2] * _dr[2] ; break ;
  case DXY:
    prefactor = _dr[0] * _dr[1] ; break ;
  case DXZ:
    prefactor = _dr[0] * _dr[2] ; break ;
  case DYZ:
    prefactor = _dr[1] * _dr[2] ; break ;
  }

  return prefactor ;

}


/**
 * @brief Compute the values of the atomic orbitals arising in the LCAO expansion for the trial wavefunction.
 * @param[in]  _self   : TrialWavefunction_t object.
 * @param[in]  _pos    : Position at which we're evaluating the atomic orbitals.
 * @param[out] _aoVals : Atomic orbital values.
 * @note The statically allocated aoValsBase, ddr1_aoValsBase and ddr2_aoValsBase are full at the end of this routine, 
 *       so can be used for computing derivatives of molecular orbitals in other routines.
 */
void trial_wavefunction_atomicOrbitals( const TrialWavefunction_t *_self,
					const size_t _iThread,
					const float_p * _vec,
					const float_p * _sq,
					float_p * _aoVals ) {

  // Zero the accumulator over m quantum number atomic orbitals
  size_t iAO_m = 0 ;

  // Loop over each angular momentum l quantum number atomic orbital
  for( size_t iAO_l=0 ; iAO_l<_self->nAOs_l ; iAO_l++ ) {

    size_t aoIndex_l = _iThread*NAOSMAX + iAO_l ;
    aoValsBase[aoIndex_l] = 0, ddr1_aoValsBase[aoIndex_l] = 0, ddr2_aoValsBase[aoIndex_l] = 0 ;

    // Various indices we need for loop bounds and array offsets
    size_t centreIdx = _self->aoCentre[iAO_l], nPrims = _self->nPrims[iAO_l], aoPrimOffset = _self->aoPrimOffset[iAO_l] ;

    // Distance components between electron and atomic orbital centre
    const float_p * r = _vec+centreIdx*nDims ; float_p rSq = _sq[centreIdx] ;

    // Compute the angular-momentum independent component of the atomic orbital. Contraction over primitives
    for( size_t iPrim=0 ; iPrim<nPrims ; iPrim++ ) {
      float_p zeta = _self->primZeta[aoPrimOffset+iPrim];
      float_p coeff = _self->primCoeff[aoPrimOffset+iPrim];

      float_p gaussian = coeff * exp( - zeta * rSq ) ;

      aoValsBase[aoIndex_l] += gaussian, ddr1_aoValsBase[aoIndex_l] += zeta * gaussian, ddr2_aoValsBase[aoIndex_l] += zeta * zeta * gaussian ; 
    }

    // Now we do the contraction with the Cartesian prefactor for the atomic
    // orbitals
    // Check that we're not exceeding the number of atomic orbitals we've
    // ascertained arise in the LCAO each time
    size_t ltype = _self->aoType_l[iAO_l] ;
    for( size_t jAO_m=0 ; jAO_m<ltype ; jAO_m++ ) {
      assert( iAO_m < _self->nAOs_m ) ;
      float_p pre = cartesianPrefactor( r, mapAngMomIdx( ltype, jAO_m ) ) ;
      _aoVals[iAO_m] = pre * _self->aoNorm[iAO_m] * aoValsBase[aoIndex_l] ;
      iAO_m++ ;
    }
    
  }

}


void trial_wavefunction_atomicOrbitals_wrapper( const TrialWavefunction_t *_self,
          const size_t _iThread,
          const float_p * _vec,
          const float_p * _sq,
          float_p * _aoVals ) {

  // step 1) expand centers before computation
  // TODO: consider doing the overall computation without expansion

  // Distance components between electron and atomic orbital centre
  size_t iAO_l = 0;
  for( iAO_l=0 ; iAO_l < DEF_NAOS_L ; iAO_l++ ) {
    size_t centreIdx = _self->aoCentre[iAO_l];
    distance_rSq[iAO_l] = _sq[centreIdx];
    for( size_t d = 0; d < nDims; d++ ) {
      distance_r[iAO_l*nDims + d] = _vec[centreIdx * nDims + d];
    }
  }

  // step 2) perform the actual atomicOrbitals computation
  trial_wavefunction_atomicOrbitals_inner(
    (const float_p (*)[3]) distance_r,
    distance_rSq,
    ao_vals_vec,
    aoValsBase,
    ddr1_aoValsBase,
    ddr2_aoValsBase
  );

  // step 3) Compress the ao_vals_vec data into aoVals
  // TODO: consider doing the overall computation without compression
  size_t iAO_m = 0;
  for( iAO_l=0 ; iAO_l < DEF_NAOS_L ; iAO_l++ ) {
    size_t ltype = _self->aoType_l[iAO_l] ;
    for( size_t jAO_m=0; jAO_m < ltype; jAO_m++ ) {
      _aoVals[iAO_m] = ao_vals_vec[iAO_l][jAO_m];
      iAO_m++ ;
    }
  }
}


/**
 * @brief Compute the values of the atomic orbitals arising in the LCAO expansion for the trial wavefunction.
 * @param[in]  _self   : TrialWavefunction_t object.
 * @param[in]  _pos    : Position at which we're evaluating the atomic orbitals.
 * @param[out] _aoVals : Atomic orbital values.
 * @note The statically allocated aoValsBase, ddr1_aoValsBase and ddr2_aoValsBase are full at the end of this routine, 
 *       so can be used for computing derivatives of molecular orbitals in other routines.
 */
void trial_wavefunction_atomicOrbitals_inner(
          const float_p distance_r[DEF_NAOS_L][3],
          const float_p distance_rSq[DEF_NAOS_L],
          float_p _aoVals[DEF_NAOS_L][DEF_MAX_AO_TYPE],
          float_p _aoValsBase[DEF_NAOS_L],
          float_p _ddr1_aoValsBase[DEF_NAOS_L],
          float_p _ddr2_aoValsBase[DEF_NAOS_L] ) {

  #include <trial_wavefunction_const_arrays_dump.h>

  // Loop over each angular momentum l quantum number atomic orbital
  for( size_t iAO_l=0 ; iAO_l < DEF_NAOS_L ; iAO_l++ ) {

    _aoValsBase[iAO_l] = 0; 
    _ddr1_aoValsBase[iAO_l] = 0; 
    _ddr2_aoValsBase[iAO_l] = 0;

    // Compute the angular-momentum independent component of the atomic orbital. Contraction over primitives
    for( size_t iPrim=0 ; iPrim < DEF_MAX_NPRIMS; iPrim++ ) {

      float_p zeta = expanded_primZeta[iAO_l][iPrim];
      float_p coeff = expanded_primCoeff[iAO_l][iPrim];

      float_p gaussianVal = coeff * expf( - zeta * distance_rSq[iAO_l] );

      _aoValsBase[iAO_l] += gaussianVal; 
      _ddr1_aoValsBase[iAO_l] += zeta * gaussianVal; 
      _ddr2_aoValsBase[iAO_l] += zeta * zeta * gaussianVal;
    }

    // Now we do the contraction with the Cartesian prefactor for the atomic
    // orbitals
    // Check that we're not exceeding the number of atomic orbitals we've
    // ascertained arise in the LCAO each time
    size_t ltype = const_aoType_l[iAO_l] ;
    for( size_t jAO_m=0; jAO_m < DEF_MAX_AO_TYPE; jAO_m++ ) {
      // Custom cartesian prefactor for S and P orbitals only
      size_t _m = mapAngMomIdx( ltype, jAO_m );
      float_p pre = 0;

      pre = _m == S ? 1.0 : pre;
      pre = _m == PX ? distance_r[iAO_l][0] : pre;
      pre = _m == PY ? distance_r[iAO_l][1] : pre;
      pre = _m == PZ ? distance_r[iAO_l][2] : pre;

      _aoVals[iAO_l][jAO_m] = pre * expanded_aoNorm[iAO_l][jAO_m] * _aoValsBase[iAO_l];
    }
  }
}


static void gradientCombination( const float_p * _dr,
				 const float_p * _f,
				 const size_t _m,
				 float_p * _aoGrad ) {
  
  switch( _m ) {

  case S:
    _aoGrad[0] = -2 * _dr[0] * _f[1] ;
    _aoGrad[1] = -2 * _dr[1] * _f[1] ;
    _aoGrad[2] = -2 * _dr[2] * _f[1] ;
    break ;
  case PX:
    _aoGrad[0] = ( _f[0] - 2 * _dr[0] * _dr[0] * _f[1] ) ;
    _aoGrad[1] = -2 * _dr[0] * _dr[1] * _f[1] ;
    _aoGrad[2] = -2 * _dr[0] * _dr[2] * _f[1] ;
    break ;
  case PY:
    _aoGrad[0] = -2 * _dr[1] * _dr[0] * _f[1] ;
    _aoGrad[1] = ( _f[0] - 2 * _dr[1] * _dr[1] * _f[1] ) ;
    _aoGrad[2] = -2 * _dr[1] * _dr[2] * _f[1] ;
    break ;
  case PZ:
    _aoGrad[0] = -2 * _dr[2] * _dr[0] * _f[1] ;
    _aoGrad[1] = -2 * _dr[2] * _dr[1] * _f[1] ;
    _aoGrad[2] = ( _f[0] - 2 * _dr[2] * _dr[2] * _f[1] ) ;
    break ;
  case DXX:
    _aoGrad[0] =  2 * ( _dr[0] * _f[0] - _dr[0] * _dr[0] * _dr[0] * _f[1] ) ;
    _aoGrad[1] = -2 * ( _dr[0] * _dr[0] * _dr[1] * _f[1] ) ;
    _aoGrad[2] = -2 * ( _dr[0] * _dr[0] * _dr[2] * _f[1] ) ;
    break ;
  case DYY:
    _aoGrad[0] = -2 * ( _dr[1] * _dr[1] * _dr[0] * _f[1] ) ;
    _aoGrad[1] =  2 * ( _dr[1] * _f[0] - _dr[1] * _dr[1] * _dr[1] * _f[1] ) ;
    _aoGrad[2] = -2 * ( _dr[1] * _dr[1] * _dr[2] * _f[1] ) ;
    break ;
  case DZZ:
    _aoGrad[0] = -2 * ( _dr[2] * _dr[2] * _dr[0] * _f[1] ) ;
    _aoGrad[1] = -2 * ( _dr[2] * _dr[2] * _dr[1] * _f[1] ) ;
    _aoGrad[2] =  2 * ( _dr[2] * _f[0] - _dr[2] * _dr[2] * _dr[2] * _f[1] ) ;
    break ;
  case DXY:
    _aoGrad[0] = ( _dr[1] * _f[0] - 2 * _dr[0] * _dr[0] * _dr[1] * _f[1] ) ;
    _aoGrad[1] = ( _dr[0] * _f[0] - 2 * _dr[1] * _dr[1] * _dr[0] * _f[1] ) ;
    _aoGrad[2] = -2 * _dr[0] * _dr[1] * _dr[2] * _f[1] ;
    break ;
  case DXZ:
    _aoGrad[0] = ( _dr[2] * _f[0] - 2 * _dr[0] * _dr[0] * _dr[2] * _f[1] ) ;
    _aoGrad[1] = -2 * _dr[0] * _dr[1] * _dr[2] * _f[1] ;
    _aoGrad[2] = ( _dr[0] * _f[0] - 2 * _dr[2] * _dr[2] * _dr[0] * _f[1] ) ;
    break ;
  case DYZ:
    _aoGrad[0] = -2 * _dr[0] * _dr[1] * _dr[2] * _f[1] ;
    _aoGrad[1] = ( _dr[2] * _f[0] - 2 * _dr[1] * _dr[1] * _dr[2] * _f[1] ) ;
    _aoGrad[2] = ( _dr[1] * _f[0] - 2 * _dr[2] * _dr[2] * _dr[1] * _f[1] ) ;
    break ;
  }

}

void trial_wavefunction_d1atomicOrbitals( const TrialWavefunction_t *_self,
					  const size_t _iThread,
					  const float_p * _vec,
					  float_p * _aoGrad ) {

  // Zero the accumulator over m quantum number atomic orbitals
  size_t iAO_m = 0 ;

  // Loop over each angular momentum l quantum number atomic orbital
  for( size_t iAO_l=0 ; iAO_l<_self->nAOs_l ; iAO_l++ ) {

    size_t aoIndex_l = _iThread * NAOSMAX + iAO_l, centreIdx = _self->aoCentre[iAO_l] ;
    
    // Distance components between electron and atomic orbital centre
    const float_p * r = _vec+centreIdx*nDims ;

    // Now we do the contraction with the Cartesian prefactor for the atomic orbitals
    // Check that we're not exceeding the number of atomic orbitals we've ascertained arise in the LCAO each time
    size_t ltype = _self->aoType_l[iAO_l] ;
    for( size_t jAO_m=0 ; jAO_m<ltype ; jAO_m++ ) {
      assert( iAO_m < _self->nAOs_m ) ;
      float_p f[2] = {
	      _self->aoNorm[iAO_m] * aoValsBase[aoIndex_l],
	      _self->aoNorm[iAO_m] * ddr1_aoValsBase[aoIndex_l]
      } ;

      gradientCombination( r, f, mapAngMomIdx( ltype, jAO_m ),
			   _aoGrad+(iAO_m*nDims) ) ;
      iAO_m++ ;
    }
    
  }

}

/**
 * @brief Compute the angular momentum portion of the laplacian of the atomic orbital which gets
 *        contracted with the Gaussian portion.
 * @param[in]  _dr     : Vector difference between electron and atomic orbital centre.
 * @param[in]  _f      : Gaussian parts of the combination.
 * @param[in]  _m      : Atomic orbital angular momentum type.
 * @param[out] float_p : Atomic orbital prefactor.
 */
static float_p laplacianCombination( const float_p * _dr,
				     const float_p * _f,
				     const size_t _m ) {

  float_p factor = 0 ;
  float_p rSq = _dr[0] * _dr[0] + _dr[1] * _dr[1] + _dr[2] * _dr[2] ;
  
  switch( _m ) {

  case S:
    factor = 4 * rSq * _f[2] - 6 * _f[1] ;
    break ;
  case PX:
    factor = ( 4 * rSq * _f[2] - 10 * _f[1] ) * _dr[0] ;
    break ;
  case PY:
    factor = ( 4 * rSq * _f[2] - 10 * _f[1] ) * _dr[1] ;
    break ;
  case PZ:
    factor = ( 4 * rSq * _f[2] - 10 * _f[1] ) * _dr[2] ;
    break ;
  case DXX:
    factor = 2 * _f[0] + ( 4 * rSq * _f[2] - 2 * _f[1] ) * _dr[0] * _dr[0] ;
    break ;
  case DYY:
    factor = 2 * _f[0] + ( 4 * rSq * _f[2] - 2 * _f[1] ) * _dr[1] * _dr[1] ;
    break ;
  case DZZ:
    factor = 2 * _f[0] + ( 4 * rSq * _f[2] - 2 * _f[1] ) * _dr[2] * _dr[2] ;
    break ;
  case DXY:
    factor = ( 4 * rSq * _f[2] - 2 * _f[1] ) * _dr[0] * _dr[1] ;
    break ;
  case DXZ:
    factor = ( 4 * rSq * _f[2] - 2 * _f[1] ) * _dr[0] * _dr[2] ;
    break ;
  case DYZ:
    factor = ( 4 * rSq * _f[2] - 2 * _f[1] ) * _dr[1] * _dr[2] ;
    break ;

  }

  return factor ;

}

/**
 * @brief Compute the Laplacian of the atomic orbitals for the LCAO with respect to an electron's position.
 * @param[in] _self    : TrialWavefunction_t object.
 * @param[out] _aoLapl : Laplacian of atomic orbitals.
 */
void trial_wavefunction_d2atomicOrbitals( const TrialWavefunction_t *_self,
					  const size_t _iThread,
					  const float_p * _vec,
					  float_p * _aoLapl ) {

  // Zero the accumulator over m quantum number atomic orbitals
  size_t iAO_m = 0 ;

  // Loop over each angular momentum l quantum number atomic orbital
  for( size_t iAO_l=0 ; iAO_l<_self->nAOs_l ; iAO_l++ ) {

    size_t aoIndex_l = _iThread * NAOSMAX + iAO_l, centreIdx = _self->aoCentre[iAO_l] ;
    
    // Distance components between electron and atomic orbital centre
    const float_p * r = _vec+centreIdx*nDims ;

    // Now we do the contraction with the Cartesian prefactor for the atomic orbitals
    // Check that we're not exceeding the number of atomic orbitals we've ascertained arise in the LCAO each time
    size_t ltype = _self->aoType_l[iAO_l] ;
    for( size_t jAO_m=0 ; jAO_m<ltype ; jAO_m++ ) {
      assert( iAO_m < _self->nAOs_m ) ;
      float_p f[3] = {
	      _self->aoNorm[iAO_m] * aoValsBase[aoIndex_l],
	      _self->aoNorm[iAO_m] * ddr1_aoValsBase[aoIndex_l],
	      _self->aoNorm[iAO_m] * ddr2_aoValsBase[aoIndex_l]
      } ;
      _aoLapl[iAO_m] =
	      laplacianCombination( r, f, mapAngMomIdx( ltype, jAO_m ) ) ;
      iAO_m++ ;
    }
    
  }

}
