#ifndef TRIAL_WAVEFUNCTION_H
#define TRIAL_WAVEFUNCTION_H

#define NAOSMAX 4096

#include <global.h>

enum WavefunctionType { SLATER, SLATER_JASTROW } ;
enum Spin { ALPHA, BETA } ;
enum Orbital { S_TYPE = 1, P_TYPE = 3, D_TYPE = 6, F_TYPE = 10 } ;
enum AngMom { S = 2,
	      PX = 6, PY = 7, PZ = 8,
	      DXX = 12, DYY = 13, DZZ = 14, DXY = 15, DXZ = 16, DYZ = 17,
	      FXXX = 20, FYYY = 21, FZZZ = 22, FXXY = 23, FXXZ = 24,
	      FXYY = 25, FXYZ = 26, FXZZ = 27, FYYZ = 28, FYZZ = 29
            } ;


#include <trial_wavefunction_dump.h>

void trial_wavefunction_initialise( TrialWavefunction_t * _self ) ;


void trial_wavefunction_print( const TrialWavefunction_t * _self ) ;
void trial_wavefunction_evaluate( const TrialWavefunction_t * _self,
				  const size_t _iThread,
				  const float_p * _vec,
				  const float_p * _sq,
				  const size_t _iSpin,
				  cfloat_p ** _wave ) ;
void trial_wavefunction_gradient( const TrialWavefunction_t * _self,
				  const size_t _iThread,
				  const float_p * _vec,
				  const size_t _iSpin,
				  cfloat_p ** _grad ) ;
void trial_wavefunction_laplacian( const TrialWavefunction_t * _self,
				   const size_t _iThread,
				   const float_p * _vec,
				   const size_t _iSpin,
				   cfloat_p ** _lapl ) ;

void trial_wavefunction_atomicOrbitals( const TrialWavefunction_t *_self,
					const size_t _iThread,
					const float_p * _vec,
					const float_p * _sq,
					float_p * _aoVals ) ;
void trial_wavefunction_atomicOrbitals_inner(
          const float_p distance_r[DEF_NAOS_L][3],
          const float_p distance_rSq[DEF_NAOS_L],
          float_p _aoVals[DEF_NAOS_L][DEF_MAX_AO_TYPE],
          float_p _aoValsBase[DEF_NAOS_L],
          float_p _ddr1_aoValsBase[DEF_NAOS_L],
          float_p _ddr2_aoValsBase[DEF_NAOS_L] );
void trial_wavefunction_atomicOrbitals_wrapper( const TrialWavefunction_t *_self,
          const size_t _iThread,
          const float_p * _vec,
          const float_p * _sq,
          float_p * _aoVals ) ;
void trial_wavefunction_d1atomicOrbitals( const TrialWavefunction_t *_self,
					  const size_t _iThread,
					  const float_p * _vec,
					  float_p * _aoGrad ) ;
void trial_wavefunction_d2atomicOrbitals( const TrialWavefunction_t *_self,
					  const size_t _iThread,
					  const float_p * _vec,
					  float_p * _aoLapl ) ;

static inline size_t mapAngMomIdx( const size_t iAO_l, const size_t iAO_m ) {
  return 2 * iAO_l + iAO_m ;
}

static inline void mapAngMom( const size_t angMom_l,
		       const size_t angMom_m,
		       size_t angMom[3] ) {

  if( angMom_l == (size_t) S_TYPE ) {
    angMom[0] = 0, angMom[1] = 0, angMom[2] = 0 ;
  } else if( angMom_l == P_TYPE ) {
    switch( angMom_m ) {
    case 0: angMom[0] = 1, angMom[1] = 0, angMom[2] = 0 ; break ;
    case 1: angMom[0] = 0, angMom[1] = 1, angMom[2] = 0 ; break ;
    case 2: angMom[0] = 0, angMom[1] = 0, angMom[2] = 1 ; break ;
    default: handleError( 2, "Unknown m-number when l = 1." ) ; break ;
    }
  } else if( angMom_l == (size_t) D_TYPE ) {
    switch( angMom_m ) {
    case 0: angMom[0] = 2, angMom[1] = 0, angMom[2] = 0 ; break ;
    case 1: angMom[0] = 0, angMom[1] = 2, angMom[2] = 0 ; break ;
    case 2: angMom[0] = 0, angMom[1] = 0, angMom[2] = 2 ; break ;
    case 3: angMom[0] = 1, angMom[1] = 1, angMom[2] = 0 ; break ;
    case 4: angMom[0] = 1, angMom[1] = 0, angMom[2] = 1 ; break ;
    case 5: angMom[0] = 0, angMom[1] = 1, angMom[2] = 1 ; break ;
    default: handleError( 2, "Unknown m-number when l = 2." ) ; break ;
    }
  } else if( angMom_l == (size_t) F_TYPE ) {
    switch( angMom_m ) {
    case 0: angMom[0] = 3, angMom[1] = 0, angMom[2] = 0 ; break ;
    case 1: angMom[0] = 0, angMom[1] = 3, angMom[2] = 0 ; break ;
    case 2: angMom[0] = 0, angMom[1] = 0, angMom[2] = 3 ; break ;
    case 3: angMom[0] = 2, angMom[1] = 1, angMom[2] = 0 ; break ;
    case 4: angMom[0] = 2, angMom[1] = 0, angMom[2] = 1 ; break ;
    case 5: angMom[0] = 1, angMom[1] = 2, angMom[2] = 0 ; break ;
    case 6: angMom[0] = 1, angMom[1] = 1, angMom[2] = 1 ; break ;
    case 7: angMom[0] = 1, angMom[1] = 0, angMom[2] = 2 ; break ;
    case 8: angMom[0] = 0, angMom[1] = 2, angMom[2] = 1 ; break ;
    case 9: angMom[0] = 0, angMom[1] = 1, angMom[2] = 2 ; break ;
    default: handleError( 2, "Unknown m-number when l = 3." ) ; break ;
    }
  } else {
    handleError( 2, "Unknown l-number." ) ;
  }

}


#endif /* #ifndef TRIAL_WAVEFUNCTION_H */
