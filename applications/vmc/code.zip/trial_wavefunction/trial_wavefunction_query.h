/**
 * @file trial_wavefunction_query.h
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Trial Wavefunction getters and setters.
 */

#ifndef TRIAL_WAVEFUNCTION_GAS_H
#define TRIAL_WAVEFUNCTION_GAS_H

// "wave" in hexadecimal
#define MAGIC_WAVE 0x77617665
#define InitMagicWave( tw ) ( tw->magic = MAGIC_WAVE )
#define nMOs( tw, s ) ( s == ALPHA ? ((const TrialWavefunction_t *)(tw))->nMOsAlpha : ((const TrialWavefunction_t *)(tw))->nMOsBeta )
#define nAOs_m( tw ) ( ((const TrialWavefunction_t *)(tw))->nAOs_m )
#define nAOs_l( tw ) ( ((const TrialWavefunction_t *)(tw))->nAOs_l )
#define nAtomTypes( tw ) ( ((const TrialWavefunction_t *)(tw))->nAtomTypes )
#define nCentres( tw ) ( ((const TrialWavefunction_t *)(tw))->nCentres ) 

// The remaining access routines access values which also exist in Ensemble_t
// So, we check the magic number of the "class" before doing the access. Multi-line macros look dreadful, so just write as inline functions
static inline size_t nAlpha( const TrialWavefunction_t * _self ) { assert( _self->magic == MAGIC_WAVE ) ; return _self->nAlpha ; }
static inline size_t nBeta( const TrialWavefunction_t * _self ) { assert( _self->magic == MAGIC_WAVE ) ; return _self->nBeta ; }
static inline size_t nElec( const TrialWavefunction_t * _self ) { assert( _self->magic == MAGIC_WAVE ) ; return _self->nAlpha + _self->nBeta ; }
static inline size_t spin( const TrialWavefunction_t * _self, const size_t _iEl ) { assert( _self->magic == MAGIC_WAVE ) ; return _iEl < _self->nAlpha ? ALPHA : BETA ; }

// =====================================================================
//               Getters and Setters for the data arrays
// =====================================================================

static inline cfloat_p getMOCoeff( const TrialWavefunction_t * _self, const size_t _iSpin, const size_t _iDet, const size_t _iMO,
				   const size_t _iAO ) {

  const cfloat_p * moCoeffs = _iSpin ? _self->moCoeffBeta : _self->moCoeffAlpha ;
  const size_t nMOs = _iSpin ? _self->nMOsBeta : _self->nMOsAlpha ;
  if( _iMO >= nMOs ) { printf( "Molecular orbital index out of bounds in getMOCoeff()." ) ; assert( _iMO < nMOs ) ; }
  if( _iDet >= _self->nDets ) { printf( "Determinant index out of bounds in getMOCoeff()." ) ; assert( _iDet < _self->nDets ) ; } 
  
  return moCoeffs[_iDet * nMOs * _self->nAOs_m + _iMO * _self->nAOs_m + _iAO] ;

}

static inline void setMOCoeff( TrialWavefunction_t * _self, const size_t _iSpin, const size_t _iDet, const size_t _iMO, const size_t _iAO,
			       const cfloat_p val ) {

  cfloat_p * moCoeffs = _iSpin ? _self->moCoeffBeta : _self->moCoeffAlpha ;
  size_t nMOs = _iSpin ? _self->nMOsBeta : _self->nMOsAlpha ;
  if( _iMO >= nMOs ) { printf( "Molecular orbital index out of bounds in getMOCoeff()." ) ; assert( _iMO < nMOs ) ; }
  if( _iDet >= _self->nDets ) { printf( "Determinant index out of bounds in getMOCoeff()." ) ; assert( _iDet < _self->nDets ) ; } 
  
  moCoeffs[_iDet * nMOs * _self->nAOs_m + _iMO * _self->nAOs_m + _iAO] = val ;

}

static inline cfloat_p getMultiRefCoeff( const TrialWavefunction_t * _self, const size_t _iDet ) {

  return _self->multiRefCoeffs[_iDet] ;

}

#endif /* #ifndef TRIAL_WAVEFUNCTION_GAS_H */
