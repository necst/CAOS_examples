/**
 * @file trial_wavefunction.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Trial Wavefunction evaluation routines.
 */
#include <trial_wavefunction/trial_wavefunction.h>
#include <trial_wavefunction/trial_wavefunction_query.h>

static float_p aoValues[NTHREADSMAX*NAOSMAX] ;
static float_p aoGradients[NTHREADSMAX*NAOSMAX*3] ;
static float_p aoLaplacians[NTHREADSMAX*NAOSMAX] ;

/**
 * @brief Compute a row of a Slater matrix in the trial wavefunction. Do so for all Slater matrices
 *        if the trial wavefunction is multireference. Note that this is the most efficient way of doing
 *        the calculation since each of the Slater matrices utilises the same atomic orbital values; it's
 *        just the molecular orbital coefficients which differ.
 * @param[in] _self  : TrialWavefunction_t object.
 * @param[in] _pos   : Position of the electron.
 * @param[in] _iSpin : Spin-state of the electron for the molecular orbital coefficients.
 * @param[in] _wave  : Slater matrix rows we're filling.
 */
void trial_wavefunction_evaluate( const TrialWavefunction_t * _self,
				  const size_t _iThread,
				  const float_p * _vec,
				  const float_p * _sq,
				  const size_t _iSpin,
				  cfloat_p ** _wave ) {

  float_p * aoVals = aoValues + _iThread*NAOSMAX ;
  
  trial_wavefunction_atomicOrbitals_wrapper( _self, _iThread, _vec, _sq, aoVals ) ;

  // Loop over each reference Slater matrix
  for( size_t iDet=0 ; iDet<_self->nDets ; iDet++ ) {

    cfloat_p * row = _wave[iDet] ; assert( row ) ;
    // Zero the array we're storing the Slater matrix elements in
    memset( row, 0, nMOs( _self, _iSpin ) * sizeof(cfloat_p) ) ;

    // Loop over each Molecular Orbital and Atomic Orbital and accumulate the molecular orbital values
    for( size_t iMO=0 ; iMO<nMOs( _self, _iSpin ) ; iMO++ ) {
      for( size_t iAO=0 ; iAO<_self->nAOs_m ; iAO++ ) {

	      cfloat_p moCoeff = getMOCoeff( _self, _iSpin, iDet, iMO, iAO ) ;
	      row[iMO] += moCoeff * (cfloat_p) aoVals[iAO] ; 

      }

    }

  }
  
}

void trial_wavefunction_gradient( const TrialWavefunction_t * _self,
				  const size_t _iThread,
				  const float_p * _vec,
				  const size_t _iSpin,
				  cfloat_p ** _grad ) {

  float_p * aoGrad = aoGradients + _iThread * NAOSMAX * nDims ; 

  // Compute the laplacian of the atomic orbitals 
  trial_wavefunction_d1atomicOrbitals( _self, _iThread, _vec, aoGrad ) ;
  
  // Loop over each reference Slater matrix
  for( size_t iDet=0 ; iDet<_self->nDets ; iDet++ ) {

    cfloat_p * row = _grad[iDet] ; assert( row ) ;

    // Zero the array we're storing the Slater matrix elements in
    czero( row, nDims * nMOs( _self, _iSpin ) ) ;

    // Loop over each Molecular Orbital and Atomic Orbital and accumulate
    // the molecular orbital values
    for( size_t iMO=0 ; iMO<nMOs( _self, _iSpin ) ; iMO++ ) {
      for( size_t iAO=0 ; iAO<_self->nAOs_m ; iAO++ ) {

	      cfloat_p moCoeff = getMOCoeff( _self, _iSpin, iDet, iMO, iAO ) ;
	      row[iMO*nDims]   += moCoeff * (cfloat_p) aoGrad[iAO*nDims] ;
	      row[iMO*nDims+1] += moCoeff * (cfloat_p) aoGrad[iAO*nDims+1] ;
	      row[iMO*nDims+2] += moCoeff * (cfloat_p) aoGrad[iAO*nDims+2] ; 


      }
      
      row[iMO*nDims]   *= _self->multiRefCoeffs[iDet] ;
      row[iMO*nDims+1] *= _self->multiRefCoeffs[iDet] ;
      row[iMO*nDims+2] *= _self->multiRefCoeffs[iDet] ;

    }

  }

}

/**
 * @brief Compute the Laplacian of molecular orbitals with respect to electron position vector.
 * @param[in]  _self  : TrialWavefunction_t object.
 * @param[in]  _pos   : Electron position vector.
 * @param[in]  _iSpin : Spin index.
 * @param[out] _lapl  : Laplacian of the molecular orbitals.
 */
void trial_wavefunction_laplacian( const TrialWavefunction_t * _self,
				   const size_t _iThread,
				   const float_p * _vec,
				   const size_t _iSpin,
				   cfloat_p ** _lapl ) {

  float_p * aoLapl = aoLaplacians + _iThread * NAOSMAX ; 

  // Compute the laplacian of the atomic orbitals 
  trial_wavefunction_d2atomicOrbitals( _self, _iThread, _vec, aoLapl ) ;
  
  // Loop over each reference Slater matrix
  for( size_t iDet=0 ; iDet<_self->nDets ; iDet++ ) {

    cfloat_p * row = _lapl[iDet] ; assert( row ) ;
    // Zero the array we're storing the Slater matrix elements in
    memset( row, 0, nMOs( _self, _iSpin ) * sizeof(cfloat_p) ) ;

    // Loop over each Molecular Orbital and Atomic Orbital and accumulate the molecular orbital values
    for( size_t iMO=0 ; iMO<nMOs( _self, _iSpin ) ; iMO++ ) {
      for( size_t iAO=0 ; iAO<_self->nAOs_m ; iAO++ ) {

	      cfloat_p moCoeff = getMOCoeff( _self, _iSpin, iDet, iMO, iAO ) ;
	      row[iMO] += moCoeff * (cfloat_p) aoLapl[iAO] ; 

      }

      row[iMO] *= _self->multiRefCoeffs[iDet] ;
    }

  }
  
}

