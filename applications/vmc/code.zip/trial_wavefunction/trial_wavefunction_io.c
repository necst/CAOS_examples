/**
 * @file trial_wavefunction_io.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Input/output methods for the TrialWavefunction_t class.
 */
#include <trial_wavefunction/trial_wavefunction.h>
#include <trial_wavefunction/trial_wavefunction_query.h>
#include <sys/stat.h>

/**
 * @brief Print some details about the TrialWavefunction_t object.
 * @param[in] _self : TrialWavefunction_t object.
 */
void trial_wavefunction_print( const TrialWavefunction_t * _self ) {

  printf( " === Trial Wavefunction\n" ) ;
  printf( "     %zu Determinants, %zu Alpha-Spin and %zu Beta-Spin Molecular Orbitals.\n", _self->nDets, _self->nMOsAlpha, _self->nMOsBeta ) ;
  printf( "     Atomic Orbitals: %zu l Quantum Number, %zu m Quantum Number.\n", _self->nAOs_l, _self->nAOs_m ) ;
  printf( "     %zu Atomic Centres and %zu Atom Types.\n", _self->nCentres, _self->nAtomTypes ) ;

  int acc;

  acc = 0 ; printf( "\t.aoCentre/*[%zu]*/ = {\n", _self->nAOs_l ) ;
  for( size_t iAO=0 ; iAO<_self->nAOs_l ; iAO++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%zu", _self->aoCentre[iAO] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.nPrims/*[%zu]*/ = {\n", _self->nAOs_l ) ;
  for( size_t iAO=0 ; iAO<_self->nAOs_l ; iAO++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%zu", _self->nPrims[iAO] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.nAtoms/*[%zu]*/ = {\n", _self->nAOs_l ) ;
  for( size_t iAtomType=0 ; iAtomType<_self->nAtomTypes ; iAtomType++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%zu", _self->nAtoms[iAtomType] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.aoPrimOffset/*[%zu]*/ = {\n", _self->nAOs_l ) ;
  for( size_t iAO=0 ; iAO<_self->nAOs_l ; iAO++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%zu", _self->aoPrimOffset[iAO] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;
  
  acc = 0 ; printf( "\t.nuclearCharge/*[%zu]*/ = {\n", _self->nAtomTypes ) ;
  for( size_t iAtomType=0 ; iAtomType<_self->nAtomTypes ; iAtomType++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%zu", _self->nuclearCharge[iAtomType] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.aoType_l/*[%zu]*/ = {\n", _self->nAOs_l ) ;
  for( size_t iAO=0 ; iAO<_self->nAOs_l ; iAO++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%zu", (size_t)_self->aoType_l[iAO] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.aoNorm/*[%zu]*/ = {\n", _self->nAOs_m ) ;
  for( size_t iAO=0 ; iAO<_self->nAOs_m ; iAO++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%lf", _self->aoNorm[iAO] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.primZeta/*[%zu]*/ = {\n", _self->nPrimsTot ) ;
  for( size_t iPrim=0 ; iPrim<_self->nPrimsTot ; iPrim++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%lf", _self->primZeta[iPrim] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.primCoeff/*[%zu]*/ = {\n", _self->nPrimsTot ) ;
  for( size_t iPrim=0 ; iPrim<_self->nPrimsTot ; iPrim++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%lf", _self->primCoeff[iPrim] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.centre_x/*[%zu]*/ = {\n", _self->nCentres ) ;
  for( size_t iCentre=0 ; iCentre<_self->nCentres ; iCentre++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%lf", _self->centre_x[iCentre] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.centre_y/*[%zu]*/ = {\n", _self->nCentres ) ;
  for( size_t iCentre=0 ; iCentre<_self->nCentres ; iCentre++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%lf", _self->centre_y[iCentre] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.centre_z/*[%zu]*/ = {\n", _self->nCentres ) ;
  for( size_t iCentre=0 ; iCentre<_self->nCentres ; iCentre++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ; 
    printf( "%lf", _self->centre_z[iCentre] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.multiRefCoeffs/*[%zu]*/ = {\n", _self->nDets ) ;
  for( size_t iDet=0 ; iDet<_self->nDets ; iDet++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ;
    printf( "% lf", _self->multiRefCoeffs[iDet] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.moCoeffAlpha/*[%zu]*/ = {\n", _self->nMOsAlpha * _self->nAOs_m ) ;
  for( size_t iCoeff=0 ; iCoeff<_self->nDets * _self->nMOsAlpha * _self->nAOs_m ; iCoeff++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ;
    printf( "% lf", _self->moCoeffAlpha[iCoeff] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

  acc = 0 ; printf( "\t.moCoeffBeta/*[%zu]*/ = {\n", _self->nMOsBeta * _self->nAOs_m ) ;
  for( size_t iCoeff=0 ; iCoeff<_self->nDets * _self->nMOsBeta * _self->nAOs_m ; iCoeff++ ) {
    if( acc == 7 ) { printf( ",\n" ) ; acc = 0 ; }
    acc == 0 ? printf( "\t\t" ) : printf( ",   " ) ;
    printf( "% lf", _self->moCoeffBeta[iCoeff] ) ;
    acc++ ;
  }
  printf( "\n\t},\n" ) ;

}


