FLAGS="-std=c99 -DMINIAPP -DUSESINGLES -DMERSENNE -O3"
SOURCE="utilities/*.c trial_wavefunction/*.c ensemble/*.c mini_vmc.c"
if ! gcc $FLAGS $SOURCE -o mini_vmc.x -I. -lm ; then
    echo "Error: Failed to build mini-app" 
    exit 1
fi

