#ifndef GENERAL_FUNCTIONS_H
#define GENERAL_FUNCTIONS_H

static inline void printSplash( ) {

  printf( "    %s_________  %s____  ____   %s______  %s____  ____  %s________\n", KRED, KYEL, KGRN, KBLU, KMAG ) ;
  printf( "   %s|  _   _  |%s|_  _||_  _|%s.' ___  |%s|_   ||   _|%s|_   __  |\n", KRED, KYEL, KGRN, KBLU, KMAG ) ; 
  printf( "   %s|_/ | | \\_|  %s\\ \\  / / %s/ .'   \\_|  %s| |__| |    %s| |_ \\_|\n", KRED, KYEL, KGRN, KBLU, KMAG ) ;
  printf( "       %s| |       %s\\ \\/ /  %s| |         %s|  __  |    %s|  _| _\n", KRED, KYEL, KGRN, KBLU, KMAG ) ;
  printf( "      %s_| |_      %s_|  |_  %s\\ `.___.'\\ %s_| |  | |_  %s_| |__/ |\n", KRED, KYEL, KGRN, KBLU, KMAG ) ; 
  printf( "     %s|_____|    %s|______|  %s`.____ .'%s|____||____|%s|________|%s\n\n", KRED, KYEL, KGRN, KBLU, KMAG, KNRM ) ;

} 
 
static inline void printTimestamp( ) {

  time_t current_time ;
  char *c_time_string ;

  // Obtain current time
  current_time = time(NULL);

  if( current_time == ((time_t) - 1) ) {
    handleError( 2, "Failed to obtain the current time and date." ) ;
  }

  /* Convert to local time format. */
  c_time_string = ctime( &current_time ) ;

  if( c_time_string == NULL ) {
    handleError( 2, "Failed to convert the current time and date." ) ;
  }
  printf( " === Calculation Timestamp : %s\n", c_time_string ) ;
 
}

static inline void printCalculationTime( const string prepend, double startTime, double endTime ) {

  double calculationTime = endTime - startTime ;
  size_t hours = (size_t) calculationTime / 3600 ; calculationTime -= (double) (hours * 3600) ;
  size_t minutes = (size_t) calculationTime / 60 ; calculationTime -= (double) (minutes * 60) ;
  size_t seconds = (size_t) calculationTime /  1 ; calculationTime -= (double) seconds ;
  size_t milliseconds = (size_t) (calculationTime * 1000) ;
  
  printf( " === %s Calculation Time : %2zu hours, %2zu minutes, %2zu seconds, %3zu milliseconds.\n", prepend, hours, minutes, seconds, milliseconds ) ;

}

static inline void printProgress( const float_p progress ) {

  assert( progress >= 0.0 ) ;

#ifndef SUPRESSPROGRESS
  // We make the width of the progress bar 80 ASCII characters wide
  int barWidth = 80 ;

  // Get the position along the progress bar we're going to be printing
  int position = (int) ( barWidth * progress ) ;

  printf( "     Progress [" ) ;
  // Loop over each position within our progress bar
  for( int iPosition=0 ; iPosition<barWidth ; ++iPosition ) {
    printf( "%s", KGRN ) ;
    // Print an equals sign if we're filling up complete spaces
    if( iPosition < position ) {
      printf( "=" ) ;
    // For the end of the progress bar, print an arrow tip
    } else if( iPosition == position ) {
      printf( ">" ) ;
    // Otherwise we just fill with blank space
    } else {
      printf( " " );
    }
    printf( "%s", KNRM ) ;
  }

  // If we haven't completed, print the percentage completion with a carriage return
  if( progress < 1.0 ) {
    printf( "] %d %%\r", (int) (progress * 100.0) ) ;
  // Otherwise we're done
  } else {
    printf( "] %sDone!%s\n", KGRN, KNRM ) ;
  }

#endif // ifdef PRINTPROGRESS
 
  // Flush the terminal to stop the cursor roaming all over the screen
  fflush( stdout ) ;

}

#endif /* #ifndef GENERAL_FUNCTIONS_H */
