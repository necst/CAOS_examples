/**
 * @file density.h
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Compute the density from a QMC sampling.
 */
#ifndef DENSITY_H
#define DENSITY_H

#include <trial_wavefunction/trial_wavefunction.h>

typedef struct Density {

  size_t * grid ;
  size_t nPoints, nBins ;
  size_t nSamples, nOutOfBounds ;
  float_p boxWidth, dx ;

  void (*initialise)( struct Density * _self,
		      const size_t _nPoints,
		      const float_p _boxWidth ) ;
  void (*destroy)( struct Density * _self ) ;
  size_t (*getBin)( struct Density * _self,
		    const size_t _i,
		    const size_t _j,
		    const size_t _k ) ;
  void (*loadBin)( struct Density * _self,
		   const float_p _x,
		   const float_p _y,
		   const float_p _z ) ;
  void (*printCube)( struct Density * _self,
		     const TrialWavefunction_t * _wave,
		     FILE * _cubeFile ) ;
  
} Density_t ;
typedef Density_t * DensityPtr_t ;

void density_bootstrap( DensityPtr_t _self ) ;
void density_initialise( DensityPtr_t _self,
			 const size_t _nPoints,
			 const float_p _boxWidth ) ;
void density_destroy( DensityPtr_t _self ) ;
size_t density_get_bin( DensityPtr_t _self,
			const size_t _i,
			const size_t _j,
			const size_t _k ) ;
void density_load_bin( DensityPtr_t _self,
		       const float_p _x,
		       const float_p _y,
		       const float_p _z ) ;
void density_print_cube( DensityPtr_t _self,
			 const TrialWavefunction_t * _wave,
			 FILE * _cubeFile ) ;

void aim_initialise( const size_t _bcp_filter_width ) ;
void aim_track_bcp( DensityPtr_t _self ) ;


#endif /* #ifndef DENSITY_H */
