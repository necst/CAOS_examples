#ifndef GENERAL_MATHEMATICS_H
#define GENERAL_MATHEMATICS_H

/**
 * @brief Query whether two arguments are numerically equivalent.
 * @param[in]  _arg_a : First argument.
 * @param[in]  _arg_b : Second argument.
 * @param[out] bool   : Numerically equivalent or not.
 */
static inline bool approx( const float_p _arg_a,
			   const float_p _arg_b ) {

  if( fabs(_arg_a - _arg_b) < TOLERANCE ) {
    return true ;
  } else {
    return false ;
  }
  
}

/**
 * @brief Double factorial function. Recursive, implements:
 *        n!! = 1               if n = 0 or n = 1
 *        n!! = n * (n - 2)!!   if n = 2, 3, etc.
 * @param[in]  n      : Self-explanatory.
 * @param[out] return : n!!
 */
static inline int doubleFac( const int n ) {

  if( n < 0 || n == 0 || n == 1 ) {
    return 1 ;
  } else {
    return doubleFac( n - 2 ) * n ;
  }

}

static inline size_t ceiling( const size_t _num, const size_t _den ) {

  return( (_num + _den / 2) / _den ) ; 

}

static inline void bubbleSort( float_p *pData, const size_t nPoints ) {

  for( size_t iPoint=0 ; iPoint<nPoints-1 ; iPoint++ ) {
    for( size_t jPoint=0 ; jPoint<(nPoints-iPoint-1) ; jPoint++ ){

      if( pData[jPoint] > pData[jPoint+1] ) {
        float_p value = pData[jPoint+1] ;
	      pData[jPoint+1] = pData[jPoint] ; pData[jPoint] = value ;
      }

    }
  }

}

/* Complex functions for various float types */
inline float_p creal_p( const cfloat_p z ) {

  // Assume real so Re[z] = z
  return z ; 

}

inline float_p cimag_p( const cfloat_p z ) {

  // Assume real so Im[z] = 0
  return 0.0*z;

}

inline cfloat_p conj_p( const cfloat_p z ) {

  // Assume it's real so z = z*
  return z ;

}

inline float_p cabs_p( const cfloat_p z ) {

  return z ; // Assume it's real!

}

/**
 * @brief Apply periodic boundary conditions to an interparticle
 *        vector.
 * @param[in,out] _vec_ij     : Interparticle vector. PBCs applied to this.  
 * @param[in]     _box_radius : Half the box width.
 */
static inline void periodic_boundary( float_p * _vec_ij,
			       const float_p * _box_radius ) {

  for( size_t iDim=0 ; iDim<nDims ; iDim++ ) {

    // Query whether we need to apply PBC to the current dimension. Apply
    // if so
    if( fabs( _vec_ij[iDim] ) > _box_radius[iDim] / 2 ) {
      if( _vec_ij[iDim] < 0 ) _vec_ij[iDim] += _box_radius[iDim] / 2 ;
      else _vec_ij[iDim] -= _box_radius[iDim] / 2 ;
    }

  }

}

/**
 * @brief Print a cfloat_p variable appropriately, taking into account if real or complex defined.
 * @param[in]   z : cfloat_p variable to be printed.
 */
inline void print_p( string outStr, const cfloat_p z ) {

  sprintf( outStr, "% f", z ) ;

}

static inline size_t uint_maxVal( const size_t * _array, const size_t _nVals ) {

  size_t maxSoFar = 0 ;
  for( size_t iVal=0 ; iVal<_nVals ; iVal++ ) {
    if( _array[iVal] > maxSoFar ) maxSoFar = _array[iVal] ;
  }

  return maxSoFar ;

}

static inline int int_maxVal( const int * _array, const size_t _nVals ) {

  int maxSoFar = 0 ;
  for( size_t iVal=0 ; iVal<_nVals ; iVal++ ) {
    if( _array[iVal] > maxSoFar ) maxSoFar = _array[iVal] ;
  }

  return maxSoFar ;

}

static inline float_p float_maxVal( const float_p * _array, const size_t _nVals ) {

  float_p maxSoFar = 0 ;
  for( size_t iVal=0 ; iVal<_nVals ; iVal++ ) {
    if( fabs(_array[iVal]) > maxSoFar ) maxSoFar = fabs(_array[iVal]) ;
  }

  return maxSoFar ;

}





#endif /* #ifndef GENERAL_MATHEMATICS_H */
