/**
 * @file random_numbers.h
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Pseudorandom Number generators.
 */
#ifndef RANDOM_NUMBERS_H
#define RANDOM_NUMBERS_H

/**
 * @class SimpleRandom
 * @brief PRNG using POSIX library functions.
 *        Make it thread safe by having each object store it's
 *        current state. So long as they're all initialised with
 *        different seeds, we should be fine.
 */
typedef struct SimpleRandom {

  bool cached ;
  unsigned int state ;
  float_p cachedGaussian ;

  void (*setup)( struct SimpleRandom * _self,
		 const unsigned int _seed ) ;
  float_p (*uniform)( struct SimpleRandom * _self ) ;
  float_p (*gaussian)( struct SimpleRandom * _self,
		       const float_p _sigma ) ;
  
} SimpleRandom_t ;

void simplerandom_bootstrap( SimpleRandom_t * _self ) ;
void simplerandom_setup( SimpleRandom_t * _self,
			 const unsigned int _seed ) ;
float_p simplerandom_uniform( SimpleRandom_t * _self ) ;
float_p simplerandom_gaussian( SimpleRandom_t * _self,
			       const float_p _sigma ) ;

#include <utilities/mersenne_twister.h>

/**
 * @class MersenneTwister
 * @brief PRNG using the original Mersenne Twister (see included file).
 *        Mersenne Twister is just a big LFSR, so naturally thread safe
 *        so long as we initialise each Twister with a different seed.
 */
typedef struct MersenneTwister {

  dsfmt_t dsfmt ;
  double rarray[ ( (DSFMT_MEXP - 128) / 104 + 1 ) * 2 ] ;
  int rsize ;
  double * rptr ;
  
  void (*setup)( struct MersenneTwister * _self,
		 const size_t _seed ) ;
  void (*next)( struct MersenneTwister * _self ) ;
  float_p (*uniform)( struct MersenneTwister * _self ) ;
  float_p (*gaussian)( struct MersenneTwister * _self,
		       const float_p _sigma ) ;
  
} MersenneTwister_t ;

void mersenne_bootstrap( MersenneTwister_t * _self ) ;
void mersenne_setup( MersenneTwister_t * _self,
		     const size_t _seed ) ;
void mersenne_next( MersenneTwister_t * _self ) ;
float_p mersenne_uniform( MersenneTwister_t * _self ) ;
float_p mersenne_gaussian( MersenneTwister_t * _self,
			   const float_p _sigma ) ;

// Define a generic typedef here for the type of PRNG
// we're utilising. We default to the SimpleRandom unless
// the user compiles with -DMERSENNE
typedef MersenneTwister_t Random_t ;

// Our PRNGs reside here, and we subsequently define wrapper
// functions to get the type of random numbers we'll need
Random_t prng[NTHREADSMAX] ;

/**
 * @brief Return a uniform random number from the PRNG on [0,1).
 * @param[in]  _self   : Random_t object.
 * @param[out] float_p : Random number from U[0,1).
 */
static inline float_p uniform( Random_t * _self ) {

  return _self->uniform( _self ) ;
  
}

/**
 * @brief Return a Gaussian random number from the PRNG on N(0,_sigma).
 * @param[in]  _self   : Random_t object.
 * @param[in]  _sigma  : Standard deviation of the distribution.
 * @param[out] float_p : Random number from N(0,_sigma).
 */
static inline float_p gaussian( Random_t * _self, const float_p _sigma ) {

  return _self->gaussian( _self, _sigma ) ;
  
}

/**
 * @brief Return a bimodal Gaussian random number from the PRNG.
 * @param[in]  _self   : Random_t object.
 * @param[in]  _sigma  : Standard deviation of the distribution.
 * @param[out] float_p : Random number from the bimodal distribution.
 */
static inline float_p bimodal_gaussian( Random_t * _self,
					const float_p _sigma ) {
  
  float_p gauss = _self->gaussian( _self, _sigma ) ;
  if( _self->uniform( _self ) > 0.5 ) {
    return gauss ;
  } else {
    return - gauss ;
  }

}

#endif /* #ifndef RANDOM_NUMBERS_H */
