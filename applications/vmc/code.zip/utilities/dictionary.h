#ifndef DICTIONARY_H
#define DICTIONARY_H

typedef struct dictionary * DictionaryPtr_t ;
typedef struct record_ll * RecordPtr_t ;

DictionaryPtr_t dictionary_create( int _size ) ;
void dictionary_destroy( DictionaryPtr_t _dictionary );
void dictionary_insert( DictionaryPtr_t _dictionary,
			const char * _key,
			const char * _value ) ;
const char * dictionary_search( DictionaryPtr_t _dictionary,
				const char * _key ) ;
size_t dictionary_search_unsigned( DictionaryPtr_t _dictionary,
					 const char * _key ) ;
float_p dictionary_search_float( DictionaryPtr_t _dictionary,
				       const char * _key ) ;
void dictionary_delete( DictionaryPtr_t _dictionary,
			const char * _key ) ;

#endif /* #ifdef DICTIONARY_H */
