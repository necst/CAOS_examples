/**
 * @file random_numbers.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Pseudorandom Number generators.
 */
#include <global.h>
#include <utilities/random_numbers.h>

/**
 * @brief Bootstrap the Simple PRNG.
 * @param[in] _self : SimpleRandom_t object.
 */
void simplerandom_bootstrap( SimpleRandom_t * _self ) {

  _self->setup = &simplerandom_setup ;
  _self->uniform = &simplerandom_uniform ;
  _self->gaussian = &simplerandom_gaussian ;
  
}

/**
 * @brief Bootstrap the Mersenne Twister PRNG.
 * @param[in] _self : MersenneTwister_t object.
 */
void mersenne_bootstrap( MersenneTwister_t * _self ) {

  _self->setup = &mersenne_setup ;
  _self->next = &mersenne_next ;
  _self->uniform = &mersenne_uniform ;
  _self->gaussian = &mersenne_gaussian ;
  
}

/**
 * @brief Setup and seed the Simple PRNG.
 * @param[in] _self : SimpleRandom_t object.
 * @param[in] _seed : Seeding integer for the PRNG.
 */
void simplerandom_setup( SimpleRandom_t * _self, const unsigned int _seed ) {

  _self->cached = false ;
  _self->state = _seed ;
  rand_r( &_self->state ) ;

}
  
/**
 * @brief Setup and seed the Mersenne Twister PRNG.
 * @param[in] _self : MersenneTwister_t object.
 * @param[in] _seed : Seeding integer for the PRNG.
 */
void mersenne_setup( MersenneTwister_t * _self, const size_t _seed ) {

  _self->rsize = sizeof( _self->rarray ) / sizeof( *(_self->rarray) ) ;

  dsfmt_init_gen_rand( &(_self->dsfmt), (uint32_t) _seed ) ;
  _self->next( _self ) ;
  
}

/**
 * @brief Fill the LSFR with random numbers.
 * @param[in] _self : MersenneTwister_t object.
 */
void mersenne_next( MersenneTwister_t * _self ) {

  // Fill rarray with rsize pseudorandom floats on (0,1)
  dsfmt_fill_array_open_open( &_self->dsfmt, _self->rarray, _self->rsize ) ;
  // Point to the first element of the array
  _self->rptr = _self->rarray ;

}

/**
 * @brief Return a random number on [0,1).
 * @param[in]  _self   : SimpleRandom_t object.
 * @param[out] float_p : Uniform random number.
 */
float_p simplerandom_uniform( SimpleRandom_t * _self ) {

  return (float_p) rand_r( &_self->state ) / (float_p) RAND_MAX ;

}

/**
 * @brief Return a random number on [0,1).
 * @param[in]  _self   : MersenneTwister_t object.
 * @param[out] float_p : Uniform random number.
 */
float_p mersenne_uniform( MersenneTwister_t * _self ) {

  double d ;

#ifdef BE_ASSERTIVE
  assert( _self->rptr >= _self->rarray ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  if( _self->rptr >= (_self->rarray + _self->rsize) ) {
    _self->next( _self ) ;
  }

  d = *_self->rptr++ ;

#ifdef BE_ASSERTIVE
  assert( d >= 0 && d <= 1 ) ;
#endif /* #ifdef BE_ASSERTIVE */

  return (float_p) d ;
  
}

/**
 * @brief Return a random number on N( 0, _sigma ) from the Simple PRNG.
 *        Since we use Box-Muller, we cache the second random number we generate
 *        which can be returned immediately on the subsequent call to this function.
 * @param[in]  _self   : SimpleRandom_t object.
 * @param[in]  _sigma  : Standard deviation.
 * @param[out] float_p : Gaussian random number.
 */
float_p simplerandom_gaussian( SimpleRandom_t * _self, const float_p _sigma ) {

  if( _self->cached ) {
    _self->cached = false ;
    return _self->cachedGaussian * _sigma ;
  } else {
    float_p w, x, y ;  
    do {
      x = _self->uniform( _self ) ;
      y = _self->uniform( _self ) ;

      x *= 2.0 ; x -= 1.0 ;
      y *= 2.0 ; y -= 1.0 ;
      w = x * x + y * y ;
    } while ( w >= 1.0 ) ;

    w = sqrt( ( -2.0 * log( w ) ) / w ) ;
    _self->cached = true ;
    _self->cachedGaussian = y * w ;

    return x * w * _sigma ;
  }

}

/**
 * @brief Return a random number on N( 0, _sigma ) from the Mersenne PRNG.
 * @param[in]  _self   : SimpleRandom_t object.
 * @param[in]  _sigma  : Standard deviation.
 * @param[out] float_p : Gaussian random number.
 */
float_p mersenne_gaussian( MersenneTwister_t *_self, const float_p _sigma ) {

  double d = 0 ; int nRands = 12 ;

  for( int i=0 ; i<nRands ; i++ ) {
    d += _self->uniform( _self ) ;
  }

  d -= nRands / 2.0 ;
  d *= _sigma / sqrt( nRands/12.0 ) ;

  return (float_p) d ;

}
