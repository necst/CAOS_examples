/**
 * @file density.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Compute the density from a QMC sampling.
 */
#include <utilities/density.h>
#include <trial_wavefunction/trial_wavefunction_query.h>

/**
 * @brief Bootstrap a Density_t object.
 * @param[in] _self : Density_t object.
 */
void density_bootstrap( DensityPtr_t _self ) {

  _self->initialise = &density_initialise ;
  _self->destroy = &density_destroy ;
  _self->getBin = &density_get_bin ;
  _self->loadBin = &density_load_bin ;
  _self->printCube = &density_print_cube ;

}

/**
 * @brief Initialise the cubic density grid.
 * @param[in] _self : Density_t object.
 * @param[in] _nPoints  : Number of points to bin each dimension with.
 * @param[in] _boxWidth : Width of the box in Bohrs.
 */
void density_initialise( DensityPtr_t _self,
			 const size_t _nPoints,
			 const float_p _boxWidth ) {

  _self->nPoints = _nPoints ;
  _self->nBins = _self->nPoints * _self->nPoints * _self->nPoints ;
  _self->boxWidth = _boxWidth ;
  _self->dx = _self->boxWidth / (float_p) _self->nPoints ;
  _self->grid = (size_t *) calloc( _self->nBins, sizeof(size_t) ) ;

  printf( " === Loading density grid.\n" ) ;
  printf( "     %zu points in each dimension (%zu bins). Bin width of %f Bohrs.\n",
	  _self->nPoints, _self->nBins, _self->dx ) ;
  
}

/**
 * @brief Destroy the cubic density grid.
 * @param[in] _self : Density_t object.
 */
void density_destroy( DensityPtr_t _self ) {

  free( _self->grid ) ;
  printf( "     %zu points were binned, %zu points were out-of-bounds.\n",
	  _self->nSamples, _self->nOutOfBounds ) ;
  
}

/**
 * @brief Get the flattened bin index for the grid.
 * @param[in] _self   : Density_t object.
 * @param[in]  _i     : First dimension index.
 * @param[in]  _j     : Second dimension index.
 * @param[in]  _k     : Third dimension index.
 * @param[out] size_t : The grid index.
 */
size_t density_get_bin( DensityPtr_t _self,
			const size_t _i,
			const size_t _j,
			const size_t _k ) {

  return ( _i * _self->nPoints + _j ) * _self->nPoints + _k ;

}

/**
 * @brief Add a sample to the relevant bin.
 *        If the sample point is out of bounds, just skip.
 * @param[in] _self : Density_t object.
 * @param[in] _x    : First dimension sample position.
 * @param[in] _y    : Second dimension sample position.
 * @param[in] _z    : Third dimension sample position.
 */
void density_load_bin( DensityPtr_t _self,
		       const float_p _x,
		       const float_p _y,
		       const float_p _z ) {

  int grid_x = (int) ( (_x + _self->boxWidth / 2.0) / _self->dx ) ;
  int grid_y = (int) ( (_y + _self->boxWidth / 2.0) / _self->dx ) ;
  int grid_z = (int) ( (_z + _self->boxWidth / 2.0) / _self->dx ) ;

  if( grid_x >= (int) _self->nPoints || grid_y >= (int) _self->nPoints || grid_z >= (int) _self->nPoints ||
      grid_x < 0              || grid_y < 0              || grid_z < 0 ) {
    _self->nOutOfBounds += 1 ;
  } else {
    size_t index = _self->getBin( _self, (size_t) grid_x, (size_t) grid_y, (size_t) grid_z ) ;
    _self->grid[index]++, _self->nSamples++ ;
  }
  
}


/**
 * @brief Print the .cube file with the grid. We "normalise" so that the sum of
 *        each bin gives the number of electrons.
 * @param[in] _self     : Density_t object.
 * @param[in] _wave     : TrialWavefunction_t object.
 * @param[in] _cubeFile : File to dump the cube to.
 */
void density_print_cube( DensityPtr_t _self,
			 const TrialWavefunction_t * _wave,
			 FILE * _cubeFile ) {

  size_t jAtom = 0 ; float_p zero = 0.0 ;

  fprintf( _cubeFile, "                               === Tyche Cube File ===\n" ) ;
  fprintf( _cubeFile, " %3zu x %3zu x %3zu grid, with bin width of %5.3f Bohrs. Binning success rate: %5.3f\n",
           _self->nPoints, _self->nPoints, _self->nPoints, _self->dx,
	   (float_p) _self->nSamples / (float_p) (_self->nSamples + _self->nOutOfBounds) 
         ) ;

  fprintf( _cubeFile, "%3zu %12.8f %12.8f %12.8f %10zu\n",
	   _wave->nCentres, zero, zero, zero, _self->nBins ) ;
  fprintf( _cubeFile, "%3zu %12.8f %12.8f %12.8f\n",
	   _self->nPoints, _self->dx, zero, zero ) ;
  fprintf( _cubeFile, "%3zu %12.8f %12.8f %12.8f\n",
	   _self->nPoints, zero, _self->dx, zero ) ;
  fprintf( _cubeFile, "%3zu %12.8f %12.8f %12.8f\n",
	   _self->nPoints, zero, zero, _self->dx ) ;

  for( size_t iAtomType=0 ; iAtomType<_wave->nAtomTypes ; iAtomType++ ) {
    for( size_t iAtom=0 ; iAtom<_wave->nAtoms[iAtomType] ; iAtom++ ) {
      fprintf( _cubeFile, "%3zu %12.8f %12.8f %12.8f %12.8f\n", 
	       _wave->nuclearCharge[iAtomType], zero,
	       _wave->centre_x[jAtom],
	       _wave->centre_y[jAtom],
	       _wave->centre_z[jAtom]
	     ) ;
      jAtom++ ;
    }
  }
  float_p divisor = (float_p) nElec( _wave ) / (float_p) _self->nSamples ;
  for( size_t ix=0 ; ix<_self->nPoints ; ix++ ) {
    for( size_t iy=0 ; iy<_self->nPoints ; iy++ ) {
      for( size_t iz=0 ; iz<_self->nPoints ; iz++ ) {
	size_t index = _self->getBin( _self, ix, iy, iz ) ;
	fprintf( _cubeFile, "%12.8f   ", (float_p) _self->grid[index] * divisor ) ;
	if( index % 6 == 5 ) fprintf( _cubeFile, "\n" ) ;
      }
    }
  }
  
}
