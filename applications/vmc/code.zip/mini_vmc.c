/**
 * @file mini_vmc.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Minimal Variational Monte Carlo for prototyping integration of other
 *        codebases or projects.
 * @note Requires that Ensemble_t and TrialWavefunction_t have been dumped to configuration
 *       files in include/.
 * @note While we utilise function pointers to resemble class methods, all routine names
 *       should be in scope.
 */
#define MAIN

#define MAXSTEPS 10000

#include <global.h>
#include <trial_wavefunction/trial_wavefunction.h>
#include <ensemble/ensemble.h>
#include <ensemble/ensemble_query.h>

/**
 * @brief Entry point for the miniapp.
 * @param[in]  argc : Number of arguments passed at runtime.
 * @param[in]  argv : List of arguments passed at runtime.
 * @param[out] int  : 0 on success.
 */
int main( int argc, char * argv[] ) {

  printf( " === Mini VMC begins.\n" ) ;

  // Get the runtime arguments and check they're not invalid
  size_t nSteps = strtoul( argv[1], NULL, 0 ) ;
  float_p dx = strtof( argv[2], NULL ) ;
  
  float_p average = 0, stddev = 0 ;
  float_p energies[MAXSTEPS] = { 0 } ;
  int fiftyPercentAcceptance = (int) (0.5 * nWalkers( &ensemble ) * nElec( &ensemble )) ;

  mersenne_bootstrap( prng ) ; prng->setup( prng, 137 ) ;
  
  // Initialise methods for the objects
  trial_wavefunction_initialise( &trial_wavefunction ) ; ensemble_initialise( &ensemble ) ;
  ensemble_set_distance_tables( &ensemble, &trial_wavefunction, 0 ) ;

  printf( " === %zu Walkers will be utilised.\n", nWalkers( &ensemble ) ) ;

  printf( " === Equilibrating... " ) ;
  for( size_t iStep=0 ; iStep<nSteps/2 ; iStep++ ) {

    int nAccept = 0 ;

    // Since OpenMP is a luxury in the CAOS world, going to have to make the code pretty ugly with
    // these preprocessor directives
    // The method names should all be pretty descriptive. I'll forgive myself for
    // not commenting much
    for( size_t iWalker=0 ; iWalker<nWalkers( &ensemble ) ; iWalker++ ) {

      int tid = 0 ;

      ensemble.copyTemp( &ensemble, &trial_wavefunction, tid, iWalker, "EnsembleToTemp" ) ;

      for( size_t iEl=0 ; iEl<nElec( &ensemble ) ; iEl++ ) {
	ensemble.displace( &ensemble, &trial_wavefunction, tid, iEl, dx ) ;
	ensemble.deltaSlater( &ensemble, &trial_wavefunction, tid, iWalker, iEl ) ;
	// calculateAcceptance() handles all trial energy update and ensemble/temporary walker memory management
	nAccept += ensemble.metropolis( &ensemble, &trial_wavefunction, tid, iWalker, iEl, 1.0 ) ;
      }

    }

    // Do some really rudimentary step size updating to aim for 50% acceptance
    if( nAccept < fiftyPercentAcceptance ) dx *= 0.999 ; 
    if( nAccept > fiftyPercentAcceptance ) dx *= 1.001 ; 

  }
  printf( "Done!\n" ) ;

  printf( " === dx has been set to %f after equilibration.\n", dx ) ;

  printf( " === Production Run... " ) ;
  // Main loop over VMC timesteps
  for( size_t iStep=0 ; iStep<nSteps ; iStep++ ) {

    float_p trialEnergy = 0 ; int nAccept = 0 ;

    for( size_t iWalker=0 ; iWalker<nWalkers( &ensemble ) ; iWalker++ ) {

      int tid = 0 ;
      
      ensemble.copyTemp( &ensemble, &trial_wavefunction, tid, iWalker, "EnsembleToTemp" ) ;
      for( size_t iEl=0 ; iEl<nElec( &ensemble ) ; iEl++ ) {
	ensemble.displace( &ensemble, &trial_wavefunction, tid, iEl, dx ) ;
	ensemble.deltaSlater( &ensemble, &trial_wavefunction, tid, iWalker, iEl ) ;
	// calculateAcceptance() handles all trial energy update and ensemble/temporary walker memory management
	nAccept += ensemble.metropolis( &ensemble, &trial_wavefunction, tid, iWalker, iEl, 1.0 ) ;
	trialEnergy += getLocalEnergy( &ensemble, iWalker ) ;
      }
      
    }
    
    // We just do basic statistics with the trial energy in this miniapp
    energies[iStep] = trialEnergy / (float_p) (nWalkers( &ensemble ) * nElec( &ensemble )) ;
    average += energies[iStep] / (float_p) ( nSteps ) ;

  }
  printf( "Done!\n" ) ;

  // Compute the variance and report. Then we're all done
  float_p variance = 0 ;
  for( size_t iStep=0 ; iStep<nSteps ; iStep++ ) {
    variance += ( energies[iStep] - average ) * ( energies[iStep] - average ) ;
  }
  variance /= (float_p) ( nSteps * (nSteps - 1) ) ;
  printf( " === Mean Trial Energy : %f   Variance : %f\n", average, variance ) ;
  printf( " === Mini VMC ends.\n" ) ;

  return 0 ;
  
}
