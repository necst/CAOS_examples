/**
 * @file   global.h
 * @author Salvatore Cardamone
 * @brief  Global variables, types and includes. Try to minimise what goes 
 *         in here.
 */
#ifndef GLOBAL_H
#define GLOBAL_H

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <complex.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/types.h>
#include <dirent.h>

// M_PI was dropped in C99 as C compilers aren't allowed to introduce constants
// (name isn't reserved)
// See https://stackoverflow.com/questions/29264462/m-pi-not-available-with-gcc-std-c11-but-with-std-gnu11
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define NTHREADSMAX 8

// Floating point types and associated numerical tolerance
typedef float float_p ;
typedef float cfloat_p ;
#define TOLERANCE 1.0E-04

// Save ourselves allocating memory for strings every five seconds
typedef char string[256] ;
// Number of dimensions of real space.
static const size_t nDims = 3 ;

// Include these after our typedefs so we can utilise
#include <panic.h>
#include <utilities/random_numbers.h>
#include <utilities/general_mathematics.h>
#include <utilities/general_functions.h>

// Some exploratory features
#ifdef BE_EXPLORATORY
#include <utilities/fixed.h>
#include <utilities/value_track.h>
#endif /* #ifdef BE_EXPLORATORY */

// The command line argument passed to tyche on execution. Where all input
//files are stored
char input_path[200] ;

/**
 * @brief Print to stdout and flush right away.
 * @brief[in] format : Variadic arguments for printf.
 */
static inline void print( const char * _format, ... ) { 
  va_list arg ;
  va_start( arg, _format ) ;
  vfprintf( stdout, _format, arg ) ;
  va_end( arg ) ; fflush( stdout ) ;
}

static inline size_t memcopy( void * _dest, void * _source,
			      const size_t _nBytes ) {

  if( ! _nBytes ) {
    printf( "memcopy() can't take _nBytes = 0.\n" ) ;
    exit( EXIT_FAILURE ) ;
  }
  if( ! _dest || ! _source ) return 1 ;

  memcpy( _dest, _source, _nBytes ) ;

  return 0 ;

}

static inline void zero( float_p * _vec, const size_t _nVals ) {

  for( size_t iVal=0 ; iVal<_nVals ; iVal++ ) _vec[iVal] = 0.0 ;

}

static inline void czero( cfloat_p * _vec, const size_t _nVals ) {

  for( size_t iVal=0 ; iVal<_nVals ; iVal++ ) _vec[iVal] = 0.0 ;

}

#endif /* #ifndef GLOBAL_H */
