#ifndef TRIAL_WAVEFUNCTION_DUMP
#define TRIAL_WAVEFUNCTION_DUMP

typedef struct TrialWavefunction {

	size_t magic ; int type ;
	size_t nElec, nAlpha, nBeta ;
	size_t nDets, nMOsAlpha, nMOsBeta, nCentres ;
	size_t nAtomTypes, nAOs_l, nAOs_m, nPrimsTot ;
	size_t aoCentre[6], nPrims[6], nAtoms[1], aoPrimOffset[6], nuclearCharge[1] ;
	int aoType_l[6] ;
	float_p primZeta[60], primCoeff[60], aoNorm[10] ;
	float_p centre_x[2], centre_y[2], centre_z[2] ;
	cfloat_p multiRefCoeffs[1], moCoeffAlpha[40], moCoeffBeta[40] ;
	float_p nuclearRepulsion ;

	void (*print)( const struct TrialWavefunction * _self ) ;
	void (*evaluate)( const struct TrialWavefunction * _self, const size_t _iThread, const float_p * _vec, const float_p * _sq, const size_t _iSpin, cfloat_p ** _wave ) ;
	void (*gradient)( const struct TrialWavefunction * _self, const size_t _iThread, const float_p * _vec, const size_t _iSpin, cfloat_p ** _grad ) ;
	void (*laplacian)( const struct TrialWavefunction * _self, const size_t _iThread, const float_p * _vec, const size_t _iSpin, cfloat_p ** _lap ) ;

} TrialWavefunction_t ;

#ifdef MAIN
TrialWavefunction_t trial_wavefunction = {

	.magic = 2002876005, .type = 0,
	.nDets = 1, .nMOsAlpha = 4, .nMOsBeta = 4, .nCentres = 2,
	.nAtomTypes = 1, .nAOs_l = 6, .nAOs_m = 10, .nPrimsTot = 60,
	.aoCentre/*[6]*/ = {
		0,   0,   0,   1,   1,   1
	},
	.nPrims/*[6]*/ = {
		6,   6,   6,   6,   6,   6
	},
	.nAtoms/*[6]*/ = {
		2
	},
	.aoPrimOffset/*[6]*/ = {
		0,   6,   12,   0,   6,   12
	},
	.nuclearCharge/*[1]*/ = {
		4
	},
	.aoType_l/*[6]*/ = {
		1,   1,   3,   1,   1,   3
	},
	.aoNorm/*[10]*/ = {
		0X1.FFFFF269B9EF1P-1,   0X1.0000033AFB698P+0,   0X1.0000052325E66P+0,   0X1.0000052325E66P+0,   0X1.0000052325E66P+0,   0X1.FFFFF269B9EF1P-1,   0X1.0000033AFB698P+0,
		0X1.0000052325E66P+0,   0X1.0000052325E66P+0,   0X1.0000052325E66P+0
	},
	.primZeta/*[60]*/ = {
		0X1.38DEB851EB852P+8,   0X1.CAEA7EF9DB22DP+5,   0X1.00C6A7EF9DB23P+4,   0X1.60D6A161E4F76P+2,   0X1.120902DE00D1BP+1,   0X1.C3734B51372A4P-1,   0X1.B4432CA57A787P+3,
		0X1.5964840E1719FP+1,   0X1.AD63ED0F62739P-1,   0X1.4A67620EE8D11P-2,   0X1.1EFD00713F078P-3,   0X1.0718A86D71F36P-4,   0X1.B4432CA57A787P+3,   0X1.5964840E1719FP+1,
		0X1.AD63ED0F62739P-1,   0X1.4A67620EE8D11P-2,   0X1.1EFD00713F078P-3,   0X1.0718A86D71F36P-4,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0
	},
	.primCoeff/*[60]*/ = {
		0X1.F181C49F1F8F5P-2,   0X1.7772E9B0D4EFEP-1,   0X1.ED1F0AB2CB552P-1,   0X1.E681C4963A6BBP-1,   0X1.0CFD1A2194325P-1,   0X1.5A345EFFB84C3P-4,   -0X1.127D5C670A21FP-4,
		-0X1.20D06ED358208P-4,   -0X1.59BCAA422DEBDP-6,   0X1.38BE7BA767831P-4,   0X1.8DE631C3AE6A3P-4,   0X1.669E6A6A0EFE8P-6,   0X1.1F858828D56D2P-3,   0X1.7C692E0A8753EP-3,
		0X1.976AF5A9CC0F2P-3,   0X1.28C44505EDFFCP-3,   0X1.AA59320C84BCEP-5,   0X1.333BCB20FF3A8P-8,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0,
		0X0P+0,   0X0P+0,   0X0P+0,   0X0P+0
	},
	.centre_x/*[2]*/ = {
		0X0P+0,   0X0P+0
	},
	.centre_y/*[2]*/ = {
		0X0P+0,   0X0P+0
	},
	.centre_z/*[2]*/ = {
		0X1.A9895CE080B3CP+1,   -0X1.A9895CE080B3CP+1
	},
	.multiRefCoeffs/*[1]*/ = {
		0X1P+0
	},
	.moCoeffAlpha/*[40]*/ = {
		0X1.9694D850B573P-3,   0X1.DE98773A92E38P-9,   0X0P+0,   0X0P+0,   -0X1.171D20141A53P-11,   -0X1.9694D850B573P-3,   -0X1.DE98773A92E38P-9,
		0X0P+0,   0X0P+0,   -0X1.171D20141A53P-11,   0X1.96C0A572A5EFDP-3,   0X1.A8B38255DFA06P-9,   0X0P+0,   0X0P+0,
		0X1.2BE3593D27F9FP-12,   0X1.96C0A572A5EFDP-3,   0X1.A8B38255DFA06P-9,   0X0P+0,   0X0P+0,   -0X1.2BE3593D27F9FP-12,   -0X1.BB807AD2C4B48P-5,
		0X1.93A6D05E5BBBDP-3,   0X0P+0,   0X0P+0,   -0X1.2E737AC9E94E5P-6,   -0X1.BB807AD2C4B48P-5,   0X1.93A6D05E5BBBDP-3,   0X0P+0,
		0X0P+0,   0X1.2E737AC9E94E5P-6,   -0X1.D30096E0BAF04P-5,   0X1.B47DC7271D1E1P-3,   0X0P+0,   0X0P+0,   0X1.726DD97DB22A7P-6,
		0X1.D30096E0BAF04P-5,   -0X1.B47DC7271D1E1P-3,   0X0P+0,   0X0P+0,   0X1.726DD97DB22A7P-6
	},
	.moCoeffBeta/*[40]*/ = {
		0X1.9694D850B573P-3,   0X1.DE98773A92E38P-9,   0X0P+0,   0X0P+0,   -0X1.171D20141A53P-11,   -0X1.9694D850B573P-3,   -0X1.DE98773A92E38P-9,
		0X0P+0,   0X0P+0,   -0X1.171D20141A53P-11,   0X1.96C0A572A5EFDP-3,   0X1.A8B38255DFA06P-9,   0X0P+0,   0X0P+0,
		0X1.2BE3593D27F9FP-12,   0X1.96C0A572A5EFDP-3,   0X1.A8B38255DFA06P-9,   0X0P+0,   0X0P+0,   -0X1.2BE3593D27F9FP-12,   -0X1.BB807AD2C4B48P-5,
		0X1.93A6D05E5BBBDP-3,   0X0P+0,   0X0P+0,   -0X1.2E737AC9E94E5P-6,   -0X1.BB807AD2C4B48P-5,   0X1.93A6D05E5BBBDP-3,   0X0P+0,
		0X0P+0,   0X1.2E737AC9E94E5P-6,   -0X1.D30096E0BAF04P-5,   0X1.B47DC7271D1E1P-3,   0X0P+0,   0X0P+0,   0X1.726DD97DB22A7P-6,
		0X1.D30096E0BAF04P-5,   -0X1.B47DC7271D1E1P-3,   0X0P+0,   0X0P+0,   0X1.726DD97DB22A7P-6
	},
	.nuclearRepulsion = 0X1.34040D4D4929AP+1,

	.print = NULL,
	.evaluate = NULL,
	.gradient = NULL,
	.laplacian = NULL

} ; 
#endif /* #ifdef MAIN */

#define DEF_NAOS_L 6

#define DEF_MAX_AO_TYPE 3

#define DEF_MAX_NPRIMS 6

#endif /* #ifndef TRIAL_WAVEFUNCTION_DUMP */
