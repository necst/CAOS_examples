/**
 * @file ensemble_io.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Methods for ensemble IO. 
 */
#include <dirent.h>
#include <ensemble/ensemble.h>
#include <ensemble/ensemble_query.h>

/**
 * @brief Print a walker's data from the ensemble.
 * @param[in] _self    : Ensemble_t object.
 * @param[in] _iWalker : Walker index.
 */
void ensemble_print_walker( const Ensemble_t * _self,
			    const size_t _iWalker ) {

#ifdef BE_ASSERTIVE
  assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  printf( " === Walker %5zu   Kinetic: %12.8f   Potential: %12.8f\n",
	  _iWalker, * getKineticEnergy( _self, _iWalker ),
	  * getPotentialEnergy( _self, _iWalker ) ) ;
  printf( "                    Weight: %12.8f    Local Energy: %12.8f\n", 
          * getWeight( _self, _iWalker ), getLocalEnergy( _self, _iWalker ) ) ;
  printf( "     %3zu Det(s), %3zu Alpha-Electron(s), %3zu Beta-Electron(s)\n",
	  nDets( _self ), nAlpha( _self ), nBeta( _self ) ) ;

  // Electrons
  printf( "     Electron Position Vectors:\n" ) ;
  float_p * electrons = getElectron( _self, _iWalker, 0 ) ;
  for( size_t iEl=0 ; iEl<nElec( _self ) ; iEl++ ) {
    printf( "     %3zu : %12.8f %12.8f %12.8f\n",
	    iEl, electrons[iEl*3], electrons[iEl*3+1], electrons[iEl*3+2] ) ;
  }

  // Slater Matrices
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    printf( "     Alpha-Spin Slater Matrix %3zu   Determinant Value : %18.15f\n",
	    iDet, * getDeterminants( _self, _iWalker, iDet, ALPHA ) ) ; 
    cfloat_p * slater = getMatrix( _self, _iWalker, iDet, ALPHA ) ;
    for( size_t iEl=0 ; iEl<nAlpha( _self ) ; iEl++ ) {
      printf( "     " ) ;
      for( size_t iMO=0 ; iMO<nAlpha( _self ) ; iMO++ ) {
	      printf( "% 12.8f ", slater[iEl*nAlpha( _self ) + iMO] ) ;
      }
      printf( "\n" ) ;
    }
  }
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    printf( "     Beta-Spin Slater Matrix %3zu   Determinant Value : %18.15f\n",
	    iDet, * getDeterminants( _self, _iWalker, iDet, BETA ) ) ; 
    cfloat_p * slater = getMatrix( _self, _iWalker, iDet, BETA ) ;
    for( size_t iEl=0 ; iEl<nBeta( _self ) ; iEl++ ) {
      printf( "     " ) ;
      for( size_t iMO=0 ; iMO<nBeta( _self ) ; iMO++ ) {
	      printf( "% 12.8f ", slater[iEl*nBeta( _self ) + iMO] ) ;
      }
      printf( "\n" ) ;
    }
  }

  // Inverse Matrices
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    printf( "     Alpha-Spin Inverse Matrix %3zu\n", iDet ) ; 
    cfloat_p * inverse = getInverse( _self, _iWalker, iDet, ALPHA ) ;
    for( size_t iEl=0 ; iEl<nAlpha( _self ) ; iEl++ ) {
      printf( "     " ) ;
      for( size_t iMO=0 ; iMO<nAlpha( _self ) ; iMO++ ) {
	      printf( "% 12.8f ", inverse[iEl*nAlpha( _self ) + iMO] ) ;
      }
      printf( "\n" ) ;
    }
  }

  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    printf( "     Beta-Spin Inverse Matrix %3zu\n", iDet ) ; 
    cfloat_p * inverse = getInverse( _self, _iWalker, iDet, BETA ) ;
    for( size_t iEl=0 ; iEl<nBeta( _self ) ; iEl++ ) {
      printf( "     " ) ;
      for( size_t iMO=0 ; iMO<nBeta( _self ) ; iMO++ ) {
	      printf( "% 12.8f ", inverse[iEl*nBeta( _self ) + iMO] ) ;
      }
      printf( "\n" ) ;
    }
  }

  printf( "     Alpha Inverse Check : " ) ;
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    if( ! checkIdentity( _self, _iWalker, ALPHA ) ) {
        printf( "%zu  ", iDet ) ;
     } else {
       exit( EXIT_FAILURE ) ;
     }
  }
  printf( "Clear!\n" ) ;
  printf( "     Beta Inverse Check  : " ) ;
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
     if( ! checkIdentity( _self, _iWalker, BETA ) ) {
        printf( "%zu  ", iDet ) ;
     } else {
       exit( EXIT_FAILURE ) ;
     }
  }
  printf( "Clear!\n" ) ;

  fflush( stdout ) ;
  
}

void ensemble_print_temp( const Ensemble_t * _self, const size_t _iThread ) {

  printf( " === Temporary Walker %5zu   Kinetic: %12.8f   Potential: %12.8f\n", 
	  _iThread, * getTempKineticEnergy( _self, _iThread ),
	  * getTempPotentialEnergy( _self, _iThread ) ) ;
  printf( "     %3zu Det(s), %3zu Alpha-Electron(s), %3zu Beta-Electron(s)\n",
	  nDets( _self ), nAlpha( _self ), nBeta( _self ) ) ;

  // Electrons
  printf( "     Electron Position Vectors:\n" ) ;
  float_p * electrons = getTempElectron( _self, _iThread, 0 ) ;
  for( size_t iEl=0 ; iEl<nElec( _self ) ; iEl++ ) {
    printf( "     %3zu : %12.8f %12.8f %12.8f\n",
	    iEl, electrons[iEl*3], electrons[iEl*3+1], electrons[iEl*3+2] ) ;
  }

  // Slater Matrices
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    printf( "     Alpha-Spin Slater Matrix %3zu   Determinant Value : %18.15f\n",
	    iDet, getTempDeterminants( _self, _iThread, ALPHA )[0] ) ; 
    cfloat_p * slater = getTempMatrix( _self, _iThread, iDet, ALPHA ) ;
    for( size_t iEl=0 ; iEl<nAlpha( _self ) ; iEl++ ) {
      printf( "     " ) ;
      for( size_t iMO=0 ; iMO<nAlpha( _self ) ; iMO++ ) {
	      printf( "% 12.8f ", slater[iEl*nAlpha( _self ) + iMO] ) ;
      }
      printf( "\n" ) ;
    }
  }
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    printf( "     Beta-Spin Slater Matrix %3zu   Determinant Value : %18.15f\n",
	    iDet, getTempDeterminants( _self, _iThread, BETA )[0] ) ; 
    cfloat_p * slater = getTempMatrix( _self, _iThread, iDet, BETA ) ;
    for( size_t iEl=0 ; iEl<nBeta( _self ) ; iEl++ ) {
      printf( "     " ) ;
      for( size_t iMO=0 ; iMO<nBeta( _self ) ; iMO++ ) {
	      printf( "% 12.8f ", slater[iEl*nBeta( _self ) + iMO] ) ;
      }
      printf( "\n" ) ;
    }
  }

  // Inverse Matrices
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    printf( "     Alpha-Spin Inverse Matrix %3zu\n", iDet ) ; 
    cfloat_p * inverse = getTempInverse( _self, _iThread, iDet, ALPHA ) ;
    for( size_t iEl=0 ; iEl<nAlpha( _self ) ; iEl++ ) {
      printf( "     " ) ;
      for( size_t iMO=0 ; iMO<nAlpha( _self ) ; iMO++ ) {
	      printf( "% 12.8f ", inverse[iEl*nAlpha( _self ) + iMO] ) ;
      }
      printf( "\n" ) ;
    }
  }

  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    printf( "     Beta-Spin Inverse Matrix %3zu\n", iDet ) ; 
    cfloat_p * inverse = getTempInverse( _self, _iThread, iDet, BETA ) ;
    for( size_t iEl=0 ; iEl<nBeta( _self ) ; iEl++ ) {
      printf( "     " ) ;
      for( size_t iMO=0 ; iMO<nBeta( _self ) ; iMO++ ) {
	      printf( "% 12.8f ", inverse[iEl*nBeta( _self ) + iMO] ) ;
      }
      printf( "\n" ) ;
    }
  }

  /*
  printf( "     Alpha Inverse Check : " ) ;
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    cfloat_p * matrix = getTempMatrix( _self, _iThread, iDet, ALPHA ) ;
     cfloat_p * inverse = getTempInverse( _self, _iThread, iDet, ALPHA ) ;
     if( ! checkIdentity(matrix, inverse, nAlpha( _self ), nAlpha( _self )) ) {
        printf( "%zu  ", iDet ) ;
     } else {
       exit( EXIT_FAILURE ) ;
     }
  }
  printf( "Clear!\n" ) ;
  printf( "     Beta Inverse Check  : " ) ;
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    cfloat_p * matrix = getTempMatrix( _self, _iThread, iDet, BETA ) ;
     cfloat_p * inverse = getTempInverse( _self, _iThread, iDet, BETA ) ;
     if( ! checkIdentity(matrix, inverse, nBeta( _self ), nBeta( _self )) ) {
        printf( "%zu  ", iDet ) ;
     } else {
       exit( EXIT_FAILURE ) ;
     }
  }
  printf( "Clear!\n" ) ;
  */

}

void ensemble_write_xml( const Ensemble_t * _self ) {

  DIR * directory = opendir( "results/" ) ;
  if( directory ) {
     closedir( directory ) ;
  } else {
     printf( "Directory results/ was not found when writing Ensemble.xml\n" ) ;
     exit( EXIT_FAILURE ) ;
  }

  FILE * xml = fopen( "results/Ensemble.xml", "w+" ) ; assert( xml ) ;

  fprintf( xml, "\t<Parameter name=\"nWalkers\"> %5zu </Parameter>\n", nWalkers( _self ) ) ;
  fprintf( xml, "\t<Parameter name=\"nElec\"> %5zu </Parameter>\n\n", nElec( _self ) ) ;

  for( size_t iWalker=0 ; iWalker<nWalkers( _self ) ; iWalker++ ) {
    fprintf( xml, "\t<Walker>\n" ) ;
    for( size_t iEl=0 ; iEl<nElec( _self ) ; iEl++ ) {
      float_p * electron = getElectron( _self, iWalker, iEl ) ;
      fprintf( xml, "\t\t%12.8f %12.8f %12.8f\n", electron[0], electron[1], electron[2] ) ;
    }
    fprintf( xml, "\t</Walker>\n" ) ;
  }

  fprintf( xml, "</Ensemble>\n\n" ) ;

  fclose( xml ) ;

}

/**
 * @brief Dump the ensemble configuration to a header file. Write out the 
 *        struct with statically allocated arrays and initialise everything.
 * @param[in] _self : Ensemble_t object.
 */
void ensemble_dump( const Ensemble_t * _self ) {

  DIR * directory = opendir( "include/" ) ;
  if( directory ) {
     closedir( directory ) ;
  } else {
     printf( "Directory include/ was not found when dumping ensemble.\n" ) ;
     exit( EXIT_FAILURE ) ;
  }

  printf( " === Dumping Ensemble to include/ensemble.dump..." ) ;
  FILE * dump = fopen( "include/ensemble.dump", "w+" ) ; assert( dump ) ;
  size_t acc = 0 ;
  
  // First of all we dump the struct with statically allocated arrays
  fprintf( dump, "#ifndef ENSEMBLE_DUMP\n#define ENSEMBLE_DUMP\n\n" ) ;

  fprintf( dump, "typedef struct Ensemble {\n\n" ) ;

  fprintf( dump, "\tsize_t magic ;\n" ) ;
  fprintf( dump, "\tsize_t nDets, nWalkers, nAlpha, nBeta ;\n" ) ;
  fprintf( dump, "\tsize_t nPadAlpha, nPadBeta ;\n\n" ) ;

  fprintf( dump, "\tsize_t sectionSizes[%zu], sectionOffsets[%zu] ;\n",
	   (size_t) NSECTIONS, (size_t) NSECTIONS ) ;
  fprintf( dump, "\tsize_t t_sectionSizes[%zu], t_sectionOffsets[%zu] ;\n",
	   (size_t) NSECTIONS, (size_t) NSECTIONS ) ;
  fprintf( dump, "\tsize_t generation[1] ;\n\n" ) ;
  
  fprintf( dump, "\tcfloat_p * cData, * cTempData ;\n" ) ;
  fprintf( dump,
     "\tfloat_p __attribute__((aligned(0x10))) rData[%zu], rTempData[%zu] ;\n",
     _self->rBufferSize + _self->cBufferSize, _self->t_rBufferSize + _self->t_cBufferSize ) ;
  fprintf( dump,
     "\tsize_t rBufferSize, cBufferSize, t_rBufferSize, t_cBufferSize ;\n" ) ;
  fprintf( dump, "\tfloat_p effectiveTimestep_num[1], effectiveTimestep_den[1] ;\n\n" ) ;

  fprintf( dump,
     "\tvoid (*copy)( struct Ensemble * _self, const struct Ensemble * _source ) ;\n" ) ;
  fprintf( dump,
     "\tvoid (*displaceAll)( struct Ensemble * _self, const float_p _dx ) ;\n" ) ;
  fprintf( dump,
     "\tvoid (*copyTemp)( struct Ensemble * _self, const TrialWavefunction_t * _wave, const size_t _iThread, const size_t _iWalker, const string _direction ) ;\n" ) ;
  fprintf( dump,
     "\tvoid (*displace)( struct Ensemble * _self, const TrialWavefunction_t * _wave, const size_t _iThread, const size_t _iEl, const float_p dx ) ;\n" ) ;
  fprintf( dump,
     "\tvoid (*deltaSlater)( struct Ensemble * _self, const TrialWavefunction_t * _wave, const size_t _iThread, const size_t _iWalker, const size_t _iEl ) ;\n" ) ;
  fprintf( dump,
     "\tint (*metropolis)( struct Ensemble * _self, const TrialWavefunction_t * _wave, const size_t _iThread, const size_t _iWalker, const size_t _iEl, const float_p _random_scale ) ;\n" ) ;
  fprintf( dump,
     "\tvoid (*updateTempInverse)( struct Ensemble * _self, const size_t _iEl ) ;\n" ) ;
  fprintf( dump,
     "\tvoid (*updateLocalEnergy)( struct Ensemble * _self, const size_t _iEl ) ;\n" ) ;
  fprintf( dump,
     "\tvoid (*acceptMove)( struct Ensemble * _self, const TrialWavefunction_t * _wave, const size_t _iThread, const size_t _iWalker, const size_t _iEl ) ;\n" ) ;
  fprintf( dump,
     "\tbool (*acceptanceCriterion)( struct Ensemble * _self, const TrialWavefunction_t * _wave, const size_t _iThread, const size_t _iWalker, const size_t _iEl, const float_p _random_scale ) ;\n" ) ;
  fprintf( dump,
     "\tvoid (*rejectMove)( struct Ensemble * _self, const TrialWavefunction_t * _wave, const size_t _iThread, const size_t _iWalker, const size_t _iEl ) ;\n" ) ;
  fprintf( dump,
	   "\tvoid (*printWalker)( const struct Ensemble * _self, const size_t _iWalker ) ;\n" ) ;
  fprintf( dump,
	   "\tvoid (*printTemp)( const struct Ensemble * _self, const size_t _iThread ) ;\n\n" ) ;

  fprintf( dump, "} Ensemble_t ;\n\n" ) ;

  fprintf( dump, "#ifdef MAIN\n" ) ;
  fprintf( dump, "Ensemble_t ensemble = {\n\n" ) ;

  fprintf( dump, "\t.magic = %zu,\n", _self->magic ) ;
  fprintf( dump,
     "\t.nDets = %zu, .nWalkers = %zu, .nAlpha = %zu, .nBeta = %zu,\n",
     _self->nDets, _self->nWalkers, _self->nAlpha, _self->nBeta ) ;
  fprintf( dump,
     "\t.nPadAlpha = %zu, .nPadBeta = %zu,\n",
     _self->nPadAlpha, _self->nPadBeta ) ;

  acc = 0 ; fprintf( dump, "\t.sectionOffsets/*[%zu]*/ = {\n",
		     (size_t) NSECTIONS ) ;
  for( size_t iVal=0 ; iVal<NSECTIONS ; iVal++ ) {
    if( acc == 7 ) { fprintf( dump, ",\n" ) ; acc = 0 ; }
    acc == 0 ? fprintf( dump, "\t\t" ) : fprintf( dump, ",   " ) ;
    fprintf( dump, "%zu", _self->sectionOffsets[iVal] ) ;
    acc++ ;
  }
  fprintf( dump, "\n\t},\n" ) ;

  acc = 0 ; fprintf( dump, "\t.sectionSizes/*[%zu]*/ = {\n",
		     (size_t) NSECTIONS ) ;
  for( size_t iVal=0 ; iVal<NSECTIONS ; iVal++ ) {
    if( acc == 7 ) { fprintf( dump, ",\n" ) ; acc = 0 ; }
    acc == 0 ? fprintf( dump, "\t\t" ) : fprintf( dump, ",   " ) ;
    fprintf( dump, "%zu", _self->sectionSizes[iVal] ) ;
    acc++ ;
  }
  fprintf( dump, "\n\t},\n" ) ;

  acc = 0 ; fprintf( dump, "\t.t_sectionOffsets/*[%zu]*/ = {\n",
		     (size_t) NSECTIONS ) ;
  for( size_t iVal=0 ; iVal<NSECTIONS ; iVal++ ) {
    if( acc == 7 ) { fprintf( dump, ",\n" ) ; acc = 0 ; }
    acc == 0 ? fprintf( dump, "\t\t" ) : fprintf( dump, ",   " ) ;
    fprintf( dump, "%zu", _self->t_sectionOffsets[iVal] ) ;
    acc++ ;
  }
  fprintf( dump, "\n\t},\n" ) ;

  acc = 0 ; fprintf( dump, "\t.t_sectionSizes/*[%zu]*/ = {\n",
		     (size_t) NSECTIONS ) ;
  for( size_t iVal=0 ; iVal<NSECTIONS ; iVal++ ) {
    if( acc == 7 ) { fprintf( dump, ",\n" ) ; acc = 0 ; }
    acc == 0 ? fprintf( dump, "\t\t" ) : fprintf( dump, ",   " ) ;
    fprintf( dump, "%zu", _self->t_sectionSizes[iVal] ) ;
    acc++ ;
  }
  fprintf( dump, "\n\t},\n" ) ;
  

  fprintf( dump,
     "\t.rBufferSize = %zu, .cBufferSize = %zu, .t_rBufferSize = %zu, .t_cBufferSize = %zu,\n\n",
     _self->rBufferSize, _self->cBufferSize, _self->t_rBufferSize, _self->t_cBufferSize ) ;

  acc = 0 ; fprintf( dump, "\t.rData/*[%zu]*/ = {\n", _self->rBufferSize + _self->cBufferSize ) ;
  for( size_t iVal=0 ; iVal<(_self->rBufferSize + _self->cBufferSize) ; iVal++ ) {
    if( acc == 7 ) { fprintf( dump, ",\n" ) ; acc = 0 ; }
    acc == 0 ? fprintf( dump, "\t\t" ) : fprintf( dump, ",   " ) ;
    fprintf( dump, "%A", _self->rData[iVal] ) ;
    acc++ ;
  }
  fprintf( dump, "\n\t},\n" ) ;

  acc = 0 ; fprintf( dump, "\t.rTempData/*[%zu]*/ = {\n",
		     _self->t_rBufferSize + _self->t_cBufferSize ) ;
  for( size_t iVal=0 ; iVal<(_self->t_rBufferSize + _self->t_cBufferSize) ; iVal++ ) {

    if( acc == 7 ) { fprintf( dump, ",\n" ) ; acc = 0 ; }
    acc == 0 ? fprintf( dump, "\t\t" ) : fprintf( dump, ",   " ) ;
    fprintf( dump, "%A", _self->rTempData[iVal] ) ;
    acc++ ;
  }
  fprintf( dump, "\n\t},\n" ) ;

    fprintf( dump, "\t.cData = NULL,\n" ) ;

    fprintf( dump, "\t.cTempData = NULL\n" ) ;

  fprintf( dump, "} ;\n\n" ) ;
  fprintf( dump, "#endif /* #ifdef MAIN*/\n" ) ;
  fprintf( dump, "#endif /* #ifndef ENSEMBLE_DUMP */\n" ) ;
  fclose( dump ) ;

/*
  // ======================= HACK HACK HACK =========================
  // Revert the changes we made above
  memcpy( elecBase, tempElecs,
	  _self->sectionSizes[ElectronPositions] * sizeof(float_p) ) ;
  free( tempElecs ) ;
  // ======================= HACK HACK HACK =========================
*/
  printf( " Done!\n" ) ;

}
