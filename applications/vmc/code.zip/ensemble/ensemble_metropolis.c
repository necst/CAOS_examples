/**
 * @file ensemble_metropolis.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Methods for accept/reject configuration moves. 
 */
#include <ensemble/ensemble.h>
#include <ensemble/ensemble_query.h>

cfloat_p inv_cols[NTHREADSMAX*RANKMAX] ;
void ensemble_update_inverse( Ensemble_t * _self,
			      const size_t _iThread,
			      const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t iSpin = spin( _self, _iEl ) ;
  size_t localElecIdx = spinElec( _self, _iEl ) ;
  size_t nElec = nSpinElec( _self, iSpin ) ;
  size_t stride = nPad( _self, iSpin ) ;
  cfloat_p * inv_col = inv_cols + _iThread * RANKMAX ;

  // First of all we update the inverse matrices
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {

    cfloat_p * inverse = getTempInverse( _self, _iThread, iDet, iSpin ) ;
    cfloat_p * row = inverse + localElecIdx * stride ;
    memcpy( inv_col, row, nElec * sizeof(cfloat_p) ) ;
    cfloat_p * mvproduct =
      getTempComputeSpace( _self, _iThread ) + iDet * nElec ;

    cfloat_p myScaleFactor = -1.0 / (1.0 + mvproduct[localElecIdx]) ;

    for( size_t iDim=0 ; iDim<nElec ; iDim++ ) {
      cfloat_p v = mvproduct[iDim] * myScaleFactor ;
      for( size_t jDim=0 ; jDim<nElec ; jDim++ ) {
	      inverse[iDim*stride + jDim] += inv_col[jDim] * v ;
      }
    }

  }

}

/**
 * @brief Reject the move proposed by the temporary walker. We avoid a call 
 *        to copyTemp() by doing minimal memory management here (just the 
 *        electron position and determinant values). Also have to explicitly 
 *        unlock the temporary walker.
 * @param[in] _self    : Ensemble_t object.
 * @param[in] _iWalker : Walker index.
 * @param[in] _iThread : Thread index.
 * @param[in] _iEl     : Electron index.
 */
void ensemble_reject_move( Ensemble_t * _self,
			   const TrialWavefunction_t * _wave,
			   const size_t _iThread,
			   const size_t _iWalker,
			   const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t iSpin = spin( _self, _iEl ) ;
  size_t localElecIdx = spinElec( _self, _iEl ) ;
  size_t stride = nPad( _self, iSpin ) ;

  // Pointers in the ensemble data buffer
  float_p * electron =
    getElectron( _self, _iWalker, _iEl ) ;
  cfloat_p * det_alpha =
    getDeterminants( _self, _iWalker, 0, ALPHA ) ;
  cfloat_p * det_beta =
    getDeterminants( _self, _iWalker, 0, BETA ) ;

  // Pointers in the temporary data buffer
  float_p * t_electron =
    getTempElectron( _self, _iThread, _iEl ) ;
  cfloat_p * t_det_alpha =
    getTempDeterminants( _self, _iThread, ALPHA ) ;
  cfloat_p * t_det_beta =
    getTempDeterminants( _self, _iThread, BETA ) ;

  // Get number of elements in slater_row and inverse_mat
  size_t nVals = iSpin == ALPHA ? nAlpha( _self ) * sizeof(cfloat_p)
                                : nBeta( _self ) * sizeof(cfloat_p) ;
  size_t nMatElem = iSpin == ALPHA ? nMatrixAlpha( _self ) * sizeof(cfloat_p) 
                                   : nMatrixBeta( _self ) * sizeof(cfloat_p) ;

  memcpy( t_electron, electron, nDims * sizeof(float_p) ) ;
  memcpy( t_det_alpha, det_alpha, nDets( _self ) * sizeof(cfloat_p) ) ;
  memcpy( t_det_beta, det_beta, nDets( _self ) * sizeof(cfloat_p) ) ;

  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    // Copy back the Slater matrix
    cfloat_p * slater_row =
      getMatrix( _self, _iWalker, iDet, iSpin ) + localElecIdx * stride ;
    cfloat_p * t_slater_row =
      getTempMatrix( _self, _iThread, iDet, iSpin ) + localElecIdx * stride ;
    memcpy( t_slater_row, slater_row, nVals ) ;
    
    // Copy back the inverse matrix
    cfloat_p * inverse_mat =
      getInverse( _self, _iWalker, iDet, iSpin ) ; 
    cfloat_p * t_inverse_mat =
      getTempInverse( _self, _iThread, iDet, iSpin ) ;
    memcpy( t_inverse_mat, inverse_mat, nMatElem ) ;
  }

  ensemble_update_distance_tables( _self, _wave, _iThread, _iEl ) ;
     
}

/**
 * @brief Accept the move proposed by the temporary walker. This is a fairly 
 *        heavy duty routine, involving explicit inverse update, explicit local 
 *        energy re-calculation and memory management for moving data from the 
 *        temporary walker to the ensemble.
 * @todo Only use trial energy update routines as opposed to full recalculation.
 * @param[in] _self    : Ensemble_t object.
 * @param[in] _wave    : TrialWavefunction_t object.
 * @param[in] _iWalker : Walker index.
 * @param[in] _iThread : Thread index.
 * @param[in] _iEl     : Electron index.
 */
void ensemble_accept_move( Ensemble_t * _self,
			   const TrialWavefunction_t * _wave,
			   const size_t _iThread,
			   const size_t _iWalker,
			   const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  // Modify the potential and kinetic contributions to the local energy
  float_p delta_potential =
    ensemble_calc_dpotential( _self, _wave, _iThread, _iWalker, _iEl ) ;
  * getTempPotentialEnergy( _self, _iThread ) += delta_potential ;

  float_p delta_kinetic =
    ensemble_calc_dkinetic( _self, _wave, _iThread, _iWalker, _iEl ) ; 
  * getTempKineticEnergy( _self, _iThread ) += delta_kinetic ;

  // Copy the temporary walker back to the ensemble
  _self->copyTemp( _self, _wave, _iThread, _iWalker, "TempToEnsemble" ) ;

}


/**
 * @brief Query the acceptance criterion for a VMC move.
 *        Check a node hasn't been crossed, then .
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _wave    : TrialWavefunction_t object.
 * @param[in]  _iThread : Thread index.
 * @param[in]  _iWalker : Walker index.
 * @param[out] bool     : Accept or reject.
 */
bool ensemble_acceptance_vmc( Ensemble_t * _self,
			      const TrialWavefunction_t * _wave,
			      const size_t _iThread,
			      const size_t _iWalker,
			      const size_t _iEl,
			      const float_p _random_scale ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  // Compute the old and new wavefunction values so we can invoke the
  // Metropolis criterion
  cfloat_p newWfn = getTempWfnValue( _self, _wave, _iThread ) ;
  cfloat_p oldWfn = getWfnValue( _self, _wave, _iWalker ) ;
  cfloat_p ratio = newWfn / oldWfn ;
  float_p sqRatio = creal_p( ratio * conj_p( ratio ) ) ;

  bool favourable =
    ( sqRatio >= 1.0f ||
      sqRatio > _random_scale * prng[_iThread].uniform( prng + _iThread ) ) 
    ? true : false ;
  
  // If we accept, call the accept the determinant part of the
  // Metropolis, then check whether we also have a Jastrow
  // factor. Call relevant acceptance routines
  if( favourable ) {

    // Update the inverse wavefunction so we can calculate the new energies
    ensemble_update_inverse( _self, _iThread, _iEl ) ;

    if( _wave->type == SLATER ) {

      return true ;

    }

  // If we reject, call the reject routine
  } else {
    return false ;
  }
  
  return false ;

}

/**
 * @brief Compute the acceptance probability for the move of _iEl. Handle 
 *        whether the move is accepted or rejected.
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _iWalker : Walker index.
 * @param[in]  _iThread : Thread index.
 * @param[in]  _iEl     : Electron index.
 * @param[out] int      : Move rejected (0) or accepted (1).
 */
int ensemble_calc_acceptance( Ensemble_t * _self,
			      const TrialWavefunction_t * _wave,
			      const size_t _iThread,
			      const size_t _iWalker,
			      const size_t _iEl,
			      const float_p _random_scale ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t iSpin = spin( _self, _iEl ) ;
  size_t localElecIdx = spinElec( _self, _iEl ) ;
  size_t nElec = nSpinElec( _self, iSpin ) ;
  size_t stride = nPad( _self, iSpin ) ;

  cfloat_p  * tempDets = getTempDeterminants( _self, _iThread, iSpin ) ;

  // We undertake the first part of the Sherman-Morrison update here. Compute
  // the vector-matrix product of the delta vector and inverse matrix
  // The resultant vector gets stored in the temporary compute space which
  // can be used in updating the inverse fully if we accept the move
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {

    cfloat_p * inverse = getTempInverse( _self, _iThread, iDet, iSpin ) ;
    cfloat_p * delta = getTempDelta( _self, _iThread, iDet, iSpin ) ;
    cfloat_p * mvproduct =
      getTempComputeSpace( _self, _iThread ) + iDet * nElec ;
    memset( mvproduct, 0, nElec * sizeof(cfloat_p) ) ;

    for( size_t iDim=0 ; iDim<nElec ; iDim++ ) {
      for( size_t jDim=0 ; jDim<nElec ; jDim++ ) {
	      mvproduct[iDim] += delta[jDim] * inverse[iDim*stride + jDim] ;
      }
    }

    cfloat_p myScaleFactor = 1.0 + mvproduct[localElecIdx] ;
    tempDets[iDet] *= myScaleFactor ;

  }
  
  if( _self->acceptanceCriterion( _self, _wave, _iThread,
				  _iWalker, _iEl, _random_scale ) ) {
    _self->acceptMove( _self, _wave, _iThread, _iWalker, _iEl ) ;
    return true ;
  } else {
    _self->rejectMove( _self, _wave, _iThread, _iWalker, _iEl ) ;
    return false ;
  }
  
}
