/**
 * @file ensemble_constructors.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Constructor routines for the Ensemble_t class.
 */
#include <trial_wavefunction/trial_wavefunction.h>
#include <ensemble/ensemble.h>
#include <ensemble/ensemble_query.h>

/**
 * @brief Initialise the function pointers for an Ensemble_t object.
 * @param[in] _self : Ensemble_t object.
 */
void ensemble_initialise( Ensemble_t * _self ) {

  _self->copy = &ensemble_copy ;
  _self->copyTemp = &ensemble_copy_temp ;
  _self->displace = &ensemble_displace_temp ;
  _self->deltaSlater = &ensemble_calc_delta ;
  _self->metropolis = &ensemble_calc_acceptance ;
  _self->acceptMove = &ensemble_accept_move ;
  _self->rejectMove = &ensemble_reject_move ;
  _self->printWalker = &ensemble_print_walker ;
  _self->printTemp = &ensemble_print_temp ;
  _self->acceptanceCriterion = &ensemble_acceptance_vmc ;

  _self->cData = _self->rData + _self->rBufferSize ;
  _self->cTempData = _self->rTempData + _self->t_rBufferSize ;
 
}

