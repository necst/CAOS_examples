/**
 * @file ensemble.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Ensemble methods I can't justify creating separate
 *        translation units for.
 */
#include <ensemble/ensemble.h>
#include <ensemble/ensemble_query.h>


/**
 * @brief Transpose a strided matrix in-place, i.e. destroy the original matrix.
 *        We transpose the entire square as opposed to rectangle-to-rectangle. 
 *        So CERTAINLY shouldn't be invoked when the entire ensemble has been 
 *        initialised.
 * @param[in] _matrix : Matrix for transposition.
 * @param[in] _stride : Rank of the stride.
 */
static void transpose( cfloat_p * _matrix,
                       const size_t _rank,
		       const size_t _stride ) {

  // Make a copy of the original matrix so we can transpose element-by-element
  cfloat_p temp[RANKMAX*RANKMAX] ;
  memcpy( temp, _matrix, _rank * _stride * sizeof(cfloat_p) ) ;

  // Do the transposition.
  for( size_t iRow=0 ; iRow<_rank ; iRow++ ) {
    for( size_t iCol=0 ; iCol<_rank ; iCol++ ) {
      _matrix[iCol*_stride + iRow] = temp[iRow*_stride + iCol] ;
    }
  }

}

/**
 * @brief Update a thread's distance tables subject to an electron move.
 * @note At the end of this, the old square distances for the electron will be 
 *       at the end of their respective
 *       distance tables. We can then compute the change in potential energy if 
 *       we accept the move!
 * @param[in] _self           : Ensemble_t object.
 * @param[in] _wave           : TrialWavefunction_t object.
 * @param[in] _iEl            : Electron index.
 * @param[in] _distanceTables : Distance tables for the thread.
 */
void ensemble_update_distance_tables( const Ensemble_t * _self,
				      const TrialWavefunction_t * _wave,
				      const size_t _iThread,
				      const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  float_p * vec_en = getTempDistanceTable( _iThread, VECTOR_EN ) ;
  float_p * sq_en = getTempDistanceTable( _iThread, SQUARE_EN ) ;
  float_p * vec_ee = getTempDistanceTable( _iThread, VECTOR_EE ) ;
  float_p * sq_ee = getTempDistanceTable( _iThread, SQUARE_EE ) ;
  // Some convenient pointers to the relevant parts of the electron-nuclear
  // distance tables
  float_p * row_vec_en = vec_en + _iEl * _wave->nCentres * nDims ;
  float_p * row_sq_en = sq_en + _iEl * _wave->nCentres ;
  float_p * pos_iElec = getTempElectron( _self, _iThread, _iEl ) ;

  // Copy the old square distances to the end of their tables so we have them
  // for the change in potential calculation!
  memcpy( sq_en + nElec( _self ) * _wave->nCentres,
	  sq_en + _iEl * _wave->nCentres,
	  _wave->nCentres * sizeof(float_p) ) ;
  memcpy( sq_ee + nElec( _self ) * nElec( _self ),
	  sq_ee + _iEl * nElec( _self ),
	  nElec( _self ) * sizeof(float_p) ) ;
  
  size_t jAtom = 0 ;
  // Loop over atoms and compute vector and square distances
  for( size_t iAtomType=0 ; iAtomType<_wave->nAtomTypes ; iAtomType++ ) {
    for( size_t iAtom=0 ; iAtom<_wave->nAtoms[iAtomType] ; iAtom++ ) {

      float_p pos_iAtom[3] = {
	      _wave->centre_x[jAtom],
	      _wave->centre_y[jAtom],
	      _wave->centre_z[jAtom]
      } ;

      float_p dx = pos_iElec[0] - pos_iAtom[0] ;
      float_p dy = pos_iElec[1] - pos_iAtom[1] ;
      float_p dz = pos_iElec[2] - pos_iAtom[2] ;

      row_vec_en[jAtom*nDims]   = dx ;
      row_vec_en[jAtom*nDims+1] = dy ;
      row_vec_en[jAtom*nDims+2] = dz ;
      
      row_sq_en[jAtom] = dx*dx + dy*dy + dz*dz ;

      jAtom++ ; 

    }
  }

  // Loop over electrons with higher index than passed electron and compute
  // vector and square distances. Symmetrise the distance tables (well,
  // antisymmetrise(?) the vector difference table) for convenience
  // Explicitly zero the diagonal elements
  for( size_t jEl=0 ; jEl<nElec( _self ) ; jEl++ ) {

    size_t iBaseIdx = (_iEl*nElec( _self ) + jEl) * nDims ;
    size_t jBaseIdx = (jEl*nElec( _self ) + _iEl) * nDims ;

    if( jEl == _iEl ) {

      zero( vec_ee + iBaseIdx, nDims ) ;
      zero( sq_ee + _iEl*nElec( _self ) + jEl, 1 ) ;

    } else {

      float_p * pos_jElec = getTempElectron( _self, _iThread, jEl ) ;

      float_p dx = pos_iElec[0] - pos_jElec[0] ;
      float_p dy = pos_iElec[1] - pos_jElec[1] ;
      float_p dz = pos_iElec[2] - pos_jElec[2] ;

      vec_ee[iBaseIdx]   = dx, vec_ee[jBaseIdx]   = -dx ;
      vec_ee[iBaseIdx+1] = dy, vec_ee[jBaseIdx+1] = -dy ;
      vec_ee[iBaseIdx+2] = dz, vec_ee[jBaseIdx+2] = -dz ;

      float_p rSq = dx*dx + dy*dy + dz*dz ;
      sq_ee[_iEl*nElec( _self ) + jEl] = rSq ;
      sq_ee[jEl*nElec( _self ) + _iEl] = rSq ;

    }
  }

}

/**
 * @brief Set distance tables for temporary walker so we can conveniently 
 *        evaluate Jastrow factor and potential energy without constantly 
 *        computing these quantities.
 * @param[in] _self    : Ensemble_t object.
 * @param[in] _wave    : TrialWavefunction_t object.
 * @param[in] _iThread : Thread index.
 */
void ensemble_set_distance_tables( const Ensemble_t * _self,
				   const TrialWavefunction_t * _wave,
				   const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */

  // Loop over electrons and do all electron-electron and electron-nuclear
  // distances within
  for( size_t iEl=0 ; iEl<nElec( _self ) ; iEl++ ) {    
    ensemble_update_distance_tables( _self, _wave, _iThread, iEl ) ;
  }  
  
}

/**
 * @brief Compute the Slater and Laplacian matrices for the requested walker.
 * @param[in] _self     : Ensemble_t object.
 * @param[in] _wave     : TrialWavefunction_t object.
 * @param[in] _iWalker  : Index of the walker we're working with.
 * @param[in] _iSpin    : Spin matrix we're updating.
 */
void ensemble_calc_slater( Ensemble_t * _self,
			   const TrialWavefunction_t * _wave,
			   const size_t _iThread,
			   const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  // Loop over each row of the Slater matrix and compute the column elements
  for( size_t iEl=0 ; iEl<nSpinElec( _self, _iSpin ) ; iEl++ ) {

    // Get the rows for each reference Slater matrix for the requested electron
    cfloat_p * slaterRows[NDETSMAX] = { NULL } ;
    cfloat_p * gradientRows[NDETSMAX] = { NULL } ;
    cfloat_p * laplacianRows[NDETSMAX] = { NULL } ;

    size_t offset = iEl * nPad( _self, _iSpin ) ;

    for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
      slaterRows[iDet] =
	      getTempMatrix( _self, _iThread, iDet, _iSpin ) + offset ;
      gradientRows[iDet] =
	      getTempGradient( _self, _iThread, iDet, _iSpin ) + offset * nDims ;
      laplacianRows[iDet] =
	      getTempLaplacian( _self, _iThread, iDet, _iSpin ) + offset ;
    }

    offset = elecIdx( _self, iEl, _iSpin ) * _wave->nCentres ;
    // Get the electron position and evaluate the Slater matrix rows
    float_p * vec_en =
      getTempDistanceTable( _iThread, VECTOR_EN ) + offset * nDims ;
    float_p * sq_en  =
      getTempDistanceTable( _iThread, SQUARE_EN ) + offset ;

    _wave->evaluate( _wave, _iThread, vec_en, sq_en, _iSpin, slaterRows ) ;
    _wave->gradient( _wave, _iThread, vec_en, _iSpin, gradientRows ) ;
    _wave->laplacian( _wave, _iThread, vec_en, _iSpin, laplacianRows ) ;

  }

}


/**
 * @brief Compute the difference in a Slater matrix row given an electron 
 *        displacement for a walker.
 * @param[in] _self    : Ensemble_t object.
 * @param[in] _wave    : Wavefunction object.
 * @param[in] _iWalker : Index of the walker we're working with.
 * @param[in] _iThread : OpenMP thread index.
 * @param[in] _iEl     : Electron index we've displaced.
 */
void ensemble_calc_delta( Ensemble_t * _self,
			  const TrialWavefunction_t * _wave,
			  const size_t _iThread,
			  const size_t _iWalker,
			  const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  // Get the spin, spin-index and number of electrons of this spin state for
  // the electron we've displaced
  size_t iSpin = spin( _self, _iEl ) ;
  size_t localElecIdx = spinElec( _self, _iEl ) ;
  size_t nElec = nSpinElec( _self, iSpin ) ;
  size_t stride = nPad( _self, iSpin ) ;

  // Get the rows for each reference Slater matrix for the requested electron
  cfloat_p * delta[NDETSMAX] = { NULL } ;
  size_t nVals = iSpin == ALPHA ? nAlpha( _self ) * sizeof(cfloat_p)
                                : nBeta( _self )  * sizeof(cfloat_p) ;
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    delta[iDet] = getTempDelta( _self, _iThread, iDet, iSpin ) ;
    memset( delta[iDet], 0, nVals ) ;
  }

  size_t offset_en = _wave->nCentres * _iEl ;
  // Fill the delta with new Slater matrix elements
  float_p * vec_en =
    getTempDistanceTable( _iThread, VECTOR_EN ) + offset_en * nDims ;
  float_p * sq_en  =
    getTempDistanceTable( _iThread, SQUARE_EN ) + offset_en ;

  _wave->evaluate( _wave, _iThread, vec_en, sq_en, iSpin, delta ) ;

  // Subtract the old Slater matrix elements from delta
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {

    cfloat_p * tempSlater = getTempMatrix( _self, _iThread, iDet, iSpin ) ;
    cfloat_p * row = tempSlater + localElecIdx * stride ;

    for( size_t iMO=0 ; iMO<nElec ; iMO++ ) {
      // TODO : Sort this monstrosity out
      delta[iDet][iMO] -= row[iMO] ; row[iMO] += delta[iDet][iMO] ;
    }

  }
    
}

/**
 * @brief Apply a smooth cutoff to the quantum force to prevent it causing
 *        large electron moves if it approaches a node. See Equation (55)
 *        of the CASINO manual.
 * @param[in] _quantum_force : The quantum force to cutoff.
 */
static void apply_cutoff_quantum_force( float_p * _quantum_force ) {

  float_p qf_sq = 0.0 ;
  
  for( size_t iDim=0 ; iDim<nDims ; iDim++ ) {
    qf_sq += _quantum_force[iDim] * _quantum_force[iDim] ;
  }

  float_p scale = (sqrt( 1 + 2 * qf_sq * 0.001 ) - 1) / qf_sq * 0.001 ;

  for( size_t iDim=0 ; iDim<nDims ; iDim++ ) {
    _quantum_force[iDim] *= scale ;
  }
  
}

/**
 * @brief Calculate the Quantum Forces for each electron in a temporary walker.
 * @param[in] _self    : Ensemble_t object.
 * @param[in] _wave    : TrialWavefunction_t object.
 * @param[in] _iThread : Thread index.
 * @todo : I've gone a little overkill with the wavefunction evaluation followed
 *         by gradient. At a guess, the wavefunction will have already been
 *         computed by the time we call this routine, so probably superfluous.
 */
cfloat_p * slaterRowsThreads[NTHREADSMAX*NDETSMAX] ;
cfloat_p * gradientRowsThreads[NTHREADSMAX*NDETSMAX] ;
cfloat_p * inverseRowsThreads[NTHREADSMAX*NDETSMAX] ;
void ensemble_calc_quantum_force( Ensemble_t * _self,
				   const TrialWavefunction_t * _wave,
				   const size_t _iThread,
				   const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */

  // Get the base of the temporary quantum forces
  float_p * quantum_force = getTempQuantumForce( _self, _iThread, _iEl ) ;
  zero( quantum_force, nDims ) ;
  
  cfloat_p wavefunction = getTempWfnValue( _self, _wave, _iThread ) ;
  
  // Get the spin, spin-index and number of electrons of this spin state for
  // the electron we've displaced
  size_t iSpin = spin( _self, _iEl ) ;
  size_t localElecIdx = spinElec( _self, _iEl ) ;
  size_t stride = nPad( _self, iSpin ) ;
  size_t nelec = nSpinElec( _self, iSpin ) ;
  
  // Get the rows for each reference Slater matrix for the requested electron
  cfloat_p ** slaterRows = slaterRowsThreads + _iThread * NDETSMAX ;
  cfloat_p ** gradientRows = gradientRowsThreads + _iThread * NDETSMAX ;
  cfloat_p ** inverseRows = inverseRowsThreads + _iThread * NDETSMAX ;

  size_t offset = localElecIdx * stride ;

  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    slaterRows[iDet] =
      getTempMatrix( _self, _iThread, iDet, iSpin ) + offset ;
    gradientRows[iDet] =
      getTempGradient( _self, _iThread, iDet, iSpin ) + offset * nDims ;
    inverseRows[iDet] =
      getTempInverse( _self, _iThread, iDet, iSpin ) + offset ;
  }

  offset = _iEl * _wave->nCentres ;
  // Get the electron position and evaluate the Slater matrix rows
  float_p * vec_en =
    getTempDistanceTable( _iThread, VECTOR_EN ) + offset * nDims ;
  float_p * sq_en  =
    getTempDistanceTable( _iThread, SQUARE_EN ) + offset ;

  _wave->evaluate( _wave, _iThread, vec_en, sq_en, iSpin, slaterRows ) ;
  _wave->gradient( _wave, _iThread, vec_en, iSpin, gradientRows ) ;
    
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {

    cfloat_p det_alpha = getTempDeterminants( _self, _iThread, ALPHA )[iDet] ;
    cfloat_p det_beta = getTempDeterminants( _self, _iThread, BETA )[iDet] ;
    cfloat_p factor = 2.0f * det_alpha * det_beta / wavefunction ;
    
    for( size_t iMO=0 ; iMO<nelec ; iMO++ ) {
      quantum_force[0] +=
	      creal_p( factor * gradientRows[iDet][iMO*nDims] * inverseRows[iDet][iMO] ) ;
      quantum_force[1] +=
	      creal_p( factor * gradientRows[iDet][iMO*nDims+1] * inverseRows[iDet][iMO] ) ;
      quantum_force[2] +=
	      creal_p( factor * gradientRows[iDet][iMO*nDims+2] * inverseRows[iDet][iMO] ) ;
    }

  }


  apply_cutoff_quantum_force( quantum_force ) ;

}

/**
 * @brief Copy a walker's data from a pointer group to a second pointer
 *        group. Note our use of memcopy(). which means we skip a copy
 *        if a pointer in a pointer group is NULL, rather than die. 
 * @param[in] _self : Ensemble_t object.
 * @param[in] _dest : Destination pointer group.
 * @param[in] _src  : Source pointer group.
 */
void ensemble_copy_walker( const Ensemble_t * _self,
			   void * _dest[],
			   void * _src[] ) {
    
#ifdef BE_ASSERTIVE
  assert( _dest && _src ) ;
#endif /* #ifdef BE_ASSERTIVE */

  memcopy( _dest[ElectronPositions], _src[ElectronPositions],
	   nDims * nElec( _self ) * sizeof(float_p) ) ;
  memcopy( _dest[Displacements], _src[Displacements],
	   nDims * nElec( _self ) * sizeof(float_p) ) ;
  memcopy( _dest[KineticEnergies], _src[KineticEnergies],
	   sizeof(float_p) ) ;
  memcopy( _dest[PotentialEnergies], _src[PotentialEnergies],
	   sizeof(float_p) ) ;
  memcopy( _dest[JastrowFactors], _src[JastrowFactors],
	   sizeof(float_p) ) ;
  memcopy( _dest[Weights], _src[Weights],
	   sizeof(float_p) ) ;

  memcopy( _dest[AlphaMatrices], _src[AlphaMatrices],
	   nDets( _self ) * nMatrixAlpha( _self ) * sizeof(cfloat_p) ) ;
  memcopy( _dest[BetaMatrices], _src[BetaMatrices],
	   nDets( _self ) * nMatrixBeta( _self ) * sizeof(cfloat_p) ) ;
  memcopy( _dest[AlphaInverses], _src[AlphaInverses],
	   nDets( _self ) * nMatrixAlpha( _self ) * sizeof(cfloat_p) ) ;
  memcopy( _dest[BetaInverses], _src[BetaInverses],
	   nDets( _self ) * nMatrixBeta( _self ) * sizeof(cfloat_p) ) ;
  memcopy( _dest[AlphaLaplacians], _src[AlphaLaplacians],
	   nDets( _self ) * nMatrixAlpha( _self ) * sizeof(cfloat_p) ) ;
  memcopy( _dest[BetaLaplacians], _src[BetaLaplacians],
	   nDets( _self ) * nMatrixBeta( _self ) * sizeof(cfloat_p) ) ;
  memcopy( _dest[AlphaGradients], _src[AlphaGradients],
	   nDets( _self ) * nMatrixAlpha( _self ) * nDims * sizeof(cfloat_p) ) ;
  memcopy( _dest[BetaGradients], _src[BetaGradients],
	   nDets( _self ) * nMatrixBeta( _self ) * nDims * sizeof(cfloat_p) ) ;
  memcopy( _dest[AlphaDeterminants], _src[AlphaDeterminants],
	   nDets( _self ) * sizeof(cfloat_p) ) ;
  memcopy( _dest[BetaDeterminants], _src[BetaDeterminants],
	   nDets( _self ) * sizeof(cfloat_p) ) ;

}



/**
 * @brief Copy data to/from the ensemble data buffer to the temporary data 
 *        buffer.
 * @param[in] _self      : Ensemble_t object.
 * @param[in] _iWalker   : Index of the ensemble walker we're copying to/from.
 * @param[in] _iThread   : OpenMP thread index.
 * @param[in] _direction : Whether we're copying "EnsembleToTemp" or 
 *                         "TempToEnsemble"
 */
void ensemble_copy_temp( Ensemble_t * _self,
			 const TrialWavefunction_t * _wave,
			 const size_t _iThread,
			 const size_t _iWalker,
			 const string _direction ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  // For the sake of not bloating this section and preventing writing multiple
  // functions, we just use void pointers for the walker data entries
  // I know you should only do this if you know what you're doing, and
  // arguably I don't, but since this is a learning experience...
  void ** walker_pointer = walker_pointer_a + _iThread * NSECTIONS ;
  void ** temp_pointer = walker_pointer_b + _iThread * NSECTIONS ;

  // Pointers to the walker and temporary walker
  getWalkerPointer( _self, _iWalker, walker_pointer ) ;
  getTempPointer( _self, _iThread, temp_pointer ) ;

  // Do the copying
  if( ! strcmp( _direction, "EnsembleToTemp" ) ) {
    ensemble_copy_walker( _self, temp_pointer, walker_pointer ) ;
    ensemble_set_distance_tables( _self, _wave, _iThread ) ;
  } else if( ! strcmp( _direction, "TempToEnsemble" ) ) {
    ensemble_copy_walker( _self, walker_pointer, temp_pointer ) ;
  } else {
    printf( "Unrecognised argument for _direction in ensemble_copy_temp()." ) ;
    exit( EXIT_FAILURE ) ;
  }
  
}

/**
 * @brief Randomly displace an electron in the temporary walker. Update the 
 *        distance tables while we're at it.
 * @param[in] _self    : Ensemble_t object.
 * @param[in] _iEl     : Electron index we're displacing.
 * @param[in] _iThread : Temporary walker thread index.
 * @param[in] _dx      : Random displacement amplitude.
 */
void ensemble_displace_temp( Ensemble_t * _self,
			     const TrialWavefunction_t * _wave,
			     const size_t _iThread,
			     const size_t _iEl,
			     const float_p _dx ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  float_p * temp_pos = getTempElectron( _self, _iThread, _iEl ) ;

  // Do the displacement
  temp_pos[0] += 2 * _dx * prng[_iThread].uniform( prng + _iThread ) - _dx ;
  temp_pos[1] += 2 * _dx * prng[_iThread].uniform( prng + _iThread ) - _dx ;
  temp_pos[2] += 2 * _dx * prng[_iThread].uniform( prng + _iThread ) - _dx ;

  ensemble_update_distance_tables( _self, _wave, _iThread, _iEl ) ;

}

/**
 * @brief Randomly diffuse an electron in the temporary walker. Update the 
 *        distance tables while we're at it.
 * @param[in] _self    : Ensemble_t object.
 * @param[in] _wave    : TrialWavefunction_t object.
 * @param[in] _iThread : Temporary walker thread index.
 * @param[in] _iEl     : Electron index we're displacing.
 * @param[in] _dtau    : Random displacement amplitude.
 */
void ensemble_diffuse_temp( Ensemble_t * _self,
			     const TrialWavefunction_t * _wave,
			     const size_t _iThread,
			     const size_t _iEl,
			     const float_p _dtau ) {
  
#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  float_p * dr = getTempDisplacement( _self, _iThread, _iEl ) ;

  dr[0] = prng[_iThread].gaussian( prng + _iThread, sqrt( _dtau ) ) ;
  dr[1] = prng[_iThread].gaussian( prng + _iThread, sqrt( _dtau ) ) ;
  dr[2] = prng[_iThread].gaussian( prng + _iThread, sqrt( _dtau ) ) ;

  diffusiveDistanceSq[_iThread] += dr[0]*dr[0] + dr[1]*dr[1] + dr[2]*dr[2] ;
  
  float_p * quantum_force = getTempQuantumForce( _self, _iThread, _iEl ) ;

  dr[0] += 0.5 * _dtau * quantum_force[0] ;
  dr[1] += 0.5 * _dtau * quantum_force[1] ;
  dr[2] += 0.5 * _dtau * quantum_force[2] ;

  float_p * temp_pos = getTempElectron( _self, _iThread, _iEl ) ;

  // Do the displacement
  temp_pos[0] += dr[0] ; temp_pos[1] += dr[1] ; temp_pos[2] += dr[2] ;

  ensemble_update_distance_tables( _self, _wave, _iThread, _iEl ) ;

}

/**
 * @brief Compute the unreweighted variance for the ensemble. See equations 
 *        (237) and (238) in CASINO manual.
 *        Used as a cost function for wavefunction optimisation.
 * @param[in]  _self   : Ensemble_t object.
 * @param[out] float_p : Unreweighted variance for the ensemble.
 */
float_p ensemble_calc_unreweightedVariance( const Ensemble_t * _self ) {

  float_p unreweightedEnergy = 0, unreweightedVariance = 0 ;

  for( size_t iWalker=0 ; iWalker<nWalkers( _self ) ; iWalker++ ) {
    unreweightedEnergy += getLocalEnergy( _self, iWalker ) ;
  }
  unreweightedEnergy /= (float_p) nWalkers( _self ) ;

  for( size_t iWalker=0 ; iWalker<nWalkers( _self ) ; iWalker++ ) {
    float_p value =
      fabs( getLocalEnergy( _self, iWalker ) - unreweightedEnergy ) ;
    unreweightedVariance += value * value ;
  }

  return unreweightedVariance / (float_p) ( nWalkers( _self ) - 1 ) ;

}

/**
 * @brief Copy the data from an Ensemble_t object to another Ensemble_t object.
 *        Just do electron positions, Slater matrices and their inverses, as 
 *        well as fundamental parameters.
 *        Note that we're assuming the arrays are statically allocated! 
 * @param[in] _self   : Ensemble_t object.
 * @param[in] _source : Ensemble_t object.
 */
void ensemble_copy( Ensemble_t * _self,
		    const Ensemble_t * _source ) {

  // Initialise the magic number of the object.
  InitMagicEnsemble( _self ) ;

  /// Initialise parameters
  _self->nDets = nDets( _source ), _self->nWalkers = nWalkers( _source ) ;
  _self->nAlpha = nAlpha( _source ), _self->nBeta = nBeta( _source ) ;
  _self->nPadAlpha = nPad( _source, ALPHA ) ;
  _self->nPadBeta = nPad( _source, BETA ) ;
  _self->rBufferSize = _source->rBufferSize ;
  _self->cBufferSize = _source->cBufferSize ;

  // Get the section offsets and sizes
  memcpy( _self->sectionSizes, _source->sectionSizes,
	  NSECTIONS * sizeof(size_t) ) ;
  memcpy( _self->sectionOffsets, _source->sectionOffsets,
	  NSECTIONS * sizeof(size_t) ) ;

  _self->cData = _self->rData + _self->rBufferSize ;
  _self->cTempData = _self->rTempData + _self->t_rBufferSize ;
  
  memcpy( _self->rData, _source->rData,
	  (_self->rBufferSize + _self->cBufferSize) * sizeof(float_p)
	) ;

}
