/**
 * @file ensemble_query.h
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Query immutable ensemble characteristics.
 */

#ifndef ENSEMBLE_QUERY_H
#define ENSEMBLE_QUERY_H

// =====================================================================
//                             Query routines
// =====================================================================

// "ensbl" in hexadecimal
#define MAGIC_ENSEMBLE 0x656e73626c 
#define InitMagicEnsemble( w ) ( w->magic = MAGIC_ENSEMBLE )

/**
 * @brief Return the number of reference determinants in the trial wavefunction.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Number of reference determinants.
 */
static inline size_t nDets( const Ensemble_t * _self ) {
  return _self->nDets ;
}

/**
 * @brief Return the number of walkers in the ensemble.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Number of walkers.
 */
static inline size_t nWalkers( const Ensemble_t * _self ) {
  return _self->nWalkers ;
}

/**
 * @brief Return the padded width of alpha-spin matrices.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Width of alpha-spin matrices.
 */
static inline size_t nPadAlpha( const Ensemble_t * _self ) {
  return _self->nPadAlpha ;
}

/**
 * @brief Return the padded width of beta-spin matrices.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Width of beta-spin matrices.
 */
static inline size_t nPadBeta( const Ensemble_t * _self ) {
  return _self->nPadBeta ;
}

/**
 * @brief Return the padded width of a particular spin matrix.
 * @param[in]  _self  : Ensemble_t object.
 * @param[in]  _iSpin : Spin state.
 * @param[out] size_t : Width of spin matrices.
 */
static inline size_t nPad( const Ensemble_t * _self,
			   const size_t _iSpin ) {
  return _iSpin == ALPHA ? _self->nPadAlpha : _self->nPadBeta ;
}

/**
 * @brief Return the number of matrix elements for alpha-spin matrices.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Number of elements.
 */
static inline size_t nMatrixAlpha( const Ensemble_t * _self ) {
  return _self->nPadAlpha * _self->nAlpha ;
}

/**
 * @brief Return the number of matrix elements for beta-spin matrices.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Number of elements.
 */
static inline size_t nMatrixBeta( const Ensemble_t * _self ) {
  return _self->nPadBeta * _self->nBeta ;
}

/**
 * @brief Return the number of matrix elements for a given spin matrix.
 * @param[in]  _self  : Ensemble_t object.
 * @param[in]  _iSpin : Spin of the matrix.
 * @param[out] size_t : Number of elements.
 */
static inline size_t nMatrix( const Ensemble_t * _self,
			      const size_t _iSpin ) {
  return _iSpin == ALPHA ? nMatrixAlpha( _self ) : nMatrixBeta( _self ) ;
}
/**
 * @brief Return the local index of the electron in spin-state.
 * @param[in]  _self  : Ensemble_t object.
 * @param[in]  _iEl   : Electron index.
 * @param[out] size_t : Local index.
 */
static inline size_t spinElec( const Ensemble_t * _self,
			       const size_t _iEl ) {
#ifdef BE_ASSERTIVE
  assert( _iEl < _self->nAlpha + _self->nBeta ) ;
#endif /* #ifdef BE_ASSERTIVE */
  return _iEl >= _self->nAlpha ? _iEl - _self->nAlpha : _iEl ;
}

/**
 * @brief Return the number of electrons in a spin-state.
 * @param[in]  _self  : Ensemble_t object.
 * @param[in]  _iSpin : Spin index.
 * @param[out] size_t : Number of electrons.
 */
static inline size_t nSpinElec( const Ensemble_t *_self,
				const size_t _iSpin ) {
  return _iSpin == ALPHA ? _self->nAlpha : _self->nBeta ;
}

/**
 * @brief Return the global index of the electron from spin-state.
 * @param[in]  _self  : Ensemble_t object.
 * @param[in]  _iEl   : Electron index.
 * @param[in]  _iSpin : Spin index.
 * @param[out] size_t : The global electron index.
 */
static inline size_t elecIdx( const Ensemble_t * _self,
			      const size_t _iEl,
			      const size_t _iSpin ) {
#ifdef BE_ASSERTIVE
  assert( _iEl < _self->nAlpha + _self->nBeta ) ;
#endif /* #ifdef BE_ASSERTIVE */
  return _iSpin == ALPHA ? _iEl : _self->nAlpha + _iEl ;
}

/**
 * @brief Return the number of alpha electrons.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Number of alpha electrons.
 */
static inline size_t nAlpha( const Ensemble_t * _self ) {
#ifdef BE_ASSERTIVE
  assert( _self->magic == MAGIC_ENSEMBLE ) ;
#endif /* #ifdef BE_ASSERTIVE */
  return _self->nAlpha ;
}

/**
 * @brief Return the number of beta electrons.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Number of beta electrons.
 */
static inline size_t nBeta( const Ensemble_t * _self ) {
#ifdef BE_ASSERTIVE
  assert( _self->magic == MAGIC_ENSEMBLE ) ;
#endif /* #ifdef BE_ASSERTIVE */
  return _self->nBeta ;
}

/**
 * @brief Return the number of electrons.
 * @param[in]  _self  : Ensemble_t object.
 * @param[out] size_t : Number of electrons.
 */
static inline size_t nElec( const Ensemble_t * _self ) {
#ifdef BE_ASSERTIVE
  assert( _self->magic == MAGIC_ENSEMBLE ) ;
#endif /* #ifdef BE_ASSERTIVE */
  return _self->nAlpha + _self->nBeta ;
}

/**
 * @brief Return the spin of an electron.
 * @param[in]  _self  : Ensemble_t object.
 * @param[in]  _iEl   : Electron index.
 * @param[out] size_t : Spin index.
 */
static inline size_t spin( const Ensemble_t * _self, const size_t _iEl ) {
#ifdef BE_ASSERTIVE
  assert( _self->magic == MAGIC_ENSEMBLE ) ;
#endif /* #ifdef BE_ASSERTIVE */
  return _iEl < _self->nAlpha ? ALPHA : BETA ;
}
  
// NOTE : By convention, for any routine which accepts an electron index as an argument, the index is
//        given from the total number of electrons in the system, NOT the number of spin-electrons
//        This isn't necessarily optimal, but otherwise it becomes a nightmare to track what accepts what
// NOTE : By convention, indices passed to the following functions are ordered as follows:
//                *** Thread -> Walker -> Determinant -> Electron -> Spin ***
  
// =====================================================================
//                    Getters for the ensemble buffer
// =====================================================================

/**
 * @brief Return the requested spin-matrix from the data buffer.
 * @note Matrices are in row-major regardless of the accelerator.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iDet      : Determinant index.
 * @param[in]  _iWalker   : Walker index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the matrix.
 */
static inline cfloat_p * getMatrix( const Ensemble_t * _self,
				    const size_t _iWalker,
				    const size_t _iDet,
				    const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  //assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->sectionOffsets[AlphaMatrices]
    : _self->sectionOffsets[BetaMatrices] ;
  size_t offsetWalker  = _iSpin == ALPHA
    ? _iWalker * nDets( _self ) * nMatrixAlpha( _self )
    : _iWalker * nDets( _self ) * nMatrixBeta( _self ) ; 
  size_t offsetDeterminant = _iSpin == ALPHA
    ? _iDet * nMatrixAlpha( _self )
    : _iDet * nMatrixBeta( _self ) ; 
  
  return (cfloat_p *)
    (_self->cData + offsetSection + offsetWalker + offsetDeterminant) ; 
  
}

/**
 * @brief Return the requested spin-incerse from the data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iDet      : Determinant index.
 * @param[in]  _iWalker   : Walker index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the matrix.
 */
static inline cfloat_p * getInverse( const Ensemble_t * _self,
				     const size_t _iWalker,
				     const size_t _iDet,
				     const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  //assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */

  size_t offsetSection = _iSpin == ALPHA
    ? _self->sectionOffsets[AlphaInverses]
    : _self->sectionOffsets[BetaInverses] ;
  size_t offsetWalker  = _iSpin == ALPHA
    ? _iWalker * nDets( _self ) * nMatrixAlpha( _self )
    : _iWalker * nDets( _self ) * nMatrixBeta( _self ) ; 
  size_t offsetDeterminant = _iSpin == ALPHA
    ? _iDet * nMatrixAlpha( _self )
    : _iDet * nMatrixBeta( _self ) ; 
  
  return (cfloat_p *)
    (_self->cData + offsetSection + offsetWalker + offsetDeterminant) ; 
  
}

/**
 * @brief Return the requested spin-gradient from the data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iDet      : Determinant index.
 * @param[in]  _iWalker   : Walker index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the gradient.
 */
static inline cfloat_p * getGradient( const Ensemble_t * _self,
				      const size_t _iWalker,
				      const size_t _iDet,
				      const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  //assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* ifdef BE_ASSERTIVE */

  size_t offsetSection = _iSpin == ALPHA
    ? _self->sectionOffsets[AlphaGradients]
    : _self->sectionOffsets[BetaGradients] ;
  size_t offsetWalker  = _iSpin == ALPHA
    ? _iWalker * nDets( _self ) * nMatrixAlpha( _self ) * nDims
    : _iWalker * nDets( _self ) * nMatrixBeta( _self ) * nDims ; 
  size_t offsetDeterminant = _iSpin == ALPHA
    ? _iDet * nMatrixAlpha( _self ) * nDims
    : _iDet * nMatrixBeta( _self ) * nDims ; 

  return (cfloat_p *)
    (_self->cData + offsetSection + offsetWalker + offsetDeterminant) ; 
  
}

/**
 * @brief Return the requested spin-Laplacian from the data buffer.
 * @note Laplacians are in row-major, regardless of the accelerator.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iDet      : Determinant index.
 * @param[in]  _iWalker   : Walker index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the Laplacian.
 */
static inline cfloat_p * getLaplacian( const Ensemble_t * _self,
				       const size_t _iWalker,
				       const size_t _iDet,
				       const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  //assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->sectionOffsets[AlphaLaplacians]
    : _self->sectionOffsets[BetaLaplacians] ;
  size_t offsetWalker  = _iSpin == ALPHA
    ? _iWalker * nDets( _self ) * nMatrixAlpha( _self )
    : _iWalker * nDets( _self ) * nMatrixBeta( _self ) ; 
  size_t offsetDeterminant = _iSpin == ALPHA
    ? _iDet * nMatrixAlpha( _self )
    : _iDet * nMatrixBeta( _self ) ; 

  return (cfloat_p *)
    (_self->cData + offsetSection + offsetWalker + offsetDeterminant) ; 
  
}

/**
 * @brief Return the requested electron from the data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iWalker  : Walker index.
 * @param[in]  _iEl      : Electron index.
 * @param[out] float_p * : Pointer to the electron.
 */
static inline float_p * getElectron( const Ensemble_t * _self,
				     const size_t _iWalker,
				     const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  //  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->sectionOffsets[ElectronPositions] ;
  size_t offsetElectron = _iWalker * nElec( _self ) + _iEl ; 

  return (float_p *)
    (_self->rData + offsetSection + offsetElectron * nDims) ;
  
}

/**
 * @brief Return the requested displacement from the data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iWalker  : Walker index.
 * @param[in]  _iEl      : Electron index.
 * @param[out] float_p * : Pointer to the displacement.
 */
static inline float_p * getDisplacement( const Ensemble_t * _self,
				         const size_t _iWalker,
				         const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  //assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->sectionOffsets[Displacements] ;
  size_t offsetElectron = _iWalker * nElec( _self ) + _iEl ; 

  return (float_p *)
    (_self->rData + offsetSection + offsetElectron * nDims) ;
  
}

/**
 * @brief Return the requested determinants from the data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iWalker   : Walker index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the walker's spin-determinants.
 */
static inline cfloat_p * getDeterminants( const Ensemble_t * _self,
					  const size_t _iWalker,
					  const size_t _iDet,
					  const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  //assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->sectionOffsets[AlphaDeterminants]
    : _self->sectionOffsets[BetaDeterminants] ;

  return (cfloat_p *)
    (_self->cData + offsetSection + nDets( _self ) * _iWalker + _iDet) ;
  
}

/**
 * @brief Return the requested walker's kinetic energy from the data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iWalker  : Walker index.
 * @param[out] float_p * : Pointer to the walker's kinetic energy.
 */
static inline float_p * getKineticEnergy( const Ensemble_t * _self,
					  const size_t _iWalker ) {

#ifdef BE_ASSERTIVE
  //assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->sectionOffsets[KineticEnergies] ;

  return (float_p *) (_self->rData + offsetSection + _iWalker) ;
  
}

/**
 * @brief Return the requested walker's potential energy from the data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iWalker  : Walker index.
 * @param[out] float_p * : Pointer to the walker's potential energy.
 */
static inline float_p * getPotentialEnergy( const Ensemble_t * _self,
					    const size_t _iWalker ) {

#ifdef BE_ASSERTIVE
  assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->sectionOffsets[PotentialEnergies] ;

  return (float_p *) (_self->rData + offsetSection + _iWalker) ;
  
}

/**
 * @brief Return the requested walker's Jastrow factor from the data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iWalker  : Walker index.
 * @param[out] float_p * : Pointer to the walker's Jastrow factor.
 */
static inline float_p * getJastrowFactor( const Ensemble_t * _self,
					  const size_t _iWalker ) {

#ifdef BE_ASSERTIVE
  assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->sectionOffsets[JastrowFactors] ;

  return (float_p *) (_self->rData + offsetSection + _iWalker) ;
  
}

/**
 * @brief Return the requested walker's Jastrow factor from the data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iWalker  : Walker index.
 * @param[out] float_p * : Pointer to the walker's Jastrow factor.
 */
static inline float_p * getWeight( const Ensemble_t * _self,
				   const size_t _iWalker ) {

#ifdef BE_ASSERTIVE
  assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->sectionOffsets[Weights] ;

  return (float_p *) (_self->rData + offsetSection + _iWalker) ;
  
}

/**
 * @brief Return the requested walker's generation.
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _iWalker : Walker index.
 * @param[out] size_t * : Walker's generation.
 */
static inline size_t * getGeneration( Ensemble_t * _self,
                                      const size_t _iWalker ) {

#ifdef BE_ASSERTIVE
  assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  return _self->generation + _iWalker ;

}

/**
 * @brief Return the requested walker's local energy.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iWalker   : Walker index.
 * @param[out] cfloat_p * : Walker's local energy.
 */
static inline float_p getLocalEnergy( const Ensemble_t * _self,
				      const size_t _iWalker ) {

#ifdef BE_ASSERTIVE
  //assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  size_t offsetKinetic = _self->sectionOffsets[KineticEnergies] ;
  size_t offsetPotential = _self->sectionOffsets[PotentialEnergies] ;

  return _self->rData[offsetKinetic+_iWalker] +
    _self->rData[offsetPotential+_iWalker] ;
  
}

/**
 * @brief Return the requested walker's weighted local energy.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iWalker   : Walker index.
 * @param[out] cfloat_p * : Walker's weighted local energy.
 */
static inline float_p getWeightedLocalEnergy( const Ensemble_t * _self,
					      const size_t _iWalker ) {

  float_p localEnergy = getLocalEnergy( _self, _iWalker ) ;
  float_p weight = * getWeight( _self, _iWalker ) ;

  return localEnergy * weight ;

}

/**
 * @brief Return the ensemble's average weighted local energy.
 * @param[in]  _self      : Ensemble_t object.
 * @param[out] cfloat_p * : Ensemble's average weighted local energy.
 */
static inline float_p getWeightedEnsembleEnergy( const Ensemble_t * _self ) {

  float_p weighted_energies = 0.0, weights = 0.0 ;
  
  for( size_t iWalker=0 ; iWalker<nWalkers( _self ) ; iWalker++ ) {
    weighted_energies += getWeightedLocalEnergy( _self, iWalker ) ;
    weights += * getWeight( _self, iWalker ) ;
  }

  return weighted_energies / weights ;
  
}

/**
 * @brief Calculate the value of a walker's trial wavefunction.
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _wave    : TrialWavefunction_t object.
 * @param[in]  _iWalker : Walker index.
 * @param[out] cfloat_p : The wavefunction value.
 */
static inline cfloat_p getWfnValue( const Ensemble_t * _self,
				    const TrialWavefunction_t * _wave,
				    const size_t _iWalker ) {

#ifdef BE_ASSERTIVE
  assert( _iWalker < nWalkers( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  cfloat_p wfnValue = 0 ;
  
  cfloat_p * alphaDeterminants = getDeterminants( _self, _iWalker, 0, ALPHA ) ;
  cfloat_p * betaDeterminants = getDeterminants( _self, _iWalker, 0, BETA ) ;

  // Accumulate the multi-reference expansion
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    wfnValue += _wave->multiRefCoeffs[iDet] *
      alphaDeterminants[iDet] * betaDeterminants[iDet] ;
  }

  return wfnValue ;
  
}

/**
 * @brief Get the total weight of the ensemble.
 * @param[in] _self    : Ensemble_t object.
 * @param[out] float_p : Total weight.
 */
static inline float_p getTotalWeight( const Ensemble_t * _self ) {

  float_p totalWeight = 0.0 ;
  
  for( size_t iWalker=0 ; iWalker<nWalkers( _self ) ; iWalker++ ) {
    totalWeight += * getWeight( _self, iWalker ) ;
  }

  return totalWeight ;
  
}

/**
 * @brief Get the average energy of the ensemble.
 * @param[in] _self    : Ensemble_t object.
 * @param[out] float_p : Average energy.
 */
static inline float_p getAverageEnergy( const Ensemble_t * _self ) {

  float_p averageEnergy = 0.0 ;
  
  for( size_t iWalker=0 ; iWalker<nWalkers( _self ) ; iWalker++ ) {
    averageEnergy += getLocalEnergy( _self, iWalker ) ;
  }

  return averageEnergy / (float_p) nWalkers( _self ) ;
  
}

// =====================================================================
//                      Getters for the temp buffer
// =====================================================================

/**
 * @brief Return the requested spin-matrix from the temporary data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iDet      : Determinant index.
 * @param[in]  _Thread    : Thread index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the matrix.
 */
static inline cfloat_p * getTempMatrix( const Ensemble_t * _self,
					const size_t _iThread,
					const size_t _iDet,
					const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->t_sectionOffsets[AlphaMatrices]
    : _self->t_sectionOffsets[BetaMatrices] ;
  size_t offsetThread  = _iSpin == ALPHA
    ? _iThread * nDets( _self ) * nMatrixAlpha( _self )
    : _iThread * nDets( _self ) * nMatrixBeta( _self ) ;
  size_t offsetDeterminant = _iSpin == ALPHA
    ? _iDet * nMatrixAlpha( _self )
    : _iDet * nMatrixBeta( _self ) ;

  return (cfloat_p *)
    (_self->cTempData + offsetSection + offsetThread + offsetDeterminant) ;

}

/**
 * @brief Return the requested spin-inverse from the temporary data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iDet      : Determinant index.
 * @param[in]  _iThread   : Thread index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the inverse.
 */
static inline cfloat_p * getTempInverse( const Ensemble_t * _self,
					 const size_t _iThread,
					 const size_t _iDet,
					 const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->t_sectionOffsets[AlphaInverses]
    : _self->t_sectionOffsets[BetaInverses] ;
  size_t offsetThread  = _iSpin == ALPHA
    ? _iThread * nDets( _self ) * nMatrixAlpha( _self )
    : _iThread * nDets( _self ) * nMatrixBeta( _self ) ; 
  size_t offsetDeterminant = _iSpin == ALPHA
    ? _iDet * nMatrixAlpha( _self )
    : _iDet * nMatrixBeta( _self ) ; 

  return (cfloat_p *)
    (_self->cTempData + offsetSection + offsetThread + offsetDeterminant) ; 
  
}

/**
 * @brief Return the requested spin-gradient from the temporary data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iDet      : Determinant index.
 * @param[in]  _iThread   : Thread index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the gradient.
 */
static inline cfloat_p * getTempGradient( const Ensemble_t * _self,
					  const size_t _iThread,
					  const size_t _iDet,
					  const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->t_sectionOffsets[AlphaGradients]
    : _self->t_sectionOffsets[BetaGradients] ;
  size_t offsetThread  = _iSpin == ALPHA
    ? _iThread * nDets( _self ) * nMatrixAlpha( _self ) * nDims
    : _iThread * nDets( _self ) * nMatrixBeta( _self ) * nDims ; 
  size_t offsetDeterminant = _iSpin == ALPHA
    ? _iDet * nMatrixAlpha( _self ) * nDims
    : _iDet * nMatrixBeta( _self ) * nDims ; 
  
  return (cfloat_p *)
    (_self->cTempData + offsetSection + offsetThread + offsetDeterminant) ; 
  
}

/**
 * @brief Return the requested spin-Laplacian from the temporary data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iDet      : Determinant index.
 * @param[in]  _iThread   : Thread index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the Laplacian.
 */
static inline cfloat_p * getTempLaplacian( const Ensemble_t * _self,
					   const size_t _iThread,
					   const size_t _iDet,
					   const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->t_sectionOffsets[AlphaLaplacians]
    : _self->t_sectionOffsets[BetaLaplacians] ;
  size_t offsetThread  = _iSpin == ALPHA
    ? _iThread * nDets( _self ) * nMatrixAlpha( _self )
    : _iThread * nDets( _self ) * nMatrixBeta( _self ) ; 
  size_t offsetDeterminant = _iSpin == ALPHA
    ? _iDet * nMatrixAlpha( _self )
    : _iDet * nMatrixBeta( _self ) ; 

  return (cfloat_p *)
    (_self->cTempData + offsetSection + offsetThread + offsetDeterminant) ; 
  
}

/**
 * @brief Return the requested electron from the temporary data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iThread  : Thread index.
 * @param[in]  _iEl      : Electron index.
 * @param[out] float_p * : Pointer to the electron.
 */
static inline float_p * getTempElectron( const Ensemble_t * _self,
					 const size_t _iThread,
					 const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->t_sectionOffsets[ElectronPositions] ;
  size_t offsetElectron = _iThread * nElec( _self ) + _iEl ; 

  return (float_p *)
    (_self->rTempData + offsetSection + offsetElectron * nDims) ;
  
}

/**
 * @brief Return the requested electron displacement from the temporary 
 *        data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iThread  : Thread index.
 * @param[in]  _iEl      : Electron index.
 * @param[out] float_p * : Pointer to the electron displacement.
 */
static inline float_p * getTempDisplacement( const Ensemble_t * _self,
					     const size_t _iThread,
					     const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->t_sectionOffsets[Displacements] ;
  size_t offsetElectron = _iThread * nElec( _self ) + _iEl ; 

  return (float_p *)
    (_self->rTempData + offsetSection + offsetElectron * nDims) ;
  
}

/**
 * @brief Return the requested quantum force from the temporary data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iThread  : Thread index.
 * @param[in]  _iEl      : Electron index.
 * @param[out] float_p * : Pointer to the quantum force vector.
 */
static inline float_p * getTempQuantumForce( const Ensemble_t * _self,
					      const size_t _iThread,
					      const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->t_sectionOffsets[QuantumForces] ;
  size_t offsetElectron = _iThread * nElec( _self ) + _iEl ; 

  return (float_p *)
    (_self->rTempData + offsetSection + offsetElectron * nDims) ;
  
}


/**
 * @brief Return the requested determinants from the temporary data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iThread  : Thread index.
 * @param[in]  _iSpin    : Spin index.
 * @param[out] float_p * : Pointer to the walker's spin-determinants.
 */
static inline cfloat_p * getTempDeterminants( const Ensemble_t * _self,
					      const size_t _iThread,
					      const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->t_sectionOffsets[AlphaDeterminants]
    : _self->t_sectionOffsets[BetaDeterminants] ;
  size_t offsetThread = _iThread * nDets( _self ) ;
  
  return (cfloat_p *) (_self->cTempData + offsetSection + offsetThread) ;
  
}

/**
 * @brief Return the requested walker's kinetic energy from the temporary data 
 *        buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iThread  : Thread index.
 * @param[out] float_p * : Pointer to the walker's kinetic energy in the 
 *                         temporary data buffer.
 */
static inline float_p * getTempKineticEnergy( const Ensemble_t * _self,
					      const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->t_sectionOffsets[KineticEnergies] ;

  return (float_p *) (_self->rTempData + offsetSection + _iThread) ;
  
}

/**
 * @brief Return the requested walker's potential energy from the temporary 
 *        data buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iThread  : Thread index.
 * @param[out] float_p * : Pointer to the walker's potential energy in the 
 *                         temporary data buffer.
 */
static inline float_p * getTempPotentialEnergy( const Ensemble_t * _self,
						const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->t_sectionOffsets[PotentialEnergies] ;

  return (float_p *) (_self->rTempData + offsetSection + _iThread) ;
  
}

/**
 * @brief Return the requested walker's Jastrow factor from the temporary data 
 *        buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iThread  : Thread index.
 * @param[out] float_p * : Pointer to the walker's Jastrow factor in the 
 *                         temporary data buffer.
 */
static inline float_p * getTempJastrowFactor( const Ensemble_t * _self,
					      const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->t_sectionOffsets[JastrowFactors] ;

  return (float_p *) (_self->rTempData + offsetSection + _iThread) ;
  
}

/**
 * @brief Return the requested walker's Jastrow factor from the temporary data 
 *        buffer.
 * @param[in]  _self     : Ensemble_t object.
 * @param[in]  _iThread  : Thread index.
 * @param[out] float_p * : Pointer to the walker's Jastrow factor in the 
 *                         temporary data buffer.
 */
static inline float_p * getTempWeight( const Ensemble_t * _self,
				       const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->t_sectionOffsets[Weights] ;

  return (float_p *) (_self->rTempData + offsetSection + _iThread) ;
  
}

/**
 * @brief Return the requested walker's potential energy from the temporary 
 *        data buffer.
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _iThread : Thread index.
 * @param[out] float_p  : Pointer to the walker's potential energy in the 
 *                        temporary data buffer.
 */
static inline float_p getTempLocalEnergy( const Ensemble_t * _self,
					  const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetKinetic = _self->t_sectionOffsets[KineticEnergies] ;
  size_t offsetPotential = _self->t_sectionOffsets[PotentialEnergies] ;

  return _self->rTempData[offsetKinetic+_iThread] +
    _self->rTempData[offsetPotential+_iThread] ;

}

/**
 * @brief Return the requested difference in Slater matrix from the temporary 
 *        data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iThread   : Thread index.
 * @param[in]  _iSpin     : Spin index.
 * @param[out] cfloat_p * : Pointer to the start of the temporary buffer 
 *                          spin-determinants.
 */
static inline cfloat_p * getTempDelta( const Ensemble_t * _self,
				       const size_t _iThread,
				       const size_t _iDet,
				       const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iDet < nDets( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _iSpin == ALPHA
    ? _self->t_sectionOffsets[Delta]
    : _self->t_sectionOffsets[Delta] ;
  size_t offsetThread  = _iSpin == ALPHA
    ? _iThread * nDets( _self ) * nAlpha( _self )
    : _iThread * nDets( _self ) * nBeta( _self ) ;
  size_t offsetVector  = _iSpin == ALPHA
    ? _iDet * nAlpha( _self )
    : _iDet * nBeta( _self ) ;
  
  return (cfloat_p *)
    (_self->cTempData + offsetSection + offsetThread + offsetVector) ;
  
}

/**
 * @brief Return the requested determinants from the temporary data buffer.
 * @param[in]  _self      : Ensemble_t object.
 * @param[in]  _iThread   : Thread index.
 * @param[out] cfloat_p * : Pointer to the start of the temporary buffer 
 *                          compute space.
 */
static inline cfloat_p * getTempComputeSpace( const Ensemble_t * _self,
					      const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  size_t offsetSection = _self->t_sectionOffsets[ComputeSpace] ;
  size_t offsetThread = _iThread * NDETSMAX * nElec( _self ) ;

  return (cfloat_p *) (_self->cTempData + offsetSection + offsetThread) ;
  
}

/**
 * @brief Calculate the value of a temporary walker trial wavefunction.
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _wave    : TrialWavefunction_t object.
 * @param[in]  _iThread : Thread index.
 * @param[out] cfloat_p : The wavefunction value.
 */
static inline cfloat_p getTempWfnValue( const Ensemble_t * _self,
					const TrialWavefunction_t * _wave,
					const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */

  cfloat_p wfnValue = 0 ;
  
  cfloat_p * alphaDeterminants = getTempDeterminants( _self, _iThread, ALPHA ) ;
  cfloat_p * betaDeterminants = getTempDeterminants( _self, _iThread, BETA ) ;
  
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    wfnValue += _wave->multiRefCoeffs[iDet] *
      alphaDeterminants[iDet] * betaDeterminants[iDet] ;
  }

  return wfnValue ;
  
}

// =====================================================================
//                          General Functions
// =====================================================================

/**
 * @brief Return a thread's distance table of the requested type 
 *        (see enum DistanceTable).
 * @param[in] _iThread       : Thread index.
 * @param[in] _distanceTable : Distance table type.
 * @param[out] float_p *     : The thread's distance table. NULL if the distance
 *                             table doesn't exist.
 */
static inline float_p * getTempDistanceTable( const size_t _iThread,
					      const int _distanceTable ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  switch( _distanceTable ) {
  case VECTOR_EN:
    return vectorDistanceTables_en + _iThread * NELECMAX * NCENTRESMAX * nDims ;
    break ;
  case SQUARE_EN:
    return distanceTables_en + _iThread * NELECMAX * NCENTRESMAX ;
    break ;
  case VECTOR_EE:
    return vectorDistanceTables_ee + _iThread * NELECMAX * NELECMAX * nDims ;
    break ;
  case SQUARE_EE:
    return distanceTables_ee + _iThread * NELECMAX * NELECMAX ;
    break ;
  default:
    printf( " Distance Table %d not understood.\n", _distanceTable ) ;
    return NULL ;
    break ;
  }
  
}

static inline void getWalkerPointer( const Ensemble_t * _self,
			             const size_t _iWalker,
			             void * _pointer[] ) {
  // Zero the pointer before we start copying
  for( size_t iSec=0 ; iSec<NSECTIONS ; iSec++ ) _pointer[iSec] = NULL ;

  _pointer[ElectronPositions] =
    (void *) getElectron( _self, _iWalker, 0 ) ;
  _pointer[KineticEnergies] =
    (void *) getKineticEnergy( _self, _iWalker ) ;
  _pointer[PotentialEnergies] =
    (void *) getPotentialEnergy( _self, _iWalker ) ;
  _pointer[JastrowFactors] =
    (void *) getJastrowFactor( _self, _iWalker ) ;
  _pointer[Displacements] =
    (void *) getDisplacement( _self, _iWalker, 0 ) ;
  _pointer[Weights] =
    (void *) getWeight( _self, _iWalker ) ;
  _pointer[AlphaMatrices] =
    (void *) getMatrix( _self, _iWalker, 0, ALPHA ) ;
  _pointer[BetaMatrices] =
    (void *) getMatrix( _self, _iWalker, 0, BETA ) ;
  _pointer[AlphaInverses] =
    (void *) getInverse( _self, _iWalker, 0, ALPHA ) ;
  _pointer[BetaInverses] =
    (void *) getInverse( _self, _iWalker, 0, BETA ) ;
  _pointer[AlphaGradients] =
    (void *) getGradient( _self, _iWalker, 0, ALPHA ) ;
  _pointer[BetaGradients] =
    (void *) getGradient( _self, _iWalker, 0, BETA ) ;
  _pointer[AlphaLaplacians] =
    (void *) getLaplacian( _self, _iWalker, 0, ALPHA ) ;
  _pointer[BetaLaplacians] =
    (void *) getLaplacian( _self, _iWalker, 0, BETA ) ;
  _pointer[AlphaDeterminants] =
    (void *) getDeterminants( _self, _iWalker, 0, ALPHA ) ;
  _pointer[BetaDeterminants] =
    (void *) getDeterminants( _self, _iWalker, 0, BETA ) ;

}

static inline void getTempPointer( const Ensemble_t * _self,
                                   const size_t _iThread,
				   void * _pointer[] ) {

  // Zero the pointer before we start copying
  for( size_t iSec=0 ; iSec<NSECTIONS ; iSec++ ) _pointer[iSec] = NULL ;

  _pointer[ElectronPositions] =
    (void *) getTempElectron( _self, _iThread, 0 ) ;
  _pointer[KineticEnergies] =
    (void *) getTempKineticEnergy( _self, _iThread ) ;
  _pointer[PotentialEnergies] =
    (void *) getTempPotentialEnergy( _self, _iThread ) ;
  _pointer[JastrowFactors] =
    (void *) getTempJastrowFactor( _self, _iThread ) ;
  _pointer[Displacements] =
    (void *) getTempDisplacement( _self, _iThread, 0 ) ;
  _pointer[Weights] =
    (void *) getTempWeight( _self, _iThread ) ;
  _pointer[AlphaMatrices] =
    (void *) getTempMatrix( _self, _iThread, 0, ALPHA ) ;
  _pointer[BetaMatrices] =
    (void *) getTempMatrix( _self, _iThread, 0, BETA ) ;
  _pointer[AlphaInverses] =
    (void *) getTempInverse( _self, _iThread, 0, ALPHA ) ;
  _pointer[BetaInverses] =
    (void *) getTempInverse( _self, _iThread, 0, BETA ) ;
  _pointer[AlphaGradients] =
    (void *) getTempGradient( _self, _iThread, 0, ALPHA ) ;
  _pointer[BetaGradients] =
    (void *) getTempGradient( _self, _iThread, 0, BETA ) ;
  _pointer[AlphaLaplacians] =
    (void *) getTempLaplacian( _self, _iThread, 0, ALPHA ) ;
  _pointer[BetaLaplacians] =
    (void *) getTempLaplacian( _self, _iThread, 0, BETA ) ;
  _pointer[AlphaDeterminants] =
    (void *) getTempDeterminants( _self, _iThread, ALPHA ) ;
  _pointer[BetaDeterminants] =
    (void *) getTempDeterminants( _self, _iThread, BETA ) ;

}

/**
 * @brief Check that a Slater matrix and its inverse yield the identity for a 
 *        walker in the ensemble. Note that the Slater matrix is in row-major 
 *        and the inverse is in column-major.
 * @param[in]  _matrix  : The matrix.
 * @param[in]  _inverse : The inverse.
 * @param[in]  _nRows   : Number of rows.
 * @param[in]  _nCols   : Number of columns.
 * @param[out] size_t   : Zero if we get the identity, one otherwise.
 */
static inline size_t checkIdentity( const Ensemble_t * _self,
				    const size_t _iWalker,
				    const size_t _iSpin ) {

#ifdef BE_ASSERTIVE
  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iSpin == ALPHA || _iSpin == BETA ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  cfloat_p diagonal[RANKMAX] = { 0 } ;

  // Get our matrix and inverse from the buffer
  cfloat_p * matrix = getMatrix( _self, _iWalker, 0, _iSpin ) ;
  cfloat_p * inverse = getInverse( _self, _iWalker, 0, _iSpin ) ;

  size_t stride = nPad( _self, _iSpin ), rank = nSpinElec( _self, _iSpin ) ;

  for( size_t iRow=0 ; iRow<rank ; iRow++ ) {
     for( size_t iCol=0 ; iCol<rank ; iCol++ ) {
        diagonal[iRow] +=
	  matrix[iRow * stride + iCol] * inverse[iRow * stride + iCol] ;
     }
     // Check we recover the identity, within the numerical precision
     if( cabs_p(diagonal[iRow] - 1) > TOLERANCE ) {
        printf( " *** Diagonal Element %zu is not unity: %f.\n",
		        iRow, diagonal[iRow] ) ;
        return 1 ;
     }
  }

  return 0 ;

}

#endif /* #ifndef ENSEMBLE_QUERY_H */
