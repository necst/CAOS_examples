/**
 * @file ensemble.h
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 *
 * @brief Walker ensemble representation. Read ensemble.readme for various
 *        decisions which have been made in its construction. Furthermore,
 *        please stick to these descisions and don't add functionality which
 *        doesn't belong in here.
 */
#ifndef ENSEMBLE_H
#define ENSEMBLE_H

#include <global.h>
#include <trial_wavefunction/trial_wavefunction.h>
#include <utilities/density.h>

// Resources scale as ( 4n^2 + 3n + 3 ) * NWALKERSMAX * sizeof(float_p)
// For 10000 walkers with 128 electrons (closed-shell), this is just over 1GB
// (double precision)
#define NWALKERSMAX 8192
#define NDETSMAX 32
#define RANKMAX 128
#define NCENTRESMAX 128
#define NELECMAX 256
#define NSECTIONS_REAL 7
#define NSECTIONS_COMPLEX 12
#define NSECTIONS (NSECTIONS_REAL + NSECTIONS_COMPLEX)

enum DistanceTable { VECTOR_EN, SQUARE_EN, VECTOR_EE, SQUARE_EE } ;
enum BufferSections {
  // Real-Valued parts
  KineticEnergies, PotentialEnergies, JastrowFactors,
  Weights, Displacements, ElectronPositions, QuantumForces,
  // Complex-Valued parts
  AlphaMatrices, BetaMatrices,
  AlphaGradients, BetaGradients, 
  AlphaLaplacians, BetaLaplacians,
  AlphaInverses, BetaInverses,
  AlphaDeterminants, BetaDeterminants,
  Delta, ComputeSpace
} ;

float_p vectorDistanceTables_ee[NELECMAX*NELECMAX*NTHREADSMAX*3] ;
float_p vectorDistanceTables_en[NELECMAX*NCENTRESMAX*NTHREADSMAX*3] ;
float_p distanceTables_ee[NELECMAX*NELECMAX*NTHREADSMAX] ;
float_p distanceTables_en[NELECMAX*NCENTRESMAX*NTHREADSMAX] ;
void * walker_pointer_a[NTHREADSMAX*NSECTIONS] ;
void * walker_pointer_b[NTHREADSMAX*NSECTIONS] ;
float_p diffusiveDistanceSq[NTHREADSMAX] ;

// If MINIAPP hasn't been defined, then we declare the Ensemble_t here.
// We statically allocate as much as possible while retaining the most
// runtime flexibility that we can.
#include <ensemble.dump>
void ensemble_initialise( Ensemble_t * _self ) ;

// Function Prototypes
// I'm not really sure whether it's bad practice to just put all the prototypes
// here. I understand if you're using fairly generic function names, you
// don't want to introduce these into the namespace of any compilation unit
// which inclues the header, but our function names are pretty unique.
void ensemble_print_walker( const Ensemble_t * _self,
			    const size_t _iWalker ) ;
void ensemble_print_temp( const Ensemble_t * _self, const size_t _iThread ) ;
void ensemble_dump( const Ensemble_t * _self ) ;
void ensemble_accumulate_density( const Ensemble_t * _self,
                                  DensityPtr_t _density ) ;
float_p ensemble_calc_potential( const Ensemble_t * _self,
				 const TrialWavefunction_t * _wave,
				 const size_t _iThread ) ;
float_p ensemble_calc_dpotential( const Ensemble_t * _self,
				  const TrialWavefunction_t * _wave,
				  const size_t _iThread,
				  const size_t _iWalker,
				  const size_t _iEl ) ;
float_p ensemble_calc_dkinetic( Ensemble_t * _self,
				const TrialWavefunction_t * _wave,
				const size_t _iThread,
				const size_t _iWalker,
				const size_t _iEl ) ;
float_p ensemble_calc_kinetic( Ensemble_t * _self,
			       const TrialWavefunction_t * _wave,
			       const size_t _iThread ) ;
void ensemble_update_distance_tables( const Ensemble_t * _self,
				      const TrialWavefunction_t * _wave,
				      const size_t _iThread,
				      const size_t _iEl ) ;
void ensemble_set_distance_tables( const Ensemble_t * _self,
				   const TrialWavefunction_t * _wave,
				   const size_t _iThread ) ;
void ensemble_calc_slater( Ensemble_t * _self,
			   const TrialWavefunction_t * _wave,
			   const size_t _iThread,
			   const size_t _iSpin ) ;
void ensemble_calc_delta( Ensemble_t * _self,
			  const TrialWavefunction_t * _wave,
			  const size_t _iThread,
			  const size_t _iWalker,
			  const size_t _iEl ) ;
void ensemble_copy_temp( Ensemble_t * _self,
			 const TrialWavefunction_t * _wave,
			 const size_t _iThread,
			 const size_t _iWalker,
			 const string _direction ) ;
void ensemble_displace_temp( Ensemble_t * _self,
			     const TrialWavefunction_t * _wave,
			     const size_t _iThread,
			     const size_t _iEl,
			     const float_p _dx ) ;
void ensemble_diffuse_temp( Ensemble_t * _self,
                             const TrialWavefunction_t * _wave,
                             const size_t _iThread,
                             const size_t _iEl,
                             const float_p _dtau ) ;
float_p ensemble_calc_unreweightedVariance( const Ensemble_t * _self ) ;
void ensemble_copy( Ensemble_t * _self,
		    const Ensemble_t * _source ) ;
void ensemble_reject_move( Ensemble_t * _self,
			   const TrialWavefunction_t * _wave,
			   const size_t _iThread,
			   const size_t _iWalker,
			   const size_t _iEl ) ;
void ensemble_accept_move( Ensemble_t * _self,
			   const TrialWavefunction_t * _wave,
			   const size_t _iThread,
			   const size_t _iWalker,
			   const size_t _iEl ) ;
int ensemble_calc_acceptance( Ensemble_t * _self,
			      const TrialWavefunction_t * _wave,
			      const size_t _iThread,
			      const size_t _iWalker,
			      const size_t _iEl,
			      const float_p _random_scale ) ;
void ensemble_calc_quantum_force( Ensemble_t * _self,
				  const TrialWavefunction_t * _wave,
				  const size_t _iThread,
				  const size_t _iEl ) ;
bool ensemble_acceptance_dmc( Ensemble_t * _self,
			      const TrialWavefunction_t * _wave,
			      const size_t _iThread,
			      const size_t _iWalker,
			      const size_t _iEl,
			      const float_p _dtau ) ;
bool ensemble_acceptance_vmc( Ensemble_t * _self,
			      const TrialWavefunction_t * _wave,
			      const size_t _iThread,
			      const size_t _iWalker,
			      const size_t _iEl,
			      const float_p _random_scale ) ;

void ensemble_parallel_update_energy( Ensemble_t * _self, 
				      Ensemble_t * _ensemble, 
				      const TrialWavefunction_t * _wave, 
				      const size_t _iEl, 
				      const bool * _wasAccepted ) ;
size_t ensemble_parallel_calc_acceptance( Ensemble_t * _self, 
					  Ensemble_t * _ensemble, 
					  const TrialWavefunction_t * _wave, 
					  const size_t _iEl, 
					  bool * _wasAccepted ) ;
void ensemble_parallel_displace( Ensemble_t * _self, const float_p _dx ) ;
void ensemble_write_xml( const Ensemble_t * _self ) ;

void ensemble_branch( Ensemble_t * _self,
		      const float_p _spawnWeight ) ;
void ensemble_constant_population( Ensemble_t * _self, 
				   const float_p _spawn_weight ) ;
void ensemble_spawn( struct Ensemble * _self,
                     const size_t _iThread,
                     const size_t _dest_index,
                     const size_t _source_index ) ;
size_t ensemble_compress( struct Ensemble * _self ) ;
void ensemble_copy_walker( const Ensemble_t * _self,
                           void * _dest[],
                           void * _src[] ) ;

#endif /* #ifndef ENSEMBLE_H */

