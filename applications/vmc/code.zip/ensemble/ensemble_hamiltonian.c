/**
 * @file ensemble_hamiltonian.c
 * @author Salvatore Cardamone
 * @email sc2018@cam.ac.uk
 * @brief Methods for computing contributions to the local
 *        energy of a walker.
 */
#include <ensemble/ensemble.h>
#include <ensemble/ensemble_query.h>

/**
 * @brief Compute the potential energy of a thread's temporary walker.
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _wave    : TrialWavefunction_t object.
 * @param[in]  _iWalker : Walker index.
 * @param[out] float_p  : Potential energy of the walker.
 */
float_p ensemble_calc_potential( const Ensemble_t * _self,
				 const TrialWavefunction_t * _wave,
				 const size_t _iThread ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
#endif /* #ifdef BE_ASSERTIVE */

  // Zero the nuclear-electron and electron-electron potential energy
  // accumulators
  float_p vne = 0, vee = 0 ; size_t jAtom = 0 ;

  // Do pairwise atom-electron interactions
  for( size_t iAtomType=0 ; iAtomType<_wave->nAtomTypes ; iAtomType++ ) {
    for( size_t iAtom=0 ; iAtom<_wave->nAtoms[iAtomType] ; iAtom++ ) {

      for( size_t iEl=0 ; iEl<nElec( _self ) ; iEl++ ) {

	      // Get the electronic position vector from the ensemble and the atomic
	      // position vector from the trial wavefunction
	      float_p * pos_iElec = getTempElectron( _self, _iThread, iEl ) ;
	      float_p pos_iAtom[3] = {
	        _wave->centre_x[jAtom],
	        _wave->centre_y[jAtom],
	        _wave->centre_z[jAtom]
	      } ;

	      // Electron-Nuclear distance and square distance
	      float_p rne[3] = {
	        pos_iAtom[0] - pos_iElec[0],
	        pos_iAtom[1] - pos_iElec[1],
	        pos_iAtom[2] - pos_iElec[2]
	      } ; 

	      float_p rneSq = rne[0]*rne[0] + rne[1]*rne[1] + rne[2]*rne[2] ;

	      // Accumulate the electron-nuclear potential energy
	      vne -= (float_p) _wave->nuclearCharge[iAtomType] / sqrt( rneSq ) ;

      }
      
      jAtom++ ;

    }
  }

  // Do pairwise electron-electron interactions
  for( size_t iEl=0 ; iEl<nElec( _self ) ; iEl++ ) {
    float_p * pos_iElec = getTempElectron( _self, _iThread, iEl ) ;
    for( size_t jEl=iEl+1 ; jEl<nElec( _self ) ; jEl++ ) {
      float_p * pos_jElec = getTempElectron( _self, _iThread, jEl ) ;

      // Electron-Electron distance and square distance
      float_p ree[3] = {
	      pos_iElec[0] - pos_jElec[0],
	      pos_iElec[1] - pos_jElec[1],
	      pos_iElec[2] - pos_jElec[2]
      } ; 

      float_p reeSq = ree[0]*ree[0] + ree[1]*ree[1] + ree[2]*ree[2] ;

      // Accumulate the electron-electron repulsion
      vee += 1.0 / sqrt( reeSq ) ;

    }
  }

  // Add the nuclear repulsion energy and return the total potential energy for
  // the walker
  return vne + vee + _wave->nuclearRepulsion ;
  
}

/**
 * @brief Compute the change in potential energy resulting from displacement of
 *        the electron.
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _wave    : TrialWavefunction_t object.
 * @param[in]  _iThread : Thread index.
 * @param[in]  _iWalker : Walker index.
 * @param[in]  _iEl     : Electron index.
 * @param[out] float_p  : Change in potential energy.
 */
float_p ensemble_calc_dpotential( const Ensemble_t * _self,
				  const TrialWavefunction_t * _wave,
				  const size_t _iThread,
				  const size_t _iWalker,
				  const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  // Zero our accumulators for nuclear-electron and electron-electron
  // potential energies
  float_p dvne = 0, dvee = 0 ; size_t jAtom = 0 ;

  size_t old_offset_en = nElec( _self ) * _wave->nCentres ;
  size_t old_offset_ee = nElec( _self ) * nElec( _self ) ;
  size_t new_offset_en = _iEl * _wave->nCentres ;
  size_t new_offset_ee = _iEl * nElec( _self ) ;
  // Get old and new square distances. Remember when we updated the distance
  // tables, we placed the old square distances at the end of the distance
  // tables for this very reason!
  float_p * old_en_sq =
    getTempDistanceTable( _iThread, SQUARE_EN ) + old_offset_en ;
  float_p * old_ee_sq =
    getTempDistanceTable( _iThread, SQUARE_EE ) + old_offset_ee ;
  float_p * new_en_sq =
    getTempDistanceTable( _iThread, SQUARE_EN ) + new_offset_en ;
  float_p * new_ee_sq =
    getTempDistanceTable( _iThread, SQUARE_EE ) + new_offset_ee ;
    
  // Do pairwise nuclear-electron interactions and compute the change in energy
  for( size_t iAtomType=0 ; iAtomType<_wave->nAtomTypes ; iAtomType++ ) {
    for( size_t iAtom=0 ; iAtom<_wave->nAtoms[iAtomType] ; iAtom++ ) {
      
      float_p inv_new = 1.0 / sqrt( new_en_sq[jAtom] ) ;
      float_p inv_old = 1.0 / sqrt( old_en_sq[jAtom] ) ;
      float_p delta_dist = inv_new - inv_old ;

      dvne -= (float_p) _wave->nuclearCharge[iAtomType] * delta_dist ;

      jAtom++ ;

    }
  }

  // Loop over electron's other than the one we've moved and compute the
  // change in energy
  for( size_t jEl=0 ; jEl<nElec( _self ) ; jEl++ ) {

    if( jEl == _iEl ) continue ;

    dvee += ( 1.0 / sqrt( new_ee_sq[jEl] ) - 1.0 / sqrt( old_ee_sq[jEl] ) ) ;  

  }

  return dvne + dvee ;

}



/**
 * @brief Compute the kinetic energy of the Slater trial wavefunction
 *        at an electron's position.
 * @param[in]  _self       : Ensemble_t object.
 * @param[in]  _inv        : Each reference's inverse column.
 * @param[in]  _laplSlater : Each reference's laplacian wrt. elec position.
 * @param[in]  _iEl        : Electron index.
 * @param[out] float_p     : Trial wavefunction kinetic energy.
 */
static float_p ensemble_kinetic_slat( const Ensemble_t * _self,
				      cfloat_p ** _inv,
				      cfloat_p ** _laplSlater,
              cfloat_p * _multirefFactors,
				      const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */

  float_p electronKinetic = 0 ;
  
  // Compute the kinetic energy
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    for( size_t iMO=0 ; iMO<nSpinElec( _self, _iEl ) ; iMO++ ) {

      electronKinetic -= creal_p( _multirefFactors[iDet] *  _inv[iDet][iMO] * _laplSlater[iDet][iMO] ) ;

    }	
  }

  return electronKinetic ;
  
}

/**
 * @brief Calculate the change in kinetic energy resulting from the displacement
 *        of a single electron.
 * @note I don't seem to be able to get Equation (121) in the CASINO manual to 
 *       work, but this implementation is fine since we've already updated the 
 *       temporary walker's inverse matrix.
 * @note It's work pointing out that since an electron has been displaced, the 
 *       wavefunction for this electron's spin state
 *       has also changed. As such, every electron of the same spin's kinetic 
 *       energy has also changed, even if their Slater rows haven't (the entire 
 *       inverse has been altered by the Sherman-Morrison update).
 *       The kinetic energy is a wavefunction property, we're just sampling the 
 *       kinetic energy with the electrons! So, must loop over kinetic energy of
 *       every electron in the same spin-state!
 * @param[in]  _self    : Ensemble_t object.
 * @param[in]  _wave    : TrialWavefunction_t object.
 * @param[in]  _iThread : Thread index.
 * @param[in]  _iWalker : Walker index.
 * @param[in]  _iEl     : Electron index.
 * @param[out] float_p  : Change in kinetic energy from electron displacement.
 */
float_p ensemble_calc_dkinetic( Ensemble_t * _self,
				const TrialWavefunction_t * _wave,
				const size_t _iThread,
				const size_t _iWalker,
				const size_t _iEl ) {

#ifdef BE_ASSERTIVE
  assert( _iThread < NTHREADSMAX ) ;
  assert( _iWalker < nWalkers( _self ) ) ;
  assert( _iEl < nElec( _self ) ) ;
#endif /* #ifdef BE_ASSERTIVE */
  
  // Get the spin, spin-index and number of electrons of this spin state for the
  // electron we've displaced
  size_t iSpin = spin( _self, _iEl ) ;
  size_t localElecIdx = spinElec( _self, _iEl ) ;
  size_t nElec = nSpinElec( _self, iSpin ) ;
  size_t stride = nPad( _self, iSpin ) ;

  // Get the electron position and evaluate the Laplacian matrix rows
  size_t en_offset = _iEl * _wave->nCentres ;
  float_p * vec_en =
    getTempDistanceTable( _iThread, VECTOR_EN ) + en_offset * nDims ;
  float_p * sq_en  =
    getTempDistanceTable( _iThread, SQUARE_EN ) + en_offset ;

  cfloat_p * slaterRows[NDETSMAX] = { NULL } ;
  cfloat_p * laplacianRows[NDETSMAX] = { NULL } ;
  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    slaterRows[iDet] =
	    getTempMatrix( _self, _iThread, iDet, iSpin ) + localElecIdx * stride ;
    laplacianRows[iDet] =
      getTempLaplacian( _self, _iThread, iDet, iSpin ) + localElecIdx * stride ;
  }

  _wave->evaluate( _wave, _iThread, vec_en, sq_en, iSpin, slaterRows ) ;
  _wave->laplacian( _wave, _iThread, vec_en, iSpin, laplacianRows ) ;

  //size_t offset_en = _iEl * _wave->nCentres ;
  //float_p * vec_en =
  //  getTempDistanceTable( _iThread, VECTOR_EN ) + en_offset * nDims ;

  //_wave->laplacian( _wave, _iThread, vec_en, iSpin, laplacianRows ) ;
  
  float_p old_kin = 0, new_kin = 0 ;


  // Compute multireference multiplication
  cfloat_p * pOldMultirefFactors = (cfloat_p *) calloc( nDets( _self ), sizeof(cfloat_p) ) ;
  cfloat_p * pNewMultirefFactors = (cfloat_p *) calloc( nDets( _self ), sizeof(cfloat_p) ) ;

  cfloat_p old_wavefunction = getWfnValue( _self, _wave, _iWalker ) ; 
  cfloat_p new_wavefunction = getTempWfnValue( _self, _wave, _iThread ) ; 

  //print( "old_wavefunction = %.12lf new_wavefunction = %.12lf\n", old_wavefunction, new_wavefunction ) ;

  for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
    // Compute old multireference multiplication factors
    cfloat_p old_det_alpha = getDeterminants( _self, _iWalker, iDet, ALPHA )[0] ;
    cfloat_p old_det_beta = getDeterminants( _self, _iWalker, iDet, BETA )[0] ;
    pOldMultirefFactors[iDet] = old_det_alpha * old_det_beta / old_wavefunction ; 

    // Compute new multireference multiplication factors
    cfloat_p new_det_alpha = getTempDeterminants( _self, _iThread, ALPHA )[iDet] ;
    cfloat_p new_det_beta = getTempDeterminants( _self, _iThread, BETA )[iDet] ;
    pNewMultirefFactors[iDet] = new_det_alpha * new_det_beta / new_wavefunction ; 
  }

  // Loop over all electrons in this spin-state and evaluate how their kinetic
  // energies have changed.
  for( localElecIdx=0 ; localElecIdx<nElec ; localElecIdx++ ) {

    size_t offset = localElecIdx * stride ;

    cfloat_p * old_laplacian[NDETSMAX] = { NULL } ;
    cfloat_p * new_laplacian[NDETSMAX] = { NULL } ;
    cfloat_p * old_inverse[NDETSMAX] = { NULL } ;
    cfloat_p * new_inverse[NDETSMAX] = { NULL } ;

    // Get the corresponding inverse and Laplacian rows from the ensemble and
    // temporary walker
    for( size_t iDet=0 ; iDet<nDets( _self ) ; iDet++ ) {
      old_laplacian[iDet] =
	      getLaplacian( _self, _iWalker, iDet, iSpin ) + offset ;
      new_laplacian[iDet] =
	      getTempLaplacian( _self, _iThread, iDet, iSpin ) + offset ;
      old_inverse[iDet] =
	      getInverse( _self, _iWalker, iDet, iSpin ) + offset ;
      new_inverse[iDet] =
	      getTempInverse( _self, _iThread, iDet, iSpin ) + offset ;
    }

    old_kin += ensemble_kinetic_slat( _self, old_inverse, old_laplacian, pOldMultirefFactors, _iEl ) ;
    new_kin += ensemble_kinetic_slat( _self, new_inverse, new_laplacian, pNewMultirefFactors, _iEl ) ;
    
  }

  free( pOldMultirefFactors ) ; pOldMultirefFactors = NULL;
  free( pNewMultirefFactors ) ; pNewMultirefFactors = NULL;

  // Return the difference between the kinetic energies!
  return 0.5 * (new_kin - old_kin) ;
  
}

