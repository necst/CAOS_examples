/**
 * @file   panic.h
 * @author Salvatore Cardamone
 * @brief  Functions for error handling.
 */
#ifndef PANIC_H
#define PANIC_H

// Colour codes for some nice-looking printing
#ifndef SUPRESSCOLOR
#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"
#else
#define KNRM  ""
#define KRED  ""
#define KGRN  ""
#define KYEL  ""
#define KBLU  ""
#define KMAG  ""
#define KCYN  ""
#define KWHT  ""
#endif /* ifndef SUPRESSCOLOR */

/**
 * @brief Flag an error as either a warning, systemic error or fatal error. The first two just report to the terminal,
 *         the third also terminates the program.
 * @param[in] severity     : Severity of the error. 0 gives a warning,1 gives a systemic error, anything else
 *                           gives a fatal error.
 * @param[in] ErrorMessage : The message to accompany with the warning.
 */
static inline void handleError( int severity, const char ErrorMessage[128] ) {

  // Probably not that serious. More of a curiosity.
  if( severity == 0 ) {
    printf( " %s*** Warning : %s%s\n", KYEL, ErrorMessage, KNRM ) ;
  // Probably serious and likely to lead to a malfunction somewhere.
  } else if( severity == 1 ) {
    printf( " %s*** Systemic Error : %s%s\n", KMAG, ErrorMessage, KNRM ) ;
  // Catastrophic.
  } else {
    printf( " %s*** Fatal Error : %s%s\n", KRED, ErrorMessage, KNRM ) ;
    exit( EXIT_FAILURE ) ;
  }

}

typedef enum Error { WARNING, SYSTEMATIC, FATAL } Error_t ;
/**
 * @brief Print to stdout and flush right away.
 * @brief[in] format : Variadic arguments for printf.
 */
static inline void error( const int _severity, const char * _format, ... ) { 

  va_list arg ;
  va_start( arg, _format ) ;

  // Probably not that serious. More of a curiosity.
  if( _severity == WARNING ) {
    printf( "\n %s*** Warning : ", KYEL ) ;
    vfprintf( stdout, _format, arg ) ;
    printf( "%s\n", KNRM ) ;
    // Probably serious and likely to lead to a malfunction somewhere.
  } else if( _severity == SYSTEMATIC ) {
    printf( "\n %s*** Systematic Error : ", KMAG ) ;
    vfprintf( stdout, _format, arg ) ;
    printf( "%s\n", KNRM ) ;
  // Catastrophic.
  } else {
    printf( "\n %s*** Fatal Error : ", KRED ) ;
    vfprintf( stdout, _format, arg ) ;
    printf( "%s\n", KNRM ) ;
    exit( EXIT_FAILURE ) ;
  }

  va_end( arg ) ; fflush( stdout ) ;

}

static inline int isinvalid( const float_p _val ) {

  if( isnan( _val ) || isinf( _val ) ) return 1 ;

  return 0 ;

}

#endif /* #ifndef PANIC_H */
