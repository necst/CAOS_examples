/********************************************************************************
*
*  Company: Synelixis Solutions Ltd
*  Engineer: Andreas Brokalakis
*
*  Design Name: EXTRA Demonstrator Application
*  Application Name: Retinal Image Segmentation
*  Project Name: H2020-EXTRA
*  Target Devices: Xilinx Zynq / Zynq UltraScale+
*  Xilinx Tools version supported: Vivado/VivadoHLS 2017.4
*  Description: parameteres.h header file contains values of basic parameters used
*   in the retinal image segmentation application.
*
*  Notice: -
*
*
*  Copyright: Synelixis Solutions Ltd
*             Andreas Brokalakis, Antonis Nikitakis
*
*********************************************************************************/
//
// Revision History
//
// $Log: parameters.h $
// Revision 1.0  20/7/2017  Andreas Brokalakis
// Complete version, for final demonstration and final deliverable.
//


#ifndef PARAMS_LIB
#define PARAMS_LIB

#define NMAX 2097151

#define N_TESTS 1

//#define DEBUG_PRINT 1

#ifdef DEBUG_PRINT
	#define WIDTH 10
	#define HEIGHT 10
#else
	#define WIDTH 2592
	#define HEIGHT 1944

	//#define WIDTH 865
	//#define HEIGHT 865

#endif

#endif
