/********************************************************************************
*
*  Company: Synelixis Solutions Ltd
*  Engineer: Andreas Brokalakis
*
*  Design Name: EXTRA Demonstrator Application
*  Application Name: Retinal Image Segmentation
*  Project Name: H2020-EXTRA
*
*  This is the software reference for the application.
*  To be used with PoliMi's CAOS tools
*
*  Target Devices: Xilinx Zynq / Zynq UltraScale+
*  Xilinx Tools version supported: Vivado/VivadoHLS 2017.4
*
*  Notice: -
*
*  Description: The application implements a segmentation or retinal images
*	aiming to separate the vein structure from the other elements of the image.
*	The input images used at 5MP images (2592x1944) - defined at parameters.h 
*	header file. If you want to use other input sizes please change the parameters
*	there however keep in mind that the filters used in the application may not be
*	optimal for other resolutions.
*	The input images are supposed to be in .ppm format. Please refer in the comments
*	before the load_ppm() function for the specifics of the accepted input format. In
*	case you want to use other formats, please replace or modify this function.
*	Once the image has been read to memory, a series of filtering operations are 
*	performed. First, the image goes through two denoising Gauss filters with size
*	7x7 and 15x15. These filters reduce noise and assist the main segmentation function
*	to produce better results.
*	After the denoising filters, the main segmentation is realised through a parallel
*	series of seven 16x16 filters that aim to identify the vein structure through
*	different angles (0, 30, 60, 90, 120, 150, 180 degrees). The strongest response
*	is retained.
*
*
*  Copyright: Synelixis Solutions Ltd
*             Andreas Brokalakis, Antonis Nikitakis
*
*********************************************************************************/
// Revision History
//
// $Log: ris_burst_unroll.c $
// Revision 1.0  20/7/2018  Andreas Brokalakis
// Complete version, for final demonstration and final deliverable.
//

#include "matrices.h"
#include "parameters.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>
#include <sys/time.h>

//define color channel codes
#define RED 0
#define GREEN 1
#define BLUE 2

double gettime(void) {
    struct timeval ttime;
    gettimeofday(&ttime , NULL);
    return ttime.tv_sec + ttime.tv_usec * 0.000001;
}


//Read an image from a .ppm file format
//A single channel is read to a matrix
//Inputs:
//	filename: the name of the file to read from
//	mat: the matrix that the file data will be loaded to
//	rgd: the channel to select to load in mat
void load_ppm (char *filename, unsigned int mat[HEIGHT][WIDTH], int rgb){

	int i, j, is_rgb;
	char mode[2];
	unsigned int buf[3], pixel;

	FILE *input = fopen(filename, "r");
	if (input == NULL){
		printf("Error in loading image %s\n",filename);
		exit(1);
	}

	//read file properties
	//first line must have the form: mode width height max_value
	//Acceptable modes: P2 (grayscale), P3 (color)
	//max value can be between 0 and 255
	fscanf(input,"%s %*d %*d %*d\n", mode);
	if (strcmp(mode,"P2") == 0) 
		is_rgb = 0;
	else if (strcmp(mode,"P3") == 0) 
		is_rgb = 1;	
	else {
		printf("Image error, mode not present (either P2 or P3)\n");
		exit(1);
	}

	//read pixels
	for (i = 0; i < HEIGHT; i++){
		for (j = 0; j < WIDTH; j++){
			
			fscanf(input, "%u", &buf[RED]);
			//if the image is a color one, we must also the read the other color channels
			if (is_rgb){
				fscanf(input, "%u", &buf[GREEN]);
				fscanf(input, "%u", &buf[BLUE]);
			}

			if (is_rgb) 
				pixel = buf[rgb];	//select which channel to keep
			else 
				pixel = buf[RED];	//if the image is grayscale (1 channel - therefore this is equivalent to buf[0])

			mat[i][j] = pixel; 
		}
	}

	fclose(input);
}

//Save image data (stored in matrix mat) to an image file (.ppm file format)
//Mat contains a grayscale image, therefore a single channel is written to the 
//output file. Note that the file format will be:
//	P2 <HEIGHT> <WIDTH> 255
// <pixel0_value> ... <pixel(WIDTH-1)_value>
// ...
// <pixel(WIDTH*(HEIGHT-1))_value> ... <pixel(HEIGHT*WIDTH-1)_value>
//
//Inputs:
//	filename: the name of the file to write to
//	mat: the matrix that contains the image data 
void save_ppm(char *filename, unsigned int mat[HEIGHT][WIDTH]){

	int i, j;

	FILE *output = fopen(filename, "w");
	if (output == NULL){
		printf("Error in opening file %s in write mode\n", filename);
		exit(1);
	}

	//write file header
	fprintf(output,"P2 %d %d 255\n", WIDTH, HEIGHT);

	//write pixel values (line by line)
	for (i = 0; i < HEIGHT; i++){
		for (j = 0; j < WIDTH; j++){
			fprintf(output, "%3u ", (unsigned int)mat[i][j]);
		}
		fprintf(output,"\n");
	}

	fclose(output);
}

//Apply a gaussian 7x7 filter kernel
//The filter kernel is stored in gauss7x7 matrix available in header file matrices.h

void gauss_7_filter(unsigned int result[HEIGHT][WIDTH], unsigned int input[HEIGHT][WIDTH]){

	int i, j;
	int row, col;
	int sum;

	int kernel_size = 7;
	int center = (int)kernel_size/2;
 
	for (i = center; i < HEIGHT-(center-1 + kernel_size%2); i++){
		for (j = center; j < WIDTH-(center-1 + kernel_size%2); j++){
			
			result[i][j] = 0;
			sum = 0;

			for (row = 0; row < 7; row++){
				for (col = 0; col < 7; col++) {
					sum += ((int)gauss7x7[row][col] * (int)input[i-center+row][j-center+col]);
				}
			}

			sum = sum/201;

			if((sum > 0) && (sum < 255))
				result[i][j] = sum;
			else if(sum >= 255)
				result[i][j] = 255;
			else
				result[i][j] = 0;
				
		}	
	}
}

//Apply a gaussian 15x15 filter kernel
//The filter kernel is stored in gauss15x15 matrix available in header file matrices.h

void gauss_15_filter(unsigned int result[HEIGHT][WIDTH], unsigned int input[HEIGHT][WIDTH]){

	int i, j;
	int row, col;
	int sum;

	int kernel_size = 15;
	int center = (int)kernel_size/2;
 
	for (i = center; i < HEIGHT-(center-1+kernel_size%2); i++){
		for (j = center; j < WIDTH-(center-1+kernel_size%2); j++){
			
			result[i][j] = 0;
			sum = 0;

			for (row = 0; row < 15; row++){
				for (col = 0; col < 15; col++) {
					sum += gauss15x15[row][col] * input[i-center+row][j-center+col];
				}
			}

			sum = sum/12763;

			if ((sum > 0) && (sum < 255))
				result[i][j] = sum;
			else if(sum >= 255)
				result[i][j] = 255;
			else 
				result[i][j] = 0;					 

		}	
	}
}

//Apply a series (7) of 16x16 filter kernels - on the same input image.
//Choose he strongest responses
//The filter kernels represent different angles (0, 30, 60, 90, 120, 150, 180 degrees) and are stored in 
//coeffs matrix available in header file matrices.h

void match_filter(unsigned int result[HEIGHT][WIDTH], unsigned int input[HEIGHT][WIDTH]){

	int max;
	int sum[NUM_FILTERS];
	unsigned int i, j, theta, row, col;
	unsigned int tmp_input[MF_KERN_SIZE][MF_KERN_SIZE];
	int my_index = 0;
    int index;
    int column = MF_KERN_SIZE-1;

		 
	for	(i = MF_CENTER; i < HEIGHT-(MF_CENTER-1+MF_KERN_SIZE%2); i++){
		//prefetching a window
		for (row = 0; row < MF_KERN_SIZE; row++) {
            for (col = 0; col < MF_KERN_SIZE; col++) {
                tmp_input[row][col] = input[i-MF_CENTER+row][col];
            }
		}
		
		for (j = MF_CENTER; j < WIDTH-(MF_CENTER-1+MF_KERN_SIZE%2); j++){
			
			result[i][j] = 0;
			max = 0;

			//apply filters
			for (theta = 0; theta < NUM_FILTERS; theta++){
				sum[theta] = 0;
			}		
			
			for (row = 0; row < MF_KERN_SIZE; row++){
				for (col = 0; col < MF_KERN_SIZE; col++){
					for (theta = 0; theta < NUM_FILTERS; theta++) {
						sum[theta] += (int)coeffs[theta][row][col] * (int)tmp_input[row][(col+my_index)%MF_KERN_SIZE];	
					}
				}
			}
			
			//choose the max response
			for (theta = 0; theta < NUM_FILTERS; theta++){
				if (sum[theta] > max)
					max = sum[theta];
			}
			

			//update tmp_input (this is for memory access optimization)
            column++;
            if (column < WIDTH) {
                for (index = 0; index < MF_KERN_SIZE; index++) {
                    tmp_input[index][my_index] = input[i-MF_CENTER+index][column];
                }
            }
            else
                column = MF_KERN_SIZE-1;
            
            my_index++;
            if(my_index > (MF_KERN_SIZE-1))
                my_index = 0;

			max = max/DIVISOR;

			if ((max > 0) && (max < 255))	//invert
				result[i][j] = max;
			else if (max / DIVISOR >= 255)
				result[i][j] = 255;
			else
				result[i][j] = 0;
		}	
	}

}



int main(int argc, char *argv[]){

	int i,j,k,m,ok,lstok,sum,max;

	static unsigned int input[HEIGHT][WIDTH];
	static unsigned int soft[HEIGHT][WIDTH];
	static unsigned int tmp1[HEIGHT][WIDTH];
	static unsigned int tmp2[HEIGHT][WIDTH];

	char *input_name;
	char output_name[] = "software_out_unroll.ppm";

	double timeTotal = 0.0f;
    double time0;
		

	if(argc <= 1){
		printf("Please provide an input file\n");
		exit(1);
	}

	input_name = argv[1];

	printf("Filling matrix...\n");
	load_ppm(input_name, input, GREEN); //in case of a color image, select the green channel
	printf("Done!\n");

	printf("Applying gauss_7 filter...\n");
	time0=gettime();
	gauss_7_filter(tmp1, input);
	timeTotal = gettime()-time0;
	printf("Time: %f \n", timeTotal);

	printf("Applying gauss_15 filter...\n");
	time0=gettime();
	gauss_15_filter(tmp2, tmp1);
	timeTotal = gettime()-time0;
	printf("Time: %f \n", timeTotal);

	printf("Applying match filter...\n");
	time0=gettime();
	match_filter(tmp1, tmp2);
	timeTotal = gettime()-time0;
	printf("Time: %f \n", timeTotal);

	printf("Done!\n");

	printf("Saving output...\n");
	save_ppm(output_name, tmp1);


	printf("All Done!\n");

	return 0;

}

